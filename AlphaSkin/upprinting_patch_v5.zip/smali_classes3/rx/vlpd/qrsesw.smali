.class public Lrx/vlpd/qrsesw;
.super Ljava/lang/Object;
.source "SigningInfo.java"


# static fields
.field static sig_data:Ljava/lang/String; = "AQAAA60wggOpMIICkaADAgECAgRlIYpmMA0GCSqGSIb3DQEBCwUAMIGEMRQwEgYDVQQGDAt1cF9wcmludGluZzEUMBIGA1UECAwLdXBfcHJpbnRpbmcxFDASBgNVBAcMC3VwX3ByaW50aW5nMRQwEgYDVQQKDAt1cF9wcmludGluZzEUMBIGA1UECwwLdXBfcHJpbnRpbmcxFDASBgNVBAMMC3VwX3ByaW50aW5nMB4XDTE5MTExNDA2NDEyNloXDTQ0MTEwNzA2NDEyNlowgYQxFDASBgNVBAYMC3VwX3ByaW50aW5nMRQwEgYDVQQIDAt1cF9wcmludGluZzEUMBIGA1UEBwwLdXBfcHJpbnRpbmcxFDASBgNVBAoMC3VwX3ByaW50aW5nMRQwEgYDVQQLDAt1cF9wcmludGluZzEUMBIGA1UEAwwLdXBfcHJpbnRpbmcwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCL67bKQfXcxz8OKpJzmv9CtSIKnwK2wwcNzb6w1vonuOGfRxztA7j8uO2QbUrLbo2xuO+0oyAjKLVfFRqUMRanilDuYPjOAR/l37BnczZDtihXqNHMbeDQEcnYX4uZXTNHLT417731nKcP7zhcqffGmtVt6+/OXs5HWaBanTTcgQsFRITF6CX1DQe/g4JTHqjP0djrqjqzgx0OWvESoJX29fKcAs8QXf9S7T/2/3xMf8VsDP6oZx983gxF+qYPrb3zMxTmRzo9hlke904aAq3EYBcckAGpfJahvNEpCyB68lGFt8c06gdaMWxPo/4Z5q3Kz5yBzdKBqY0y4Y6Z1UNtAgMBAAGjITAfMB0GA1UdDgQWBBTr4gI5LpKOauHbujFUboJkt8QeHzANBgkqhkiG9w0BAQsFAAOCAQEAATwiXr3BzG01ZsFfk4fp7ae8GlrHd/NnbGfSFbXVSqaDrOwpLpflxolOdZyLCDwIroWscniSFvjfYvyrou/wN8xbj0lTJKdGfyP5bGLGmtDN934VO9ldGmA4N1uYUfnRQcPKOA2YI3c38xJQzgl250AiJM7+HwGixtBee47QeReR2+Mshrao8pgHrsgP0sw003qrD23qRjGXGMoAa42ghzW2pRTqsNKItaxnTV2kASKR5TD2mUoARBpWEpbaIaDu7qyZXMNIZ/Jd8dOfW/UqrpaSXZQK3izKHzzEoMboM9jUmFVu3q/nS+57t/0mLvdEz3jHhAk2aT4kf7nBvijpZg=="

.field public static signatures:[Landroid/content/pm/Signature;


# direct methods
.method static constructor <clinit>()V
    .locals 0

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a()V
    .locals 6

    :try_start_0
    new-instance v0, Ljava/io/DataInputStream;

    new-instance v1, Ljava/io/ByteArrayInputStream;

    sget-object v2, Lrx/vlpd/qrsesw;->sig_data:Ljava/lang/String;

    const/4 v3, 0x0

    invoke-static {v2, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    invoke-direct {v0, v1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    invoke-virtual {v0}, Ljava/io/DataInputStream;->read()I

    move-result v1

    and-int/lit16 v1, v1, 0xff

    new-array v2, v1, [[B

    const/4 v4, 0x0

    :goto_0
    if-ge v4, v1, :cond_0

    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    move-result v5

    new-array v5, v5, [B

    aput-object v5, v2, v4

    aget-object v5, v2, v4

    invoke-virtual {v0, v5}, Ljava/io/DataInputStream;->readFully([B)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_0
    new-array v0, v1, [Landroid/content/pm/Signature;

    sput-object v0, Lrx/vlpd/qrsesw;->signatures:[Landroid/content/pm/Signature;

    :goto_1
    sget-object v0, Lrx/vlpd/qrsesw;->signatures:[Landroid/content/pm/Signature;

    array-length v1, v0

    if-ge v3, v1, :cond_1

    new-instance v1, Landroid/content/pm/Signature;

    aget-object v4, v2, v3

    invoke-direct {v1, v4}, Landroid/content/pm/Signature;-><init>([B)V

    aput-object v1, v0, v3
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    :cond_1
    return-void
.end method

.method public static getApkContentsSigners()[Landroid/content/pm/Signature;
    .locals 1

    sget-object v0, Lrx/vlpd/qrsesw;->signatures:[Landroid/content/pm/Signature;

    if-nez v0, :cond_0

    invoke-static {}, Lrx/vlpd/qrsesw;->a()V

    sget-object v0, Lrx/vlpd/qrsesw;->signatures:[Landroid/content/pm/Signature;

    :cond_0
    return-object v0
.end method

.method public static getSigningCertificateHistory(Landroid/content/pm/SigningInfo;)[Landroid/content/pm/Signature;
    .locals 0

    invoke-virtual {p0}, Landroid/content/pm/SigningInfo;->hasMultipleSigners()Z

    move-result p0

    if-eqz p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    sget-object p0, Lrx/vlpd/qrsesw;->signatures:[Landroid/content/pm/Signature;

    if-nez p0, :cond_1

    invoke-static {}, Lrx/vlpd/qrsesw;->a()V

    sget-object p0, Lrx/vlpd/qrsesw;->signatures:[Landroid/content/pm/Signature;

    :cond_1
    return-object p0
.end method
