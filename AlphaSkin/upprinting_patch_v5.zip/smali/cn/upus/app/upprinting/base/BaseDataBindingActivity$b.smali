.class public Lcn/upus/app/upprinting/base/BaseDataBindingActivity$b;
.super Ljava/lang/Object;
.source "BaseDataBindingActivity.java"

# interfaces
.implements Landroidx/lifecycle/Observer;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->m(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroidx/lifecycle/Observer<",
        "Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Lcn/upus/app/upprinting/base/BaseDataBindingActivity;


# direct methods
.method public constructor <init>(Lcn/upus/app/upprinting/base/BaseDataBindingActivity;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity$b;->a:Lcn/upus/app/upprinting/base/BaseDataBindingActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onChanged(Ljava/lang/Object;)V
    .locals 8

    .line 1
    check-cast p1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    if-eqz p1, :cond_4

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity$b;->a:Lcn/upus/app/upprinting/base/BaseDataBindingActivity;

    iget-object v0, v0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutTotalCount()J

    move-result-wide v1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v3

    sub-long/2addr v1, v3

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v3

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 5
    iget-object v3, v3, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "USEQTY"

    invoke-virtual {v3, v5, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 6
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v3

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 7
    iget-object v3, v3, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "BALAQTY"

    invoke-virtual {v3, v5, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 8
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v3

    .line 9
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v5

    if-eqz v5, :cond_0

    .line 10
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    if-lez v6, :cond_0

    .line 11
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    int-to-long v6, v6

    add-long/2addr v3, v6

    .line 12
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    int-to-long v5, v5

    sub-long/2addr v1, v5

    .line 13
    :cond_0
    const-wide v1, 0x1869f
    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setBalaqty(J)V

    .line 14
    invoke-virtual {v0, v3, v4}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setUseqty(J)V

    const-string v0, "cutBeforeCheck"

    .line 15
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_3

    .line 16
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getPgMsg()Ljava/lang/String;

    move-result-object v0

    .line 17
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3

    .line 18
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity$b;->a:Lcn/upus/app/upprinting/base/BaseDataBindingActivity;

    .line 19
    iget-object v3, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    if-nez v3, :cond_1

    goto :goto_0

    .line 20
    :cond_1
    iget-object v3, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 21
    :cond_2
    :goto_0
    new-instance v3, Ljava/lang/ref/WeakReference;

    new-instance v4, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v4}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v3, v4}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v3, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 22
    :goto_1
    iget-object v3, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v4, Lc/b/a/a/g/h;

    invoke-direct {v4, v2}, Lc/b/a/a/g/h;-><init>(Lcn/upus/app/upprinting/base/BaseDataBindingActivity;)V

    .line 23
    iput-object v4, v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 24
    iget-object v3, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v3, v1}, Landroidx/fragment/app/DialogFragment;->setCancelable(Z)V

    .line 25
    iget-object v3, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    const/16 v4, 0x8

    .line 26
    iput v4, v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->g:I

    .line 27
    iget-object v3, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v3}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    .line 28
    iput-object v0, v3, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 29
    iget-object v0, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v4, 0x7f11009d

    invoke-virtual {v3, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    .line 30
    iput-object v3, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->f:Ljava/lang/String;

    .line 31
    iget-object v0, v2, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v2}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v2

    const-string v3, "customdialog"

    invoke-virtual {v0, v2, v3}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    .line 32
    sget-object v0, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 33
    invoke-virtual {v0}, Lcn/upus/app/upprinting/MApp;->c()V

    .line 34
    :cond_3
    new-instance v0, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;

    const-string v2, "recharge_finish"

    invoke-direct {v0, v2}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;-><init>(Ljava/lang/String;)V

    .line 35
    invoke-static {}, Li/b/a/c;->b()Li/b/a/c;

    move-result-object v2

    invoke-virtual {v2, v0}, Li/b/a/c;->f(Ljava/lang/Object;)V

    .line 36
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getState()I

    move-result p1

    const/4 v0, -0x4

    if-ne p1, v0, :cond_4

    .line 37
    sput-boolean v1, Lcn/upus/app/upprinting/MApp;->D:Z

    :cond_4
    return-void
.end method
