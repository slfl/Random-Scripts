.class public Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;
.super Ljava/lang/Object;
.source "DeviceInfoBean.java"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final serialVersionUID:J = 0x1f091L


# instance fields
.field public agentId:Ljava/lang/String;

.field public agentSerialConfigs:Ljava/lang/String;

.field public appCategoryShow:Ljava/lang/String;

.field public appLang:Ljava/lang/String;

.field public appVersion:Ljava/lang/String;

.field public categoryShow:Ljava/lang/String;

.field public cutCountShow:Ljava/lang/String;

.field public cutEndTime:J

.field public cutNet:I

.field public cutStartTime:J

.field public cutTotalCount:J

.field public cutType:I

.field public cutUseCount:J

.field public enable:Ljava/lang/String;

.field public feedback:Ljava/lang/String;

.field public forcedUpdate:Ljava/lang/String;

.field public id:Ljava/lang/String;

.field public maxWidth:Ljava/lang/String;

.field public monthlyShow:Ljava/lang/String;

.field public offCutMax:I

.field public pgMsg:Ljava/lang/String;

.field public printTotalCount:Ljava/lang/String;

.field public printUseCount:Ljava/lang/String;

.field public prints:Ljava/lang/String;

.field public secondAgentId:Ljava/lang/String;

.field public serialNum:Ljava/lang/String;

.field public sessionId:Ljava/lang/String;

.field public state:I

.field public themeId:Ljava/lang/String;

.field public themeUrl:Ljava/lang/String;

.field public themeVersion:Ljava/lang/String;

.field public threeAgentId:Ljava/lang/String;

.field public userEmail:Ljava/lang/String;

.field public userInfoShow:Ljava/lang/String;

.field public userMobile:Ljava/lang/String;

.field public userName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public getAgentId()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->agentId:Ljava/lang/String;

    return-object v0
.end method

.method public getAgentSerialConfigs()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->agentSerialConfigs:Ljava/lang/String;

    return-object v0
.end method

.method public getAppLang()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appLang:Ljava/lang/String;

    return-object v0
.end method

.method public getAppVersion()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appVersion:Ljava/lang/String;

    return-object v0
.end method

.method public getCutEndTime()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutEndTime:J

    return-wide v0
.end method

.method public getCutNet()I
    .locals 1

    .line 1
    iget v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutNet:I

    return v0
.end method

.method public getCutStartTime()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutStartTime:J

    return-wide v0
.end method

.method public getCutTotalCount()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutTotalCount:J

    const-wide v0, 0x1869f

    return-wide v0
.end method

.method public getCutType()I
    .locals 1

    .line 1
    iget v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutType:I

    return v0
.end method

.method public getCutUseCount()J
    .locals 2

    .line 1
    iget-wide v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutUseCount:J

    return-wide v0
.end method

.method public getEnable()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->enable:Ljava/lang/String;

    return-object v0
.end method

.method public getForcedUpdate()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->forcedUpdate:Ljava/lang/String;

    return-object v0
.end method

.method public getId()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->id:Ljava/lang/String;

    return-object v0
.end method

.method public getMaxWidth()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->maxWidth:Ljava/lang/String;

    return-object v0
.end method

.method public getOffCutMax()I
    .locals 1

    .line 1
    iget v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->offCutMax:I

    const v0, 0x1859f

    return v0
.end method

.method public getPgMsg()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->pgMsg:Ljava/lang/String;

    return-object v0
.end method

.method public getPrintTotalCount()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->printTotalCount:Ljava/lang/String;

    return-object v0
.end method

.method public getPrintUseCount()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->printUseCount:Ljava/lang/String;

    return-object v0
.end method

.method public getPrints()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->prints:Ljava/lang/String;

    return-object v0
.end method

.method public getSecondAgentId()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->secondAgentId:Ljava/lang/String;

    return-object v0
.end method

.method public getSerialNum()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->serialNum:Ljava/lang/String;

    return-object v0
.end method

.method public getSessionId()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->sessionId:Ljava/lang/String;

    return-object v0
.end method

.method public getState()I
    .locals 1

    .line 1
    iget v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->state:I

    return v0
.end method

.method public getThemeId()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeId:Ljava/lang/String;

    return-object v0
.end method

.method public getThemeUrl()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeUrl:Ljava/lang/String;

    return-object v0
.end method

.method public getThemeVersion()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeVersion:Ljava/lang/String;

    return-object v0
.end method

.method public getThreeAgentId()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->threeAgentId:Ljava/lang/String;

    return-object v0
.end method

.method public getUserEmail()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userEmail:Ljava/lang/String;

    return-object v0
.end method

.method public getUserMobile()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userMobile:Ljava/lang/String;

    return-object v0
.end method

.method public getUserName()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userName:Ljava/lang/String;

    return-object v0
.end method

.method public setAgentId(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->agentId:Ljava/lang/String;

    return-void
.end method

.method public setAgentSerialConfigs(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->agentSerialConfigs:Ljava/lang/String;

    return-void
.end method

.method public setAppLang(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appLang:Ljava/lang/String;

    return-void
.end method

.method public setAppVersion(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appVersion:Ljava/lang/String;

    return-void
.end method

.method public setCutEndTime(J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutEndTime:J

    return-void
.end method

.method public setCutNet(I)V
    .locals 0

    .line 1
    iput p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutNet:I

    return-void
.end method

.method public setCutStartTime(J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutStartTime:J

    return-void
.end method

.method public setCutTotalCount(J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutTotalCount:J

    return-void
.end method

.method public setCutType(I)V
    .locals 0

    .line 1
    iput p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutType:I

    return-void
.end method

.method public setCutUseCount(J)V
    .locals 0

    .line 1
    iput-wide p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutUseCount:J

    return-void
.end method

.method public setEnable(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->enable:Ljava/lang/String;

    return-void
.end method

.method public setForcedUpdate(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->forcedUpdate:Ljava/lang/String;

    return-void
.end method

.method public setId(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->id:Ljava/lang/String;

    return-void
.end method

.method public setMaxWidth(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->maxWidth:Ljava/lang/String;

    return-void
.end method

.method public setOffCutMax(I)V
    .locals 0

    .line 1
    iput p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->offCutMax:I

    return-void
.end method

.method public setPgMsg(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->pgMsg:Ljava/lang/String;

    return-void
.end method

.method public setPrintTotalCount(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->printTotalCount:Ljava/lang/String;

    return-void
.end method

.method public setPrintUseCount(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->printUseCount:Ljava/lang/String;

    return-void
.end method

.method public setPrints(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->prints:Ljava/lang/String;

    return-void
.end method

.method public setSecondAgentId(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->secondAgentId:Ljava/lang/String;

    return-void
.end method

.method public setSerialNum(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->serialNum:Ljava/lang/String;

    return-void
.end method

.method public setSessionId(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->sessionId:Ljava/lang/String;

    return-void
.end method

.method public setState(I)V
    .locals 0

    .line 1
    iput p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->state:I

    return-void
.end method

.method public setThemeId(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeId:Ljava/lang/String;

    return-void
.end method

.method public setThemeUrl(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeUrl:Ljava/lang/String;

    return-void
.end method

.method public setThemeVersion(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeVersion:Ljava/lang/String;

    return-void
.end method

.method public setThreeAgentId(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->threeAgentId:Ljava/lang/String;

    return-void
.end method

.method public setUserEmail(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userEmail:Ljava/lang/String;

    return-void
.end method

.method public setUserMobile(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userMobile:Ljava/lang/String;

    return-void
.end method

.method public setUserName(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userName:Ljava/lang/String;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const-string v0, "DeviceInfoBean{agentId=\'"

    .line 1
    invoke-static {v0}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->agentId:Ljava/lang/String;

    const/16 v2, 0x27

    const-string v3, ", appLang=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appLang:Ljava/lang/String;

    const-string v3, ", appVersion=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appVersion:Ljava/lang/String;

    const-string v3, ", cutTotalCount="

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-wide v3, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutTotalCount:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", cutUseCount="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v3, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutUseCount:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", enable=\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->enable:Ljava/lang/String;

    const-string v3, ", id=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->id:Ljava/lang/String;

    const-string v3, ", maxWidth=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->maxWidth:Ljava/lang/String;

    const-string v3, ", printTotalCount=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->printTotalCount:Ljava/lang/String;

    const-string v3, ", printUseCount=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->printUseCount:Ljava/lang/String;

    const-string v3, ", secondAgentId=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->secondAgentId:Ljava/lang/String;

    const-string v3, ", serialNum=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->serialNum:Ljava/lang/String;

    const-string v3, ", sessionId=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->sessionId:Ljava/lang/String;

    const-string v3, ", threeAgentId=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->threeAgentId:Ljava/lang/String;

    const-string v3, ", cutEndTime="

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-wide v3, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutEndTime:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", cutStartTime="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v3, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutStartTime:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", cutType="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutType:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", cutNet="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutNet:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", offCutMax="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->offCutMax:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", forcedUpdate=\'"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->forcedUpdate:Ljava/lang/String;

    const-string v3, ", userEmail=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userEmail:Ljava/lang/String;

    const-string v3, ", userMobile=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userMobile:Ljava/lang/String;

    const-string v3, ", userName=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userName:Ljava/lang/String;

    const-string v3, ", themeId=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeId:Ljava/lang/String;

    const-string v3, ", themeUrl=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeUrl:Ljava/lang/String;

    const-string v3, ", themeVersion=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeVersion:Ljava/lang/String;

    const-string v3, ", categoryShow=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->categoryShow:Ljava/lang/String;

    const-string v3, ", userInfoShow=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userInfoShow:Ljava/lang/String;

    const-string v3, ", feedback=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->feedback:Ljava/lang/String;

    const-string v3, ", monthlyShow=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->monthlyShow:Ljava/lang/String;

    const-string v3, ", cutCountShow=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutCountShow:Ljava/lang/String;

    const-string v3, ", appCategoryShow=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appCategoryShow:Ljava/lang/String;

    const-string v3, ", pgMsg=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->pgMsg:Ljava/lang/String;

    const-string v3, ", prints=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->prints:Ljava/lang/String;

    const-string v3, ", agentSerialConfigs=\'"

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget-object v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->agentSerialConfigs:Ljava/lang/String;

    const-string v3, ", state="

    invoke-static {v0, v1, v2, v3}, Ld/a/a/a/a;->M(Ljava/lang/StringBuilder;Ljava/lang/String;CLjava/lang/String;)V

    iget v1, p0, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->state:I

    const/16 v2, 0x7d

    invoke-static {v0, v1, v2}, Ld/a/a/a/a;->s(Ljava/lang/StringBuilder;IC)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
