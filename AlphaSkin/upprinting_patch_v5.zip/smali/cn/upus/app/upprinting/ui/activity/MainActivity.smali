.class public Lcn/upus/app/upprinting/ui/activity/MainActivity;
.super Lcn/upus/app/upprinting/base/BaseDataBindingActivity;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcn/upus/app/upprinting/base/BaseDataBindingActivity<",
        "Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;",
        ">;",
        "Landroid/view/View$OnTouchListener;"
    }
.end annotation


# instance fields
.field public A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

.field public B:Le/b/p/b;

.field public C:Le/b/p/b;

.field public D:Landroid/net/wifi/WifiManager;

.field public E:Z

.field public F:Z

.field public G:Z

.field public H:Z

.field public I:Z

.field public J:Z

.field public K:Z

.field public L:Z

.field public M:Z

.field public N:I

.field public O:Lcom/amap/api/location/AMapLocationClient;

.field public P:Lcom/amap/api/location/AMapLocationClientOption;

.field public Q:Le/b/p/b;

.field public R:Lcom/amap/api/location/AMapLocationListener;

.field public k:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/QRCodeDialog;",
            ">;"
        }
    .end annotation
.end field

.field public l:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;",
            ">;"
        }
    .end annotation
.end field

.field public m:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/AdDialog;",
            ">;"
        }
    .end annotation
.end field

.field public n:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;",
            ">;"
        }
    .end annotation
.end field

.field public o:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;",
            ">;"
        }
    .end annotation
.end field

.field public p:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;",
            ">;"
        }
    .end annotation
.end field

.field public q:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;",
            ">;"
        }
    .end annotation
.end field

.field public r:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field public s:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/AdBean;",
            ">;>;"
        }
    .end annotation
.end field

.field public t:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/NoticesBean;",
            ">;>;"
        }
    .end annotation
.end field

.field public u:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;",
            ">;"
        }
    .end annotation
.end field

.field public v:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/AppUpdateBean;",
            ">;"
        }
    .end annotation
.end field

.field public w:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;",
            ">;"
        }
    .end annotation
.end field

.field public x:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;",
            ">;"
        }
    .end annotation
.end field

.field public y:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;",
            ">;"
        }
    .end annotation
.end field

.field public z:Lcn/upus/app/upprinting/data/bean/AdBean;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->k:Ljava/lang/ref/WeakReference;

    .line 3
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->z:Lcn/upus/app/upprinting/data/bean/AdBean;

    const/4 v1, 0x1

    .line 4
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->E:Z

    .line 5
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->F:Z

    const/4 v1, 0x0

    .line 6
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G:Z

    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H:Z

    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->I:Z

    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->J:Z

    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->K:Z

    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->L:Z

    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->M:Z

    .line 7
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    .line 8
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->P:Lcom/amap/api/location/AMapLocationClientOption;

    .line 9
    new-instance v0, Lc/b/a/a/l/b/k2;

    invoke-direct {v0, p0}, Lc/b/a/a/l/b/k2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->R:Lcom/amap/api/location/AMapLocationListener;

    return-void
.end method

.method public static J(Landroid/content/Context;)V
    .locals 1

    .line 1
    const-class v0, Lcn/upus/app/upprinting/ui/activity/MainActivity;

    invoke-static {p0, v0}, Ld/a/a/a/a;->H(Landroid/content/Context;Ljava/lang/Class;)V

    return-void
.end method

.method public static M()V
    .locals 3

    .line 1
    sget-object v0, Lc/b/a/a/h/a;->c:Ljava/lang/String;

    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->delete(Ljava/lang/String;)Z

    .line 2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 3
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "theme_version"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method

.method public static synthetic P(Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getSort()I

    move-result p0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getSort()I

    move-result p1

    sub-int/2addr p0, p1

    if-lez p0, :cond_0

    const/4 p0, -0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x1

    :goto_0
    return p0
.end method

.method public static synthetic Q(Lcn/upus/app/upprinting/data/bean/PartHistoryBean;Lcn/upus/app/upprinting/data/bean/PartHistoryBean;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->getSort()I

    move-result p0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->getSort()I

    move-result p1

    sub-int/2addr p0, p1

    if-lez p0, :cond_0

    const/4 p0, -0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x1

    :goto_0
    return p0
.end method

.method public static synthetic R(Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;)I
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getSort()I

    move-result p0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getSort()I

    move-result p1

    sub-int/2addr p0, p1

    if-lez p0, :cond_0

    const/4 p0, -0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x1

    :goto_0
    return p0
.end method

.method public static p(Lcn/upus/app/upprinting/ui/activity/MainActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static q(Lcn/upus/app/upprinting/ui/activity/MainActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static r(Lcn/upus/app/upprinting/ui/activity/MainActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static s(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V
    .locals 11

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->h:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 3
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->F:Z

    const/16 v1, 0x8

    if-eqz v0, :cond_0

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->t:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_0

    .line 6
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->s:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 8
    :goto_0
    new-instance v0, Landroid/view/animation/TranslateAnimation;

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v9, 0x1

    const/4 v10, 0x0

    move-object v2, v0

    invoke-direct/range {v2 .. v10}, Landroid/view/animation/TranslateAnimation;-><init>(IFIFIFIF)V

    const-wide/16 v1, 0x3e8

    .line 9
    invoke-virtual {v0, v1, v2}, Landroid/view/animation/TranslateAnimation;->setDuration(J)V

    .line 10
    new-instance v1, Lc/b/a/a/l/b/o6;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/o6;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/animation/TranslateAnimation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 11
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast p0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p0, p0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->h:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/widget/LinearLayout;->setAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method


# virtual methods
.method public final A(Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;)V
    .locals 7

    .line 1
    iget-object v0, p1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeId:Ljava/lang/String;

    const/4 v1, 0x1

    new-array v2, v1, [Ljava/lang/Object;

    const-string v3, "\u4e91\u7aef\u7684\u4e3b\u9898id\uff1a"

    .line 2
    invoke-static {v3, v0}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-static {v2}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    const-string v2, "0"

    .line 3
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    .line 4
    sget-object p1, Lc/b/a/a/l/b/b2;->a:Lc/b/a/a/l/b/b2;

    invoke-static {p1}, Landroid/os/AsyncTask;->execute(Ljava/lang/Runnable;)V

    return-void

    .line 5
    :cond_0
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getThemeUrl()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1

    return-void

    .line 6
    :cond_1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 7
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "theme_version"

    const-string v5, ""

    invoke-virtual {v2, v3, v5}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "/"

    .line 8
    invoke-static {v0, v3}, Ld/a/a/a/a;->C(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v5, p1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->themeVersion:Ljava/lang/String;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    new-array v1, v1, [Ljava/lang/Object;

    const-string v5, "app\u5f53\u524d\u7684\u4e3b\u9898\u7248\u672c\uff1a"

    const-string v6, "\u3001\u4e91\u7aef\u7684\u4e3b\u9898\u7248\u672c\uff1a"

    .line 9
    invoke-static {v5, v2, v6, v3}, Ld/a/a/a/a;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v1, v4

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    .line 10
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-lez v0, :cond_2

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2

    .line 11
    new-instance v0, Lc/b/a/a/l/b/h2;

    invoke-direct {v0, p0, p1, v3}, Lc/b/a/a/l/b/h2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;Ljava/lang/String;)V

    invoke-static {v0}, Landroid/os/AsyncTask;->execute(Ljava/lang/Runnable;)V

    :cond_2
    return-void
.end method

.method public final B(Ljava/util/List;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;",
            ">;)",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 3
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "MaxWidth"

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v1

    .line 4
    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    if-ge v3, v2, :cond_1

    .line 5
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getMinWidth()Ljava/lang/String;

    move-result-object v2

    .line 6
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_0

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    if-ge v2, v1, :cond_0

    .line 7
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public final C(Ljava/util/List;)Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;",
            ">;)",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    .line 2
    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    if-ge v1, v2, :cond_1

    .line 3
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->isPrivate()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 4
    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-object v0
.end method

.method public final D()Lcom/amap/api/location/AMapLocationClientOption;
    .locals 4

    .line 1
    new-instance v0, Lcom/amap/api/location/AMapLocationClientOption;

    invoke-direct {v0}, Lcom/amap/api/location/AMapLocationClientOption;-><init>()V

    .line 2
    sget-object v1, Lcom/amap/api/location/AMapLocationClientOption$AMapLocationMode;->Hight_Accuracy:Lcom/amap/api/location/AMapLocationClientOption$AMapLocationMode;

    invoke-virtual {v0, v1}, Lcom/amap/api/location/AMapLocationClientOption;->setLocationMode(Lcom/amap/api/location/AMapLocationClientOption$AMapLocationMode;)Lcom/amap/api/location/AMapLocationClientOption;

    const/4 v1, 0x0

    .line 3
    invoke-virtual {v0, v1}, Lcom/amap/api/location/AMapLocationClientOption;->setGpsFirst(Z)Lcom/amap/api/location/AMapLocationClientOption;

    const-wide/16 v2, 0x7530

    .line 4
    invoke-virtual {v0, v2, v3}, Lcom/amap/api/location/AMapLocationClientOption;->setHttpTimeOut(J)Lcom/amap/api/location/AMapLocationClientOption;

    const-wide/16 v2, 0x7d0

    .line 5
    invoke-virtual {v0, v2, v3}, Lcom/amap/api/location/AMapLocationClientOption;->setInterval(J)Lcom/amap/api/location/AMapLocationClientOption;

    const/4 v2, 0x1

    .line 6
    invoke-virtual {v0, v2}, Lcom/amap/api/location/AMapLocationClientOption;->setNeedAddress(Z)Lcom/amap/api/location/AMapLocationClientOption;

    .line 7
    invoke-virtual {v0, v2}, Lcom/amap/api/location/AMapLocationClientOption;->setOnceLocation(Z)Lcom/amap/api/location/AMapLocationClientOption;

    .line 8
    invoke-virtual {v0, v2}, Lcom/amap/api/location/AMapLocationClientOption;->setOnceLocationLatest(Z)Lcom/amap/api/location/AMapLocationClientOption;

    .line 9
    sget-object v3, Lcom/amap/api/location/AMapLocationClientOption$AMapLocationProtocol;->HTTP:Lcom/amap/api/location/AMapLocationClientOption$AMapLocationProtocol;

    invoke-static {v3}, Lcom/amap/api/location/AMapLocationClientOption;->setLocationProtocol(Lcom/amap/api/location/AMapLocationClientOption$AMapLocationProtocol;)V

    .line 10
    invoke-virtual {v0, v1}, Lcom/amap/api/location/AMapLocationClientOption;->setSensorEnable(Z)Lcom/amap/api/location/AMapLocationClientOption;

    .line 11
    invoke-virtual {v0, v2}, Lcom/amap/api/location/AMapLocationClientOption;->setWifiScan(Z)Lcom/amap/api/location/AMapLocationClientOption;

    .line 12
    invoke-virtual {v0, v1}, Lcom/amap/api/location/AMapLocationClientOption;->setLocationCacheEnable(Z)Lcom/amap/api/location/AMapLocationClientOption;

    .line 13
    sget-object v1, Lcom/amap/api/location/AMapLocationClientOption$GeoLanguage;->EN:Lcom/amap/api/location/AMapLocationClientOption$GeoLanguage;

    invoke-virtual {v0, v1}, Lcom/amap/api/location/AMapLocationClientOption;->setGeoLanguage(Lcom/amap/api/location/AMapLocationClientOption$GeoLanguage;)Lcom/amap/api/location/AMapLocationClientOption;

    return-object v0
.end method

.method public final E()V
    .locals 11

    .line 1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->F:Z

    const/16 v1, 0x8

    if-eqz v0, :cond_0

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->t:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_0

    .line 4
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->s:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 6
    :goto_0
    new-instance v0, Landroid/view/animation/TranslateAnimation;

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/high16 v10, 0x3f800000    # 1.0f

    move-object v2, v0

    invoke-direct/range {v2 .. v10}, Landroid/view/animation/TranslateAnimation;-><init>(IFIFIFIF)V

    const-wide/16 v1, 0x3e8

    .line 7
    invoke-virtual {v0, v1, v2}, Landroid/view/animation/TranslateAnimation;->setDuration(J)V

    .line 8
    new-instance v1, Lcn/upus/app/upprinting/ui/activity/MainActivity$d;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity$d;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/animation/TranslateAnimation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 9
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->h:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->setAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method

.method public final F(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/AdBean;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    .line 1
    :goto_0
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    if-ge v2, v3, :cond_2

    .line 2
    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/AdBean;

    .line 3
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->z:Lcn/upus/app/upprinting/data/bean/AdBean;

    if-nez v4, :cond_0

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/AdBean;->getType()Ljava/lang/String;

    move-result-object v4

    const-string v5, "T"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 4
    iput-object v3, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->z:Lcn/upus/app/upprinting/data/bean/AdBean;

    goto :goto_1

    :cond_0
    if-nez v1, :cond_1

    .line 5
    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/AdBean;->getType()Ljava/lang/String;

    move-result-object v4

    const-string v5, "L"

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    move-object v1, v3

    :cond_1
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    if-eqz v1, :cond_3

    .line 6
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->c:Landroidx/constraintlayout/widget/ConstraintLayout;

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 8
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->a:Lcom/youth/banner/Banner;

    invoke-virtual {p1, p0}, Lcom/youth/banner/Banner;->addBannerLifecycleObserver(Landroidx/lifecycle/LifecycleOwner;)Lcom/youth/banner/Banner;

    .line 10
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->a:Lcom/youth/banner/Banner;

    const-wide/16 v2, 0xbb8

    invoke-virtual {p1, v2, v3}, Lcom/youth/banner/Banner;->setLoopTime(J)Lcom/youth/banner/Banner;

    .line 12
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 13
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->a:Lcom/youth/banner/Banner;

    new-instance v0, Lcom/youth/banner/indicator/CircleIndicator;

    invoke-direct {v0, p0}, Lcom/youth/banner/indicator/CircleIndicator;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1, v0}, Lcom/youth/banner/Banner;->setIndicator(Lcom/youth/banner/indicator/Indicator;)Lcom/youth/banner/Banner;

    .line 14
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 15
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->a:Lcom/youth/banner/Banner;

    new-instance v0, Lcn/upus/app/upprinting/ui/activity/MainActivity$a;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/AdBean;->getImages()Ljava/util/List;

    move-result-object v2

    invoke-direct {v0, p0, v2, v1}, Lcn/upus/app/upprinting/ui/activity/MainActivity$a;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;Ljava/util/List;Lcn/upus/app/upprinting/data/bean/AdBean;)V

    invoke-virtual {p1, v0}, Lcom/youth/banner/Banner;->setAdapter(Lcom/youth/banner/adapter/BannerAdapter;)Lcom/youth/banner/Banner;

    goto :goto_2

    .line 16
    :cond_3
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->c:Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setVisibility(I)V

    :goto_2
    return-void
.end method

.method public final G()V
    .locals 15

    const-string v0, "cutBeforeCheck"

    .line 1
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "1"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    .line 2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 3
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "camera_show"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    const/16 v4, 0xb4

    .line 5
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "camera_angle"

    invoke-virtual {v1, v5, v4}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    :cond_0
    const-string v1, "material"

    .line 6
    invoke-static {v1}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 7
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/16 v1, 0x8

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    .line 8
    :goto_0
    iget-object v5, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v5, v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->t:Landroid/widget/TextView;

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 10
    iget-object v5, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v5, v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->s:Landroid/widget/TextView;

    invoke-virtual {v5, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 12
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 13
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "cutType"

    invoke-virtual {v1, v5, v3}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v1

    .line 14
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->N:I

    const-wide/16 v5, 0x0

    if-nez v1, :cond_2

    .line 15
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    .line 16
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    const-string v9, "cutEndTime"

    invoke-virtual {v1, v9, v7, v8}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v7

    .line 17
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 18
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->q:Landroid/widget/TextView;

    const-string v9, "yyyy-MM-dd"

    invoke-static {v7, v8, v9}, Lcom/blankj/utilcode/util/TimeUtils;->millis2String(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 19
    :cond_2
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v1

    iput-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    if-nez v1, :cond_3

    new-array v1, v3, [Ljava/lang/Object;

    const-string v7, "sharedDataBean is null:"

    .line 20
    invoke-static {v7}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    iget v8, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->N:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v1, v4

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    .line 21
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v1

    new-instance v14, Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    const-wide/16 v9, 0x0

    const-wide/16 v11, 0x0

    iget v13, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->N:I

    const-string v8, ""

    move-object v7, v14

    invoke-direct/range {v7 .. v13}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;-><init>(Ljava/lang/String;JJI)V

    iput-object v14, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    .line 22
    invoke-virtual {v1, v14}, Landroidx/lifecycle/LiveData;->setValue(Ljava/lang/Object;)V

    .line 23
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 24
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v7, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v1, v7}, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f(Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;)V

    .line 25
    :cond_3
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 26
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v7, "DEVNO"

    const-string v8, ""

    invoke-virtual {v1, v7, v8}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 27
    iget-object v7, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    invoke-virtual {v7, v1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setDevNo(Ljava/lang/String;)V

    .line 28
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    iget v7, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->N:I

    invoke-virtual {v1, v7}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setCutType(I)V

    .line 29
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 30
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v7, "monthlyShow"

    invoke-virtual {v1, v7, v8}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 31
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 32
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 33
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1, v7}, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->e(Ljava/lang/Boolean;)V

    goto :goto_1

    .line 34
    :cond_4
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 35
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v7}, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->e(Ljava/lang/Boolean;)V

    .line 36
    :goto_1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 37
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v7, "cutCountShow"

    invoke-virtual {v1, v7, v8}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v7, "0"

    .line 38
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_5

    .line 39
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 40
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v7}, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->b(Ljava/lang/Boolean;)V

    goto :goto_2

    .line 41
    :cond_5
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 42
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1, v7}, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->b(Ljava/lang/Boolean;)V

    .line 43
    :goto_2
    :try_start_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    const-string v7, "USEQTY"

    .line 44
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v1, v7, v8}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 45
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v7

    const-string v9, "BALAQTY"

    .line 46
    iget-object v7, v7, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v7, v9, v8}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 47
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_b

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v8, :cond_b

    .line 48
    :try_start_1
    invoke-static {v1}, Lc/b/a/a/k/a;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 49
    invoke-static {v7}, Lc/b/a/a/k/a;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_3

    :catch_0
    move-exception v8

    .line 50
    :try_start_2
    invoke-virtual {v8}, Ljava/lang/Exception;->printStackTrace()V

    .line 51
    :goto_3
    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    .line 52
    invoke-static {v7}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    .line 53
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_6

    .line 54
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v7

    if-lez v7, :cond_6

    .line 55
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v7

    int-to-long v12, v7

    add-long/2addr v8, v12

    .line 56
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    int-to-long v12, v1

    sub-long/2addr v10, v12

    .line 57
    :cond_6
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    invoke-virtual {v1, v8, v9}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setUseqty(J)V

    .line 58
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    const-wide v10, 0x1869f
    invoke-virtual {v1, v10, v11}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setBalaqty(J)V

    .line 59
    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->N:I

    if-ne v1, v3, :cond_a

    cmp-long v1, v10, v5

    if-lez v1, :cond_8

    const-wide/16 v5, 0xa

    cmp-long v3, v10, v5

    if-gez v3, :cond_8

    .line 60
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 61
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->u:Landroid/widget/TextView;

    const v3, 0x7f11020f

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(I)V

    .line 62
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    const/16 v0, 0x8

    goto :goto_4

    :cond_7
    const/4 v0, 0x0

    .line 63
    :goto_4
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 64
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->u:Landroid/widget/TextView;

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_5

    :cond_8
    if-gtz v1, :cond_9

    .line 65
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 66
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->u:Landroid/widget/TextView;

    const v1, 0x7f110210

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 67
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 68
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->u:Landroid/widget/TextView;

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_5

    .line 69
    :cond_9
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 70
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->u:Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_5

    .line 71
    :cond_a
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 72
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->u:Landroid/widget/TextView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_5

    :catch_1
    move-exception v0

    .line 73
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_b
    :goto_5
    return-void
.end method

.method public final H()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H:Z

    if-eqz v0, :cond_0

    return-void

    .line 2
    :cond_0
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->u:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0}, Lc/b/a/a/h/c/e;->S(Landroidx/lifecycle/MutableLiveData;)V

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->s:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0}, Lc/b/a/a/h/c/e;->a(Landroidx/lifecycle/MutableLiveData;)V

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->t:Landroidx/lifecycle/MutableLiveData;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->r:Landroidx/lifecycle/MutableLiveData;

    .line 6
    invoke-static {}, Lc/b/a/a/h/c/c;->d()Lc/b/a/a/h/c/c;

    move-result-object v2

    const-class v3, Lc/b/a/a/h/c/l;

    invoke-virtual {v2, v3}, Lc/b/a/a/h/c/c;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lc/b/a/a/h/c/l;

    invoke-interface {v2}, Lc/b/a/a/h/c/l;->j()Le/b/g;

    move-result-object v2

    .line 7
    sget-object v3, Le/b/u/a;->b:Le/b/l;

    .line 8
    invoke-virtual {v2, v3}, Le/b/g;->h(Le/b/l;)Le/b/g;

    move-result-object v2

    .line 9
    sget-object v3, Le/b/u/a;->b:Le/b/l;

    .line 10
    invoke-virtual {v2, v3}, Le/b/g;->d(Le/b/l;)Le/b/g;

    move-result-object v2

    new-instance v3, Lc/b/a/a/h/c/h;

    invoke-direct {v3, v0, v1}, Lc/b/a/a/h/c/h;-><init>(Landroidx/lifecycle/MutableLiveData;Landroidx/lifecycle/MutableLiveData;)V

    .line 11
    invoke-virtual {v2, v3}, Le/b/g;->a(Le/b/k;)V

    .line 12
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->x:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0}, Lc/b/a/a/h/c/e;->N(Landroidx/lifecycle/MutableLiveData;)V

    .line 13
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->y:Landroidx/lifecycle/MutableLiveData;

    if-nez v0, :cond_1

    .line 14
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->y:Landroidx/lifecycle/MutableLiveData;

    .line 15
    new-instance v1, Lc/b/a/a/l/b/f2;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/f2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 16
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->y:Landroidx/lifecycle/MutableLiveData;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lc/b/a/a/h/c/e;->k(Landroidx/lifecycle/MutableLiveData;Z)V

    :cond_2
    return-void
.end method

.method public final I(Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/NoticesBean;",
            ">;)V"
        }
    .end annotation

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-nez v0, :cond_0

    .line 2
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->j:Landroid/widget/LinearLayout;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/LinearLayout;->setVisibility(I)V

    return-void

    .line 4
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->j:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->b:Lcom/youth/banner/Banner;

    invoke-virtual {v0, p0}, Lcom/youth/banner/Banner;->addBannerLifecycleObserver(Landroidx/lifecycle/LifecycleOwner;)Lcom/youth/banner/Banner;

    .line 8
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->b:Lcom/youth/banner/Banner;

    const-wide/16 v2, 0xbb8

    invoke-virtual {v0, v2, v3}, Lcom/youth/banner/Banner;->setLoopTime(J)Lcom/youth/banner/Banner;

    .line 10
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->b:Lcom/youth/banner/Banner;

    new-instance v2, Lcn/upus/app/upprinting/ui/adapter/NoticesBannerAdapter;

    invoke-direct {v2, p1}, Lcn/upus/app/upprinting/ui/adapter/NoticesBannerAdapter;-><init>(Ljava/util/List;)V

    invoke-virtual {v0, v2}, Lcom/youth/banner/Banner;->setAdapter(Lcom/youth/banner/adapter/BannerAdapter;)Lcom/youth/banner/Banner;

    move-result-object p1

    const/4 v0, 0x1

    .line 12
    invoke-virtual {p1, v0}, Lcom/youth/banner/Banner;->setOrientation(I)Lcom/youth/banner/Banner;

    move-result-object p1

    .line 13
    invoke-virtual {p1, v1}, Lcom/youth/banner/Banner;->setUserInputEnabled(Z)Lcom/youth/banner/Banner;

    move-result-object p1

    new-instance v0, Lc/b/a/a/l/b/y1;

    invoke-direct {v0, p0}, Lc/b/a/a/l/b/y1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    .line 14
    invoke-virtual {p1, v0}, Lcom/youth/banner/Banner;->setOnBannerListener(Lcom/youth/banner/listener/OnBannerListener;)Lcom/youth/banner/Banner;

    return-void
.end method

.method public K(Lcn/upus/app/upprinting/data/bean/AdBean;)V
    .locals 2

    .line 1
    invoke-static {}, Li/b/a/c;->b()Li/b/a/c;

    move-result-object v0

    const-string v1, "main_touch"

    invoke-virtual {v0, v1}, Li/b/a/c;->f(Ljava/lang/Object;)V

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AdBean;->getRouterType()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AdBean;->getRouterType()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_1

    .line 4
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->u()V

    .line 5
    sget-object v0, Lc/b/a/a/m/a;->a:Lc/b/a/a/m/a;

    if-nez v0, :cond_0

    .line 6
    new-instance v0, Lc/b/a/a/m/a;

    invoke-direct {v0}, Lc/b/a/a/m/a;-><init>()V

    sput-object v0, Lc/b/a/a/m/a;->a:Lc/b/a/a/m/a;

    .line 7
    :cond_0
    sget-object v0, Lc/b/a/a/m/a;->a:Lc/b/a/a/m/a;

    .line 8
    invoke-virtual {v0, p0, p1}, Lc/b/a/a/m/a;->b(Landroid/content/Context;Lcn/upus/app/upprinting/data/bean/AdBean;)V

    :cond_1
    return-void
.end method

.method public synthetic L()V
    .locals 1

    const/4 v0, 0x1

    .line 1
    invoke-static {p0, v0}, Lcn/upus/app/upprinting/ui/activity/setting/DataUpdateActivity;->u(Landroid/content/Context;Z)V

    return-void
.end method

.method public synthetic N(Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;Ljava/lang/String;)V
    .locals 3

    .line 1
    sget-object v0, Lc/b/a/a/h/a;->c:Ljava/lang/String;

    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->delete(Ljava/lang/String;)Z

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getThemeUrl()Ljava/lang/String;

    move-result-object p1

    sget-object v0, Lc/b/a/a/h/a;->c:Ljava/lang/String;

    const-string v1, "theme.zip"

    invoke-static {p1, v0, v1}, Lc/b/a/a/h/c/e;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 3
    sget-object p1, Lc/b/a/a/h/a;->c:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v2, Lc/b/a/a/h/a;->c:Ljava/lang/String;

    invoke-static {v0, v2, v1}, Ld/a/a/a/a;->v(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/i6;

    invoke-direct {v1, p0, p2}, Lc/b/a/a/l/b/i6;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;Ljava/lang/String;)V

    invoke-static {p1, v0, v1}, Lc/b/a/a/m/k;->a(Ljava/lang/String;Ljava/lang/String;Lc/b/a/a/m/k$a;)V

    goto :goto_0

    :cond_0
    const p1, 0x7f110145

    .line 4
    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(I)V

    :goto_0
    return-void
.end method

.method public O(Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;)V
    .locals 4

    if-eqz p1, :cond_1

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "startResourceCode"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 4
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "startResourceVersion"

    invoke-virtual {v1, v3, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;->getCode()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;->getVersion()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 6
    :cond_0
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;->getDlUrl()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 7
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->i0(Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;)V

    :cond_1
    return-void
.end method

.method public S(Ljava/util/List;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->m:Lcn/upus/app/upprinting/view/EventSwipeRefreshLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setRefreshing(Z)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v2, "\u5f53\u524d\u4ea7\u54c1\u7c7b\u578b\u6570\u91cf\uff1a"

    .line 3
    invoke-static {v2}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-string v1, "categoryShow"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lc/b/a/a/m/f;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 5
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->C(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    .line 6
    :cond_0
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->B(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    .line 7
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-string v1, "second_agent_id"

    invoke-virtual {v0, v1, v2}, Lc/b/a/a/m/f;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "2555"

    .line 8
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    const-string v0, "ro.product.manufacturer"

    .line 9
    invoke-static {v0}, Lc/b/a/a/k/d;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "linksky"

    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    const-string v0, "/mnt/media_rw/USBDisk0"

    goto :goto_0

    :cond_1
    const-string v1, "rockchip"

    .line 11
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "/mnt/media_rw"

    goto :goto_0

    :cond_2
    const-string v0, "/mnt/usb_storage"

    .line 12
    :goto_0
    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 13
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v1}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_3

    invoke-virtual {v1}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_3

    invoke-virtual {v1}, Ljava/io/File;->list()[Ljava/lang/String;

    move-result-object v0

    array-length v0, v0

    if-lez v0, :cond_3

    .line 14
    new-instance v0, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-direct {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;-><init>()V

    const-string v1, "-888"

    .line 15
    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->setCategoryOneId(Ljava/lang/String;)V

    .line 16
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 17
    :cond_3
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 18
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    invoke-virtual {v0, p1}, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->d(Ljava/util/List;)V

    return-void
.end method

.method public synthetic T(Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;)V
    .locals 0

    if-eqz p1, :cond_1

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G()V

    .line 2
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->o()V

    .line 3
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->e()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 4
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->i()V

    goto :goto_0

    .line 5
    :cond_0
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->c()V

    :cond_1
    :goto_0
    return-void
.end method

.method public synthetic U(Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;)V
    .locals 0

    if-eqz p1, :cond_1

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G()V

    .line 2
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A(Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;)V

    .line 3
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->o()V

    .line 4
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->e()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 5
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->i()V

    goto :goto_0

    .line 6
    :cond_0
    invoke-static {}, Lcn/upus/app/upprinting/MApp;->b()Lcn/upus/app/upprinting/MApp;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->c()V

    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->M:Z

    .line 8
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->t()V

    return-void
.end method

.method public synthetic V(Lcn/upus/app/upprinting/data/bean/AppUpdateBean;)V
    .locals 1

    if-eqz p1, :cond_0

    const/4 v0, 0x1

    .line 1
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->I:Z

    .line 2
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l0(Lcn/upus/app/upprinting/data/bean/AppUpdateBean;)V

    goto :goto_0

    .line 3
    :cond_0
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->v()V

    :goto_0
    return-void
.end method

.method public synthetic W(Ljava/lang/Long;)V
    .locals 5

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "\u4e0a\u4e00\u6b21\u66f4\u65b0\u65f6\u95f4\uff1a"

    .line 1
    invoke-static {v1}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-static {v2, v3}, Lcom/blankj/utilcode/util/TimeUtils;->millis2String(J)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const-string v2, "ID_abnormal"

    invoke-virtual {v0, v2, v1}, Lc/b/a/a/m/f;->a(Ljava/lang/String;Ljava/lang/Boolean;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 3
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-string v1, "data_time"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lc/b/a/a/m/f;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 5
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    new-instance v3, Ljava/text/SimpleDateFormat;

    const-string v4, "yyyyMMddHHmm"

    invoke-direct {v3, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    invoke-static {v0, v3}, Lcom/blankj/utilcode/util/TimeUtils;->string2Millis(Ljava/lang/String;Ljava/text/DateFormat;)J

    move-result-wide v3

    sub-long/2addr v1, v3

    long-to-float v0, v1

    const v1, 0x4f1a7ec8    # 2.592E9f

    cmpl-float v0, v0, v1

    if-lez v0, :cond_0

    .line 6
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-wide/16 v1, 0x0

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "data_last_update_time"

    invoke-virtual {v0, v2, v1}, Lc/b/a/a/m/f;->b(Ljava/lang/String;Ljava/lang/Long;)J

    move-result-wide v0

    .line 7
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    sub-long/2addr v2, v0

    long-to-float p1, v2

    const v0, 0x4ca4cb80    # 8.64E7f

    cmpl-float p1, p1, v0

    if-lez p1, :cond_0

    .line 8
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->y()V

    :cond_0
    return-void
.end method

.method public synthetic X(Ljava/util/List;)V
    .locals 0

    if-eqz p1, :cond_0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->F(Ljava/util/List;)V

    :cond_0
    const/4 p1, 0x1

    .line 2
    iput-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->L:Z

    .line 3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->t()V

    return-void
.end method

.method public synthetic Y(Ljava/util/List;)V
    .locals 0

    if-eqz p1, :cond_0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->I(Ljava/util/List;)V

    :cond_0
    return-void
.end method

.method public synthetic Z(Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;)V
    .locals 1

    if-eqz p1, :cond_0

    .line 1
    sput-object p1, Lcn/upus/app/upprinting/MApp;->A:Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;

    .line 2
    new-instance v0, Lc/b/a/a/l/b/j2;

    invoke-direct {v0, p0, p1}, Lc/b/a/a/l/b/j2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;)V

    invoke-static {v0}, Landroid/os/AsyncTask;->execute(Ljava/lang/Runnable;)V

    :cond_0
    return-void
.end method

.method public a0(Ljava/lang/Object;I)V
    .locals 2

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "position\uff1a"

    .line 1
    invoke-static {v1, p2}, Ld/a/a/a/a;->e(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x0

    aput-object p2, v0, v1

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 2
    invoke-static {}, Li/b/a/c;->b()Li/b/a/c;

    move-result-object p2

    const-string v0, "main_touch"

    invoke-virtual {p2, v0}, Li/b/a/c;->f(Ljava/lang/Object;)V

    .line 3
    iget-object p2, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l:Ljava/lang/ref/WeakReference;

    if-eqz p2, :cond_1

    invoke-virtual {p2}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p2

    if-nez p2, :cond_0

    goto :goto_0

    .line 4
    :cond_0
    iget-object p2, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {p2}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;

    invoke-virtual {p2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 5
    :cond_1
    :goto_0
    new-instance p2, Ljava/lang/ref/WeakReference;

    new-instance v0, Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;

    invoke-direct {v0}, Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;-><init>()V

    invoke-direct {p2, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p2, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l:Ljava/lang/ref/WeakReference;

    .line 6
    :goto_1
    iget-object p2, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {p2}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;

    check-cast p1, Lcn/upus/app/upprinting/data/bean/NoticesBean;

    .line 7
    iput-object p1, p2, Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;->b:Lcn/upus/app/upprinting/data/bean/NoticesBean;

    .line 8
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p2

    const-string v0, "notice"

    invoke-virtual {p1, p2, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public b0()V
    .locals 3

    const-wide/16 v0, 0x1e

    .line 1
    invoke-static {v0, v1}, Lc/b/a/a/m/h;->a(J)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v2, "qaz \u67e5\u8be2\u6570\u636eMain2"

    aput-object v2, v0, v1

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->i()V

    .line 4
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H()V

    goto :goto_0

    .line 5
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->m:Lcn/upus/app/upprinting/view/EventSwipeRefreshLayout;

    invoke-virtual {v0, v1}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setRefreshing(Z)V

    :goto_0
    return-void
.end method

.method public synthetic c0(Ljava/lang/Long;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->j0()V

    .line 2
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result p1

    if-eqz p1, :cond_0

    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->J:Z

    if-nez p1, :cond_0

    const/4 p1, 0x1

    .line 3
    iput-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->J:Z

    .line 4
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H()V

    :cond_0
    return-void
.end method

.method public synthetic d0(Lcom/amap/api/location/AMapLocation;)V
    .locals 7

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p1, :cond_2

    .line 1
    new-instance v2, Ljava/lang/StringBuffer;

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    .line 2
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getErrorCode()I

    move-result v3

    const-string v4, "\n"

    if-nez v3, :cond_0

    const-string v3, "\u5b9a\u4f4d\u6210\u529f\n"

    .line 3
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 4
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5b9a\u4f4d\u7c7b\u578b: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLocationType()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 5
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u7ecf    \u5ea6    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLongitude()D

    move-result-wide v5

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 6
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u7eac    \u5ea6    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLatitude()D

    move-result-wide v5

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 7
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u7cbe    \u5ea6    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getAccuracy()F

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v5, "\u7c73\n"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 8
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u63d0\u4f9b\u8005    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getProvider()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 9
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u901f    \u5ea6    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getSpeed()F

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v5, "\u7c73/\u79d2\n"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 10
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u89d2    \u5ea6    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getBearing()F

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 11
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u661f    \u6570    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getSatellites()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 12
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u56fd    \u5bb6    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getCountry()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 13
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u7701            : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getProvince()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 14
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5e02            : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getCity()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 15
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u57ce\u5e02\u7f16\u7801 : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getCityCode()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 16
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u533a            : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getDistrict()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 17
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u533a\u57df \u7801   : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getAdCode()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 18
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5730    \u5740    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getAddress()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 19
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5174\u8da3\u70b9    : "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getPoiName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 20
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5b9a\u4f4d\u65f6\u95f4: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroid/location/Location;->getTime()J

    move-result-wide v5

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_0

    :cond_0
    const-string v3, "\u5b9a\u4f4d\u5931\u8d25\n"

    .line 21
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 22
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u9519\u8bef\u7801:"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getErrorCode()I

    move-result v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 23
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u9519\u8bef\u4fe1\u606f:"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getErrorInfo()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 24
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u9519\u8bef\u63cf\u8ff0:"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLocationDetail()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :goto_0
    const-string v3, "***\u5b9a\u4f4d\u8d28\u91cf\u62a5\u544a***"

    .line 25
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const-string v3, "* WIFI\u5f00\u5173\uff1a"

    .line 26
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLocationQualityReport()Lcom/amap/api/location/AMapLocationQualityReport;

    move-result-object v3

    invoke-virtual {v3}, Lcom/amap/api/location/AMapLocationQualityReport;->isWifiAble()Z

    move-result v3

    if-eqz v3, :cond_1

    const-string v3, "\u5f00\u542f"

    goto :goto_1

    :cond_1
    const-string v3, "\u5173\u95ed"

    :goto_1
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const-string v3, "* GPS\u72b6\u6001\uff1a"

    .line 27
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLocationQualityReport()Lcom/amap/api/location/AMapLocationQualityReport;

    move-result-object v3

    invoke-virtual {v3}, Lcom/amap/api/location/AMapLocationQualityReport;->getGPSStatus()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const-string v3, "* GPS\u661f\u6570\uff1a"

    .line 28
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLocationQualityReport()Lcom/amap/api/location/AMapLocationQualityReport;

    move-result-object v3

    invoke-virtual {v3}, Lcom/amap/api/location/AMapLocationQualityReport;->getGPSSatellites()I

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 29
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "* \u7f51\u7edc\u7c7b\u578b\uff1a"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLocationQualityReport()Lcom/amap/api/location/AMapLocationQualityReport;

    move-result-object v5

    invoke-virtual {v5}, Lcom/amap/api/location/AMapLocationQualityReport;->getNetworkType()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 30
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "* \u7f51\u7edc\u8017\u65f6\uff1a"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLocationQualityReport()Lcom/amap/api/location/AMapLocationQualityReport;

    move-result-object v5

    invoke-virtual {v5}, Lcom/amap/api/location/AMapLocationQualityReport;->getNetUseTime()J

    move-result-wide v5

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const-string v3, "****************"

    .line 31
    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 32
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u56de\u8c03\u65f6\u95f4: "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    invoke-virtual {v3, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 33
    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    new-array v1, v1, [Ljava/lang/Object;

    const-string v3, "\u5b9a\u4f4d\u4fe1\u606f\u5982\u4e0b\uff1a\n"

    .line 34
    invoke-static {v3, v2}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v0

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 35
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->k0(Lcom/amap/api/location/AMapLocation;)V

    goto :goto_2

    :cond_2
    new-array p1, v1, [Ljava/lang/Object;

    const-string v1, "\u5b9a\u4f4d\u5931\u8d25\uff0cloc is null"

    aput-object v1, p1, v0

    .line 36
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    :goto_2
    return-void
.end method

.method public synthetic e0(Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->z(Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;)V

    return-void
.end method

.method public synthetic f0(Ljava/lang/Long;)V
    .locals 4

    .line 1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->E:Z

    const/4 v1, 0x1

    if-nez v0, :cond_0

    .line 2
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->E:Z

    .line 3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->x()V

    :cond_0
    new-array v0, v1, [Ljava/lang/Object;

    const/4 v1, 0x0

    .line 4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "aLong:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v0, v1

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    return-void
.end method

.method public g()I
    .locals 1

    const v0, 0x7f0c008f

    return v0
.end method

.method public g0(Lcn/upus/app/upprinting/data/bean/AppUpdateBean;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->o:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->o:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;->dismiss()V

    goto :goto_1

    .line 3
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->o:Ljava/lang/ref/WeakReference;

    .line 4
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->o:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;

    .line 5
    iput-object p1, v0, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;->b:Lcn/upus/app/upprinting/data/bean/AppUpdateBean;

    .line 6
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->o:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "forcedUpdate"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public h0(Ljava/lang/Long;)V
    .locals 11

    .line 1
    iget p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->N:I

    if-nez p1, :cond_0

    .line 2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    const-wide/16 v0, 0x0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    .line 3
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const-string v2, "cutCurrentTime"

    invoke-virtual {p1, v2, v0, v1}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v0

    const-wide/32 v3, 0xea60

    add-long/2addr v0, v3

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    .line 5
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {p1, v2, v0, v1}, Lcom/tencent/mmkv/MMKV;->f(Ljava/lang/String;J)Z

    .line 6
    :cond_0
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result p1

    if-eqz p1, :cond_8

    .line 7
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_7

    .line 8
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_7

    .line 9
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    move-object v10, p1

    check-cast v10, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    .line 10
    invoke-virtual {v10}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;->getJson()Ljava/lang/String;

    move-result-object p1

    .line 11
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "partno"

    .line 12
    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const-string v3, ""

    if-eqz v2, :cond_1

    .line 13
    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    move-object v2, v3

    goto :goto_0

    :cond_1
    const-string p1, "productId"

    .line 14
    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    move-object v2, p1

    move-object p1, v3

    :goto_0
    const-string v4, "remark"

    .line 15
    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_2

    .line 16
    invoke-virtual {v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_1

    :cond_2
    move-object v4, v3

    :goto_1
    const-string v5, "uuid"

    .line 17
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_3

    .line 18
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_2

    :cond_3
    move-object v5, v3

    :goto_2
    const-string v6, "packageType"

    .line 19
    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_4

    .line 20
    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_3

    :cond_4
    move-object v6, v3

    :goto_3
    const-string v7, "feedBack"

    .line 21
    invoke-virtual {v1, v7}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_5

    .line 22
    invoke-virtual {v1, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_4

    :cond_5
    move-object v7, v3

    :goto_4
    const-string v8, "materialId"

    .line 23
    invoke-virtual {v1, v8}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_6

    .line 24
    invoke-virtual {v1, v8}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object v8, v1

    goto :goto_5

    :cond_6
    move-object v8, v3

    :goto_5
    const/4 v9, 0x0

    const-string v1, "off"

    move-object v3, p1

    .line 25
    invoke-static/range {v1 .. v10}, Lc/b/a/a/h/c/e;->g(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)V

    .line 26
    :cond_7
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 27
    :try_start_0
    invoke-static {}, Lc/b/a/a/h/b/a;->a()Lc/b/a/a/h/b/a;

    move-result-object v1

    .line 28
    iget-object v1, v1, Lc/b/a/a/h/b/a;->b:Lc/b/a/a/h/b/d/b;

    .line 29
    iget-object v1, v1, Lc/b/a/a/h/b/d/b;->h:Lcn/upus/app/upprinting/data/db/dao/OfflinePrintBeanDao;

    .line 30
    invoke-virtual {v1}, Lorg/greenrobot/greendao/AbstractDao;->queryBuilder()Lorg/greenrobot/greendao/query/QueryBuilder;

    move-result-object v1

    invoke-virtual {v1}, Lorg/greenrobot/greendao/query/QueryBuilder;->list()Ljava/util/List;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_6

    :catch_0
    move-exception v1

    .line 31
    invoke-virtual {v1}, Ljava/lang/Exception;->printStackTrace()V

    const/4 v1, 0x0

    .line 32
    :goto_6
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 33
    :goto_7
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_8

    .line 34
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;

    .line 35
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getPrinterSerialNum()Ljava/lang/String;

    move-result-object v2

    .line 36
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getPrinterBrand()Ljava/lang/String;

    move-result-object v3

    .line 37
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getPrinterModel()Ljava/lang/String;

    move-result-object v4

    .line 38
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getPrinterState()Ljava/lang/String;

    move-result-object v5

    .line 39
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getImageMd5Hex()Ljava/lang/String;

    move-result-object v6

    .line 40
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getUuid()Ljava/lang/String;

    move-result-object v7

    .line 41
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getProductId()Ljava/lang/String;

    move-result-object v8

    .line 42
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getRemark()Ljava/lang/String;

    move-result-object v9

    .line 43
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/OfflinePrintBean;->getMoreInfo()Ljava/lang/String;

    move-result-object v10

    .line 44
    invoke-static/range {v2 .. v10}, Lc/b/a/a/h/c/e;->Q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    :cond_8
    return-void
.end method

.method public final i0(Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->p:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;->dismiss()V

    goto :goto_1

    .line 3
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->p:Ljava/lang/ref/WeakReference;

    .line 4
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;

    .line 5
    iput-object p1, v0, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;->c:Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;

    .line 6
    iget-object v0, v0, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;->d:Lcom/youth/banner/adapter/BannerImageAdapter;

    if-eqz v0, :cond_2

    .line 7
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AnimationConfigBean;->getImages()Ljava/util/List;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/youth/banner/adapter/BannerAdapter;->setDatas(Ljava/util/List;)V

    .line 8
    :cond_2
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "animationDialog"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public final j0()V
    .locals 4

    .line 1
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v0

    const v1, 0x7f0800e3

    if-eqz v0, :cond_7

    .line 2
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->getNetworkType()Lcom/blankj/utilcode/util/NetworkUtils$NetworkType;

    move-result-object v0

    sget-object v2, Lcom/blankj/utilcode/util/NetworkUtils$NetworkType;->NETWORK_ETHERNET:Lcom/blankj/utilcode/util/NetworkUtils$NetworkType;

    if-ne v0, v2, :cond_0

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0800e2

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto/16 :goto_0

    .line 5
    :cond_0
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->getNetworkType()Lcom/blankj/utilcode/util/NetworkUtils$NetworkType;

    move-result-object v0

    sget-object v2, Lcom/blankj/utilcode/util/NetworkUtils$NetworkType;->NETWORK_WIFI:Lcom/blankj/utilcode/util/NetworkUtils$NetworkType;

    if-ne v0, v2, :cond_6

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->D:Landroid/net/wifi/WifiManager;

    if-nez v0, :cond_1

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void

    .line 9
    :cond_1
    invoke-virtual {v0}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    move-result-object v0

    .line 10
    invoke-virtual {v0}, Landroid/net/wifi/WifiInfo;->getRssi()I

    move-result v0

    const/16 v2, -0x32

    if-gtz v0, :cond_2

    if-lt v0, v2, :cond_2

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0800e1

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto/16 :goto_0

    :cond_2
    const/16 v3, -0x46

    if-ge v0, v2, :cond_3

    if-lt v0, v3, :cond_3

    .line 13
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 14
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0800df

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :cond_3
    const/16 v2, -0x50

    if-ge v0, v3, :cond_4

    if-lt v0, v2, :cond_4

    .line 15
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 16
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0800de

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    :cond_4
    if-ge v0, v2, :cond_5

    const/16 v2, -0x64

    if-lt v0, v2, :cond_5

    .line 17
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 18
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0800dd

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    .line 19
    :cond_5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 20
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    .line 21
    :cond_6
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 22
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0800e0

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_0

    .line 23
    :cond_7
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 24
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 25
    :goto_0
    sget-object v0, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    if-eqz v0, :cond_8

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getMainBarImgLeftColor()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_8

    .line 26
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 27
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    invoke-virtual {v0}, Landroid/widget/ImageButton;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    sget-object v1, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getMainBarImgLeftColor()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    :cond_8
    return-void
.end method

.method public final k0(Lcom/amap/api/location/AMapLocation;)V
    .locals 13

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    sget-object v1, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "sessionId"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getAddress()Ljava/lang/String;

    move-result-object v4

    .line 4
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getCity()Ljava/lang/String;

    move-result-object v5

    .line 5
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getCityCode()Ljava/lang/String;

    move-result-object v6

    .line 6
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getCountry()Ljava/lang/String;

    move-result-object v7

    .line 7
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getProvince()Ljava/lang/String;

    move-result-object v8

    .line 8
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getDistrict()Ljava/lang/String;

    move-result-object v9

    .line 9
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getAdCode()Ljava/lang/String;

    move-result-object v10

    .line 10
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLatitude()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object v11

    .line 11
    invoke-virtual {p1}, Lcom/amap/api/location/AMapLocation;->getLongitude()D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object v12

    const/4 p1, 0x1

    new-array v0, p1, [Ljava/lang/Object;

    const/4 v1, 0x0

    const-string v2, "\u4e0a\u62a5\u7684\u7528\u6237\u5f53\u524d\u5730\u7406\u4f4d\u7f6e\u4fe1\u606f\u5982\u4e0b\uff1a"

    aput-object v2, v0, v1

    .line 12
    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    new-array p1, p1, [Ljava/lang/Object;

    .line 13
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u5730\u5740\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u57ce\u5e02\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u57ce\u5e02\u7f16\u7801\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u56fd\u5bb6\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u7701\u4efd\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u533a\u53bf\u9547\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u533a\u53bf\u9547\u7f16\u53f7\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u7eac\u5ea6\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\n\u7ecf\u5ea6\uff1a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    aput-object v0, p1, v1

    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 14
    invoke-static/range {v3 .. v12}, Lc/b/a/a/h/c/e;->R(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public l()V
    .locals 9

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v2, 0x0

    const-string v3, "TEST BD:33,0,0,0,1;"

    aput-object v3, v1, v2

    .line 1
    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const-string v1, "BD:33,0,0,0,1;"

    .line 2
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    .line 3
    invoke-virtual {p0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 5
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "MaxWidth"

    invoke-virtual {v1, v3, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v1

    const/16 v3, 0xc8

    const/4 v4, 0x3

    if-le v1, v3, :cond_0

    .line 6
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 7
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "Brightness"

    invoke-virtual {v1, v3, v4}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v1

    .line 8
    invoke-static {v1}, Lc/b/a/a/k/a;->z(I)[B

    move-result-object v1

    invoke-virtual {p0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e([B)V

    .line 9
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 10
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "IS_Print"

    invoke-virtual {v1, v3, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 11
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 12
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "Print_Sel_Type"

    invoke-virtual {v1, v5, v0}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    .line 13
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 14
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v1, v3}, Lcom/tencent/mmkv/MMKV;->o(Ljava/lang/String;)V

    .line 15
    :cond_1
    new-instance v1, Landroidx/lifecycle/ViewModelProvider;

    new-instance v3, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;

    invoke-direct {v3}, Landroidx/lifecycle/ViewModelProvider$NewInstanceFactory;-><init>()V

    invoke-direct {v1, p0, v3}, Landroidx/lifecycle/ViewModelProvider;-><init>(Landroidx/lifecycle/ViewModelStoreOwner;Landroidx/lifecycle/ViewModelProvider$Factory;)V

    const-class v3, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    invoke-virtual {v1, v3}, Landroidx/lifecycle/ViewModelProvider;->get(Ljava/lang/Class;)Landroidx/lifecycle/ViewModel;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    .line 16
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->f:Landroid/widget/ImageButton;

    new-instance v3, Lc/b/a/a/l/b/j6;

    invoke-direct {v3, p0}, Lc/b/a/a/l/b/j6;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 18
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 19
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->e:Landroid/widget/ImageButton;

    new-instance v3, Lc/b/a/a/l/b/k6;

    invoke-direct {v3, p0}, Lc/b/a/a/l/b/k6;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 20
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 21
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->t:Landroid/widget/TextView;

    new-instance v3, Lc/b/a/a/l/b/l6;

    invoke-direct {v3, p0}, Lc/b/a/a/l/b/l6;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 22
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 23
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->s:Landroid/widget/TextView;

    new-instance v3, Lc/b/a/a/l/b/m6;

    invoke-direct {v3, p0}, Lc/b/a/a/l/b/m6;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 24
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 25
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, p0}, Landroid/view/ViewGroup;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 26
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isLandscape()Z

    move-result v1

    if-eqz v1, :cond_2

    .line 27
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 28
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->d:Landroid/widget/ImageButton;

    new-instance v3, Lc/b/a/a/l/b/n6;

    invoke-direct {v3, p0}, Lc/b/a/a/l/b/n6;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 29
    :cond_2
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v1

    const/4 v3, 0x2

    if-eqz v1, :cond_4

    .line 30
    sget-object v1, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    if-eqz v1, :cond_3

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getRvType()I

    move-result v1

    if-ne v1, v0, :cond_3

    .line 31
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 32
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v5, Landroidx/recyclerview/widget/GridLayoutManager;

    invoke-direct {v5, p0, v3}, Landroidx/recyclerview/widget/GridLayoutManager;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 33
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 34
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v5, Lcn/upus/app/upprinting/ui/adapter/MainTypeGridAdapter;

    invoke-direct {v5, p0}, Lcn/upus/app/upprinting/ui/adapter/MainTypeGridAdapter;-><init>(Landroidx/fragment/app/FragmentActivity;)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    goto :goto_0

    .line 35
    :cond_3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 36
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v5, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v5, p0, v0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 37
    new-instance v1, Lcn/upus/app/upprinting/util/LinearDividerItemDecoration;

    invoke-direct {v1, p0, v0}, Lcn/upus/app/upprinting/util/LinearDividerItemDecoration;-><init>(Landroid/content/Context;I)V

    .line 38
    invoke-virtual {v1, v2, v4}, Lcn/upus/app/upprinting/util/LinearDividerItemDecoration;->a(II)V

    .line 39
    iget-object v5, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 40
    check-cast v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v5, v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v5, v1}, Landroidx/recyclerview/widget/RecyclerView;->addItemDecoration(Landroidx/recyclerview/widget/RecyclerView$ItemDecoration;)V

    .line 41
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 42
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v5, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    invoke-direct {v5, p0}, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;-><init>(Landroidx/fragment/app/FragmentActivity;)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    goto :goto_0

    .line 43
    :cond_4
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 44
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v5, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v5, p0, v2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 45
    sget-object v1, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    if-eqz v1, :cond_5

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getRvType()I

    move-result v1

    if-ne v1, v0, :cond_5

    .line 46
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 47
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v5, Lcn/upus/app/upprinting/ui/adapter/MainTypeGridAdapter;

    invoke-direct {v5, p0}, Lcn/upus/app/upprinting/ui/adapter/MainTypeGridAdapter;-><init>(Landroidx/fragment/app/FragmentActivity;)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    goto :goto_0

    .line 48
    :cond_5
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 49
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v5, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    invoke-direct {v5, p0}, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;-><init>(Landroidx/fragment/app/FragmentActivity;)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 50
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 51
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/16 v5, 0x14

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setItemViewCacheSize(I)V

    .line 52
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 53
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->setDrawingCacheEnabled(Z)V

    .line 54
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 55
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->l:Landroidx/recyclerview/widget/RecyclerView;

    const/high16 v5, 0x100000

    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->setDrawingCacheQuality(I)V

    .line 56
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 57
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->n:Lcn/upus/app/upprinting/view/MaxHeightRecycler;

    new-instance v5, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v5, p0, v2, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 58
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 59
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->n:Lcn/upus/app/upprinting/view/MaxHeightRecycler;

    new-instance v5, Lcn/upus/app/upprinting/ui/adapter/CutHistoryAdapter;

    invoke-direct {v5}, Lcn/upus/app/upprinting/ui/adapter/CutHistoryAdapter;-><init>()V

    invoke-virtual {v1, v5}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 60
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    const/4 v5, 0x0

    .line 61
    iput-object v5, v1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->b:Landroidx/lifecycle/MutableLiveData;

    .line 62
    iput-object v5, v1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->c:Landroidx/lifecycle/MutableLiveData;

    .line 63
    new-instance v5, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v5}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v5, v1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->b:Landroidx/lifecycle/MutableLiveData;

    .line 64
    new-instance v5, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v5}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v5, v1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->c:Landroidx/lifecycle/MutableLiveData;

    .line 65
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    const-string v5, ""

    invoke-virtual {v1, v5, v0, v5, v5}, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->l(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Landroidx/lifecycle/MediatorLiveData;

    move-result-object v1

    new-instance v5, Lc/b/a/a/l/b/s1;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/s1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 66
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->w:Landroidx/lifecycle/MutableLiveData;

    .line 67
    new-instance v5, Lc/b/a/a/l/b/w1;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/w1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 68
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->u:Landroidx/lifecycle/MutableLiveData;

    .line 69
    new-instance v5, Lc/b/a/a/l/b/t1;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/t1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 70
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->v:Landroidx/lifecycle/MutableLiveData;

    .line 71
    new-instance v5, Lc/b/a/a/l/b/e2;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/e2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 72
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->r:Landroidx/lifecycle/MutableLiveData;

    .line 73
    new-instance v5, Lc/b/a/a/l/b/d2;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/d2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 74
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->s:Landroidx/lifecycle/MutableLiveData;

    .line 75
    new-instance v5, Lc/b/a/a/l/b/x1;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/x1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 76
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->t:Landroidx/lifecycle/MutableLiveData;

    .line 77
    new-instance v5, Lc/b/a/a/l/b/a2;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/a2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 78
    new-instance v1, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v1}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->x:Landroidx/lifecycle/MutableLiveData;

    .line 79
    new-instance v5, Lc/b/a/a/l/b/z1;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/z1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, p0, v5}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    const-wide/16 v5, 0xf

    .line 80
    invoke-static {v5, v6}, Lc/b/a/a/m/h;->a(J)Z

    new-array v1, v0, [Ljava/lang/Object;

    const-string v5, "qaz \u67e5\u8be2\u6570\u636eMain1"

    aput-object v5, v1, v2

    .line 81
    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 82
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->i()V

    .line 83
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v1

    if-nez v1, :cond_7

    .line 84
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->s:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v1}, Lc/b/a/a/h/c/e;->a(Landroidx/lifecycle/MutableLiveData;)V

    .line 85
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->x:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v1}, Lc/b/a/a/h/c/e;->N(Landroidx/lifecycle/MutableLiveData;)V

    .line 86
    sget-object v1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 87
    invoke-virtual {v1}, Lcn/upus/app/upprinting/MApp;->o()V

    .line 88
    sget-object v1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 89
    invoke-virtual {v1}, Lcn/upus/app/upprinting/MApp;->e()Z

    move-result v1

    if-eqz v1, :cond_6

    .line 90
    sget-object v1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 91
    invoke-virtual {v1}, Lcn/upus/app/upprinting/MApp;->i()V

    goto :goto_1

    .line 92
    :cond_6
    sget-object v1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 93
    invoke-virtual {v1}, Lcn/upus/app/upprinting/MApp;->c()V

    .line 94
    :cond_7
    :goto_1
    invoke-virtual {p0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const-string v5, "wifi"

    invoke-virtual {v1, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/net/wifi/WifiManager;

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->D:Landroid/net/wifi/WifiManager;

    .line 95
    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x5

    invoke-static {v5, v6, v7, v8, v1}, Le/b/g;->c(JJLjava/util/concurrent/TimeUnit;)Le/b/g;

    move-result-object v1

    .line 96
    invoke-static {}, Le/b/o/a/a;->a()Le/b/l;

    move-result-object v5

    invoke-virtual {v1, v5}, Le/b/g;->d(Le/b/l;)Le/b/g;

    move-result-object v1

    new-instance v5, Lc/b/a/a/l/b/g2;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/g2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    .line 97
    sget-object v6, Le/b/s/b/a;->d:Le/b/r/e;

    sget-object v7, Le/b/s/b/a;->b:Le/b/r/a;

    .line 98
    sget-object v8, Le/b/s/b/a;->c:Le/b/r/e;

    .line 99
    invoke-virtual {v1, v5, v6, v7, v8}, Le/b/g;->f(Le/b/r/e;Le/b/r/e;Le/b/r/a;Le/b/r/e;)Le/b/p/b;

    move-result-object v1

    .line 100
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->C:Le/b/p/b;

    .line 101
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G()V

    .line 102
    invoke-static {}, Lcom/epson/isv/eprinterdriver/Ctrl/EPrintManager;->instance()Lcom/epson/isv/eprinterdriver/Ctrl/EPrintManager;

    move-result-object v1

    invoke-virtual {p0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v1, v5}, Lcom/epson/isv/eprinterdriver/Ctrl/EPrintManager;->initEscprLib(Landroid/content/Context;)I

    .line 103
    sget-object v1, Lc/b/a/a/h/a;->h:Ljava/util/HashMap;

    const-string v5, "L3150 Series"

    const-string v6, "1,-0.5,-2.5,0"

    invoke-virtual {v1, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    sget-object v1, Lc/b/a/a/h/a;->h:Ljava/util/HashMap;

    const-string v5, "L805 Series"

    const-string v6, "0,-8.5,-3.0,-10.15"

    invoke-virtual {v1, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 105
    sget-object v1, Lc/b/a/a/h/a;->h:Ljava/util/HashMap;

    const-string v5, "XP-6100 Series"

    const-string v6, "0,-2.0,-3.0,0"

    invoke-virtual {v1, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 106
    sget-object v1, Lc/b/a/a/h/a;->h:Ljava/util/HashMap;

    const-string v5, "ET-8500 Series"

    const-string v6, "0,-4.0,-2.0,0"

    invoke-virtual {v1, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    invoke-static {}, Lc/b/a/a/j/d/a0/b;->a()Lc/b/a/a/j/d/a0/b;

    move-result-object v1

    .line 108
    iget-object v5, v1, Lc/b/a/a/j/d/a0/b;->a:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 109
    new-instance v5, Ljava/lang/Thread;

    new-instance v6, Lc/b/a/a/j/d/a0/a;

    invoke-direct {v6, v1}, Lc/b/a/a/j/d/a0/a;-><init>(Lc/b/a/a/j/d/a0/b;)V

    invoke-direct {v5, v6}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 110
    invoke-virtual {v5}, Ljava/lang/Thread;->start()V

    .line 111
    invoke-static {}, Lc/b/a/a/j/d/z/d;->a()Lc/b/a/a/j/d/z/d;

    move-result-object v1

    .line 112
    iget-object v5, v1, Lc/b/a/a/j/d/z/d;->a:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->clear()V

    .line 113
    sget-object v5, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 114
    new-instance v6, Lc/b/a/a/j/d/z/c;

    invoke-direct {v6, v1}, Lc/b/a/a/j/d/z/c;-><init>(Lc/b/a/a/j/d/z/d;)V

    invoke-static {v5, v6}, Ljp/co/canon/android/print/ij/sdk/CanonPrintDeviceBase;->g(Landroid/content/Context;Lf/a/a/a/a/a/c/a;)Z

    .line 115
    invoke-static {p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v1

    .line 116
    iget-object v5, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 117
    check-cast v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v5, v5, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->m:Lcn/upus/app/upprinting/view/EventSwipeRefreshLayout;

    new-array v4, v4, [I

    aput v1, v4, v2

    const/high16 v1, -0x10000

    aput v1, v4, v0

    const v1, -0xff0100

    aput v1, v4, v3

    invoke-virtual {v5, v4}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setColorSchemeColors([I)V

    .line 118
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 119
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->m:Lcn/upus/app/upprinting/view/EventSwipeRefreshLayout;

    new-instance v2, Lc/b/a/a/l/b/i2;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/i2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v1, v2}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setOnRefreshListener(Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout$OnRefreshListener;)V

    .line 120
    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v2, 0x3c

    invoke-static {v2, v3, v2, v3, v1}, Le/b/g;->c(JJLjava/util/concurrent/TimeUnit;)Le/b/g;

    move-result-object v1

    new-instance v2, Lc/b/a/a/l/b/m2;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/m2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    .line 121
    sget-object v3, Le/b/s/b/a;->d:Le/b/r/e;

    sget-object v4, Le/b/s/b/a;->b:Le/b/r/a;

    .line 122
    sget-object v5, Le/b/s/b/a;->c:Le/b/r/e;

    .line 123
    invoke-virtual {v1, v2, v3, v4, v5}, Le/b/g;->f(Le/b/r/e;Le/b/r/e;Le/b/r/a;Le/b/r/e;)Le/b/p/b;

    move-result-object v1

    .line 124
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->B:Le/b/p/b;

    .line 125
    :try_start_0
    invoke-static {p0, v0, v0}, Lcom/amap/api/location/AMapLocationClient;->updatePrivacyShow(Landroid/content/Context;ZZ)V

    .line 126
    invoke-static {p0, v0}, Lcom/amap/api/location/AMapLocationClient;->updatePrivacyAgree(Landroid/content/Context;Z)V

    .line 127
    new-instance v0, Lcom/amap/api/location/AMapLocationClient;

    invoke-virtual {p0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/amap/api/location/AMapLocationClient;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    .line 128
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->D()Lcom/amap/api/location/AMapLocationClientOption;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->P:Lcom/amap/api/location/AMapLocationClientOption;

    .line 129
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    invoke-virtual {v1, v0}, Lcom/amap/api/location/AMapLocationClient;->setLocationOption(Lcom/amap/api/location/AMapLocationClientOption;)V

    .line 130
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->R:Lcom/amap/api/location/AMapLocationListener;

    invoke-virtual {v0, v1}, Lcom/amap/api/location/AMapLocationClient;->setLocationListener(Lcom/amap/api/location/AMapLocationListener;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :catch_0
    move-exception v0

    .line 131
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 132
    :goto_2
    :try_start_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->P:Lcom/amap/api/location/AMapLocationClientOption;

    invoke-virtual {v0, v1}, Lcom/amap/api/location/AMapLocationClient;->setLocationOption(Lcom/amap/api/location/AMapLocationClientOption;)V

    .line 133
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    invoke-virtual {v0}, Lcom/amap/api/location/AMapLocationClient;->startLocation()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_3

    :catch_1
    move-exception v0

    .line 134
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_3
    return-void
.end method

.method public final l0(Lcn/upus/app/upprinting/data/bean/AppUpdateBean;)V
    .locals 4

    .line 1
    sget-object v0, Lcn/upus/app/upprinting/MApp;->C:Ljava/lang/String;

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AppUpdateBean;->getAppVersion()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AppUpdateBean;->getBinVersion()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 4
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "update_mark"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    .line 6
    const-class v2, Ljava/util/HashMap;

    invoke-static {v1, v2}, Lcom/blankj/utilcode/util/GsonUtils;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/HashMap;

    .line 7
    invoke-virtual {v1, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_1

    .line 8
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->v()V

    return-void

    .line 9
    :cond_1
    invoke-static {}, Lcom/blankj/utilcode/util/AppUtils;->getAppVersionCode()I

    move-result v0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/AppUpdateBean;->getAppVersion()I

    move-result v1

    if-lt v0, v1, :cond_2

    return-void

    .line 10
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_3

    goto :goto_1

    .line 11
    :cond_3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_2

    .line 12
    :cond_4
    :goto_1
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    .line 13
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;

    new-instance v1, Lc/b/a/a/l/b/u1;

    invoke-direct {v1, p0, p1}, Lc/b/a/a/l/b/u1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;Lcn/upus/app/upprinting/data/bean/AppUpdateBean;)V

    .line 14
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;->c:Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog$b;

    .line 15
    :goto_2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;

    .line 16
    iput-object p1, v0, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;->b:Lcn/upus/app/upprinting/data/bean/AppUpdateBean;

    .line 17
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "updateTip"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public onDestroy()V
    .locals 2

    .line 1
    invoke-static {}, Lc/b/a/a/j/d/z/d;->a()Lc/b/a/a/j/d/z/d;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/j/d/z/d;->a:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 3
    invoke-static {}, Ljp/co/canon/android/print/ij/sdk/CanonPrintDeviceBase;->h()Z

    .line 4
    invoke-static {}, Lcom/epson/isv/eprinterdriver/Ctrl/EPrintManager;->instance()Lcom/epson/isv/eprinterdriver/Ctrl/EPrintManager;

    move-result-object v0

    invoke-virtual {p0}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/epson/isv/eprinterdriver/Ctrl/EPrintManager;->releaseEscprLib(Landroid/content/Context;)I

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 6
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->onCleared()V

    .line 7
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    .line 8
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->k:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 9
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->k:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/QRCodeDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/QRCodeDialog;->dismiss()V

    .line 10
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    .line 12
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->o:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_3

    .line 13
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->o:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/ForcedUpdateDialog;->dismiss()V

    .line 14
    :cond_3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->u()V

    .line 15
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 16
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/NoticeDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    .line 17
    :cond_4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->p:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_5

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_5

    .line 18
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->p:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/BootAnimationDownloadDialog;->dismiss()V

    .line 19
    :cond_5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->C:Le/b/p/b;

    if-eqz v0, :cond_6

    invoke-interface {v0}, Le/b/p/b;->isDisposed()Z

    move-result v0

    if-nez v0, :cond_6

    .line 20
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->C:Le/b/p/b;

    invoke-interface {v0}, Le/b/p/b;->dispose()V

    .line 21
    :cond_6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->B:Le/b/p/b;

    if-eqz v0, :cond_7

    invoke-interface {v0}, Le/b/p/b;->isDisposed()Z

    move-result v0

    if-nez v0, :cond_7

    .line 22
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->B:Le/b/p/b;

    invoke-interface {v0}, Le/b/p/b;->dispose()V

    .line 23
    :cond_7
    :try_start_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->q:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_8

    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->q:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_8

    .line 24
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->q:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 25
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 26
    :cond_8
    :goto_0
    :try_start_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    invoke-virtual {v0}, Lcom/amap/api/location/AMapLocationClient;->stopLocation()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    move-exception v0

    .line 27
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 28
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    if-eqz v0, :cond_9

    .line 29
    invoke-virtual {v0}, Lcom/amap/api/location/AMapLocationClient;->onDestroy()V

    .line 30
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->O:Lcom/amap/api/location/AMapLocationClient;

    .line 31
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->P:Lcom/amap/api/location/AMapLocationClientOption;

    .line 32
    :cond_9
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onDestroy()V

    return-void
.end method

.method public onEvent(Ljava/lang/String;)V
    .locals 3
    .annotation runtime Li/b/a/k;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    const-string v0, "main_touch"

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    .line 2
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isLandscape()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 3
    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->E:Z

    if-eqz p1, :cond_0

    .line 4
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->E:Z

    .line 5
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->w()V

    :cond_0
    return-void

    .line 6
    :cond_1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->J:Z

    if-eqz v0, :cond_5

    const-string v0, "classifyDBData Null"

    .line 7
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 8
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    .line 9
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v0, "categoryShow"

    const-string v2, ""

    invoke-virtual {p1, v0, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "1"

    .line 10
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 11
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H:Z

    .line 12
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->a:Ljava/lang/String;

    .line 13
    iget-object p1, p1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->c:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0, p1}, Lc/b/a/a/h/c/e;->d(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    goto :goto_0

    .line 14
    :cond_2
    sget-boolean p1, Lcn/upus/app/upprinting/MApp;->G:Z

    if-eqz p1, :cond_3

    .line 15
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H:Z

    .line 16
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->a:Ljava/lang/String;

    .line 17
    iget-object p1, p1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->c:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0, p1}, Lc/b/a/a/h/c/e;->d(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    goto :goto_0

    :cond_3
    const/4 p1, 0x1

    .line 18
    iput-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H:Z

    const/4 p1, -0x1

    .line 19
    invoke-static {p0, p1}, Lcn/upus/app/upprinting/ui/activity/setting/DataDownloadUnzipActivity;->x(Landroid/content/Context;I)V

    .line 20
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_0

    :cond_4
    const-string v0, "classifyDBData"

    .line 21
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    .line 22
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->H:Z

    .line 23
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->a:Ljava/lang/String;

    .line 24
    iget-object p1, p1, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->c:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0, p1}, Lc/b/a/a/h/c/e;->d(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    :cond_5
    :goto_0
    return-void
.end method

.method public onNewIntent(Landroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroidx/fragment/app/FragmentActivity;->onNewIntent(Landroid/content/Intent;)V

    .line 2
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G()V

    return-void
.end method

.method public onPause()V
    .locals 1

    .line 1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G:Z

    .line 3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->E()V

    .line 4
    :cond_0
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onPause()V

    return-void
.end method

.method public onResume()V
    .locals 3

    .line 1
    sget-boolean v0, Lcn/upus/app/upprinting/MApp;->D:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 2
    sput-boolean v1, Lcn/upus/app/upprinting/MApp;->D:Z

    .line 3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G()V

    .line 4
    :cond_0
    sget-boolean v0, Lcn/upus/app/upprinting/MApp;->E:Z

    if-eqz v0, :cond_1

    .line 5
    sput-boolean v1, Lcn/upus/app/upprinting/MApp;->E:Z

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v2, "qaz \u67e5\u8be2\u6570\u636eMain3"

    aput-object v2, v0, v1

    .line 7
    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 8
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->A:Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/ClassifyDataViewModel;->i()V

    .line 9
    :cond_1
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 10
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->w:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0}, Lc/b/a/a/h/c/e;->S(Landroidx/lifecycle/MutableLiveData;)V

    .line 11
    :cond_2
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onResume()V

    return-void
.end method

.method public onSerialPortEvent(Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;)V
    .locals 4
    .annotation runtime Li/b/a/k;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->POSTING:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;->getData()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "serialData:"

    .line 2
    invoke-static {v2, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v1, "RCMD=33"

    .line 3
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, ";"

    const-string v2, ""

    .line 4
    invoke-virtual {p1, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v1, ","

    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 5
    array-length v1, p1

    const/4 v2, 0x5

    if-ne v1, v2, :cond_0

    const/4 v1, 0x4

    .line 6
    aget-object p1, p1, v1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "backEdgeSize:"

    .line 7
    invoke-static {v1, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 8
    :try_start_0
    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 9
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    .line 10
    :goto_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    .line 11
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v0, "BackEdgeSize"

    invoke-virtual {p1, v0, v3}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    :cond_0
    return-void
.end method

.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 1

    .line 1
    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G:Z

    const/4 p2, 0x0

    if-eqz p1, :cond_0

    .line 2
    iput-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->G:Z

    .line 3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->E()V

    .line 4
    :cond_0
    invoke-static {}, Li/b/a/c;->b()Li/b/a/c;

    move-result-object p1

    const-string v0, "main_touch"

    invoke-virtual {p1, v0}, Li/b/a/c;->f(Ljava/lang/Object;)V

    return p2
.end method

.method public final t()V
    .locals 2

    .line 1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->L:Z

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->M:Z

    if-eqz v0, :cond_3

    .line 2
    sget-object v0, Lcn/upus/app/upprinting/MApp;->C:Ljava/lang/String;

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    sget-object v0, Lcn/upus/app/upprinting/MApp;->C:Ljava/lang/String;

    const-string v1, "2"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    sget-object v0, Lcn/upus/app/upprinting/MApp;->C:Ljava/lang/String;

    const-string v1, "3"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 3
    :cond_0
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->v()V

    goto :goto_1

    .line 4
    :cond_1
    :goto_0
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->I:Z

    if-nez v0, :cond_2

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->a:Ljava/lang/String;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->v:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0, v1}, Lc/b/a/a/h/c/e;->b(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    goto :goto_1

    .line 6
    :cond_2
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity;->v()V

    :cond_3
    :goto_1
    return-void
.end method

.method public final u()V
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/AdDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/AdDialog;->dismiss()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 3
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    :goto_0
    return-void
.end method

.method public final v()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->z:Lcn/upus/app/upprinting/data/bean/AdBean;

    if-eqz v0, :cond_3

    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->K:Z

    if-nez v0, :cond_3

    invoke-static {p0}, Lcom/blankj/utilcode/util/ActivityUtils;->isActivityAlive(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->n:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateTipDialog;

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isVisible()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 3
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 4
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/AdDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/AdDialog;->dismiss()V

    goto :goto_1

    .line 5
    :cond_2
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/AdDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/AdDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    .line 6
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/AdDialog;

    new-instance v1, Lc/b/a/a/l/b/v1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/v1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    .line 7
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/AdDialog;->c:Lcn/upus/app/upprinting/ui/dialog/AdDialog$a;

    .line 8
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/AdDialog;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->z:Lcn/upus/app/upprinting/data/bean/AdBean;

    .line 9
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/AdDialog;->b:Lcn/upus/app/upprinting/data/bean/AdBean;

    .line 10
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->m:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/AdDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "ad"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 11
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->K:Z

    :cond_3
    return-void
.end method

.method public final w()V
    .locals 11

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->d:Landroid/widget/ImageButton;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 3
    new-instance v0, Landroid/view/animation/TranslateAnimation;

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/high16 v10, -0x40800000    # -1.0f

    move-object v2, v0

    invoke-direct/range {v2 .. v10}, Landroid/view/animation/TranslateAnimation;-><init>(IFIFIFIF)V

    const-wide/16 v1, 0x3e8

    .line 4
    invoke-virtual {v0, v1, v2}, Landroid/view/animation/TranslateAnimation;->setDuration(J)V

    .line 5
    new-instance v1, Lcn/upus/app/upprinting/ui/activity/MainActivity$c;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity$c;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/animation/TranslateAnimation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 6
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->a:Lcom/youth/banner/Banner;

    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->setAnimation(Landroid/view/animation/Animation;)V

    .line 8
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->Q:Le/b/p/b;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Le/b/p/b;->isDisposed()Z

    move-result v0

    if-nez v0, :cond_0

    .line 9
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->Q:Le/b/p/b;

    invoke-interface {v0}, Le/b/p/b;->dispose()V

    const/4 v0, 0x0

    .line 10
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->Q:Le/b/p/b;

    .line 11
    :cond_0
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v1, 0x1e

    invoke-static {v1, v2, v1, v2, v0}, Le/b/g;->c(JJLjava/util/concurrent/TimeUnit;)Le/b/g;

    move-result-object v0

    .line 12
    invoke-static {}, Le/b/o/a/a;->a()Le/b/l;

    move-result-object v1

    invoke-virtual {v0, v1}, Le/b/g;->d(Le/b/l;)Le/b/g;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/n2;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/n2;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    .line 13
    sget-object v2, Le/b/s/b/a;->d:Le/b/r/e;

    sget-object v3, Le/b/s/b/a;->b:Le/b/r/a;

    .line 14
    sget-object v4, Le/b/s/b/a;->c:Le/b/r/e;

    .line 15
    invoke-virtual {v0, v1, v2, v3, v4}, Le/b/g;->f(Le/b/r/e;Le/b/r/e;Le/b/r/a;Le/b/r/e;)Le/b/p/b;

    move-result-object v0

    .line 16
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->Q:Le/b/p/b;

    return-void
.end method

.method public final x()V
    .locals 11

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->a:Lcom/youth/banner/Banner;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setVisibility(I)V

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->d:Landroid/widget/ImageButton;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->d:Landroid/widget/ImageButton;

    const v1, 0x7f080142

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageResource(I)V

    .line 7
    new-instance v0, Landroid/view/animation/TranslateAnimation;

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/high16 v8, -0x40800000    # -1.0f

    const/4 v9, 0x1

    const/4 v10, 0x0

    move-object v2, v0

    invoke-direct/range {v2 .. v10}, Landroid/view/animation/TranslateAnimation;-><init>(IFIFIFIF)V

    const-wide/16 v1, 0x3e8

    .line 8
    invoke-virtual {v0, v1, v2}, Landroid/view/animation/TranslateAnimation;->setDuration(J)V

    .line 9
    new-instance v1, Lcn/upus/app/upprinting/ui/activity/MainActivity$b;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/MainActivity$b;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/animation/TranslateAnimation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 10
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityMainBinding;->a:Lcom/youth/banner/Banner;

    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->setAnimation(Landroid/view/animation/Animation;)V

    return-void
.end method

.method public final y()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->q:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->q:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 3
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->q:Ljava/lang/ref/WeakReference;

    .line 4
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;

    new-instance v1, Lc/b/a/a/l/b/p1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/p1;-><init>(Lcn/upus/app/upprinting/ui/activity/MainActivity;)V

    .line 5
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;->b:Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog$a;

    .line 6
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/MainActivity;->q:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/DataUpdateTipDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "dataUpdateTip"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public final z(Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;)V
    .locals 5

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "ad/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->createOrExistsDir(Ljava/lang/String;)Z

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconOne()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    const-string v3, "\\?"

    if-nez v1, :cond_0

    .line 4
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconOne()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v2

    .line 5
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconOne()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v0, v1}, Lc/b/a/a/h/c/e;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 6
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->setIconOne(Ljava/lang/String;)V

    .line 7
    :cond_0
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconTwo()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 8
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconTwo()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v2

    .line 9
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconTwo()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v0, v1}, Lc/b/a/a/h/c/e;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 10
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->setIconTwo(Ljava/lang/String;)V

    .line 11
    :cond_1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconThree()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2

    .line 12
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconThree()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v2

    .line 13
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconThree()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v0, v1}, Lc/b/a/a/h/c/e;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_2

    .line 14
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->setIconThree(Ljava/lang/String;)V

    .line 15
    :cond_2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconFour()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_3

    .line 16
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconFour()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v2

    .line 17
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconFour()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v0, v1}, Lc/b/a/a/h/c/e;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_3

    .line 18
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->setIconFour(Ljava/lang/String;)V

    .line 19
    :cond_3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconFive()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_4

    .line 20
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconFive()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    aget-object v1, v1, v2

    .line 21
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->getIconFive()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2, v0, v1}, Lc/b/a/a/h/c/e;->n(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 22
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/upus/app/upprinting/data/bean/FullScreenAdBean;->setIconFive(Ljava/lang/String;)V

    :cond_4
    return-void
.end method
