.class public Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;
.super Lcn/upus/app/upprinting/base/BaseDataBindingActivity;
.source "RechargeActivity.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcn/upus/app/upprinting/base/BaseDataBindingActivity<",
        "Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;",
        ">;"
    }
.end annotation


# instance fields
.field public k:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;",
            ">;"
        }
    .end annotation
.end field

.field public l:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/RechargesRecordBean;",
            ">;>;"
        }
    .end annotation
.end field

.field public m:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;",
            ">;"
        }
    .end annotation
.end field

.field public n:Landroid/app/AlertDialog;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;-><init>()V

    return-void
.end method

.method public static p(Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static q(Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static r(Landroid/content/Context;)V
    .locals 1

    .line 1
    const-class v0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;

    invoke-static {p0, v0}, Ld/a/a/a/a;->H(Landroid/content/Context;Ljava/lang/Class;)V

    return-void
.end method


# virtual methods
.method public g()I
    .locals 1

    const v0, 0x7f0c0096

    return v0
.end method

.method public l()V
    .locals 4

    const-string v0, ";BD:20;"

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    .line 2
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->d:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v1, p0, v2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->d:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v1, Lcn/upus/app/upprinting/ui/adapter/RechargeCordAdapter;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/adapter/RechargeCordAdapter;-><init>()V

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 7
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;->k:Landroidx/lifecycle/MutableLiveData;

    .line 8
    new-instance v1, Lc/b/a/a/l/b/r7/y0;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/y0;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 9
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;->l:Landroidx/lifecycle/MutableLiveData;

    .line 10
    new-instance v1, Lc/b/a/a/l/b/r7/z0;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/z0;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;->l:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0}, Lc/b/a/a/h/c/e;->I(Landroidx/lifecycle/MutableLiveData;)V

    .line 12
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 13
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "cutCountShow"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "0"

    .line 14
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 15
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 16
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->b(Ljava/lang/Boolean;)V

    goto :goto_0

    .line 17
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 18
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->b(Ljava/lang/Boolean;)V

    .line 19
    :goto_0
    sget-boolean v0, Lcn/upus/app/upprinting/MApp;->H:Z

    if-eqz v0, :cond_1

    .line 20
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 21
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->c:Landroid/widget/ImageView;

    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 22
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 23
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->c:Landroid/widget/ImageView;

    new-instance v1, Lc/b/a/a/l/b/r7/d3;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/d3;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 24
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 25
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->a:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/r7/e3;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/e3;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    const-string v0, "page_onCreate"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onCreate"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onDestroy()V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;->m:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;->m:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;->dismiss()V

    :cond_0
    return-void
.end method

.method public onPause()V
    .locals 2

    const-string v0, "onPause"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onPause()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onRestart()V
    .locals 2

    const-string v0, "page_onReStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onRestart()V

    return-void
.end method

.method public onResume()V
    .locals 2

    const-string v0, "onResume"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onResume()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "page_onResume"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onSerialPortEvent(Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;)V
    .locals 3
    .annotation runtime Li/b/a/k;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;->getData()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "serialData:"

    .line 2
    invoke-static {v1, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v0, "CODE="

    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, ""

    .line 4
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, ";"

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->b:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_0
    const-string v0, "RCMD=20,"

    .line 7
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    const-string v0, "RCMD=20,1;"

    .line 8
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 9
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->c:Landroid/widget/ImageView;

    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_0

    :cond_1
    const-string v0, "RCMD=20,0;"

    .line 11
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 12
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 13
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->c:Landroid/widget/ImageView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_0

    :cond_2
    const-string v0, "RCMD=20,2;"

    .line 14
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_3

    const-string p1, "\u6444\u50cf\u5934\u7e41\u5fd9"

    .line 15
    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 16
    :cond_3
    :goto_0
    sget-boolean p1, Lcn/upus/app/upprinting/MApp;->H:Z

    if-eqz p1, :cond_4

    .line 17
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 18
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->c:Landroid/widget/ImageView;

    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 19
    :cond_4
    :goto_1
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;->n:Landroid/app/AlertDialog;

    if-eqz p1, :cond_5

    .line 20
    invoke-virtual {p1}, Landroid/app/AlertDialog;->dismiss()V

    :cond_5
    return-void
.end method

.method public onStart()V
    .locals 2

    const-string v0, "page_onStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onStart"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStart()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onStop()V
    .locals 2

    const-string v0, "page_onStop"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStop()V

    return-void
.end method

.method public s(Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;)V
    .locals 8

    if-eqz p1, :cond_1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    .line 3
    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->j:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    .line 4
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    .line 5
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutTotalCount()J

    move-result-wide v1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v3

    sub-long/2addr v1, v3

    .line 6
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v3

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v4

    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 7
    iget-object v3, v3, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "USEQTY"

    invoke-virtual {v3, v5, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 8
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v3

    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 9
    iget-object v3, v3, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "BALAQTY"

    invoke-virtual {v3, v5, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 10
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v3

    .line 11
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v5

    if-eqz v5, :cond_0

    .line 12
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    if-lez v6, :cond_0

    .line 13
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    int-to-long v6, v6

    add-long/2addr v3, v6

    .line 14
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    int-to-long v5, v5

    sub-long/2addr v1, v5

    .line 15
    :cond_0
    const-wide v1, 0x1869f
    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setBalaqty(J)V

    .line 16
    invoke-virtual {v0, v3, v4}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setUseqty(J)V

    .line 17
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getState()I

    move-result p1

    const/4 v0, -0x4

    if-ne p1, v0, :cond_1

    const/4 p1, 0x1

    .line 18
    sput-boolean p1, Lcn/upus/app/upprinting/MApp;->D:Z

    .line 19
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 20
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->b:Lcn/upus/app/upprinting/view/TextChangedEditText;

    const-string v0, ""

    invoke-virtual {p1, v0}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 21
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/RechargeActivity;->l:Landroidx/lifecycle/MutableLiveData;

    invoke-static {p1}, Lc/b/a/a/h/c/e;->I(Landroidx/lifecycle/MutableLiveData;)V

    :cond_1
    return-void
.end method

.method public t(Ljava/util/List;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;

    invoke-virtual {v0, p1}, Lcn/upus/app/upprinting/databinding/LayoutActivityRechargeBinding;->c(Ljava/util/List;)V

    return-void
.end method
