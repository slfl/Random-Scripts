.class public Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;
.super Lcn/upus/app/upprinting/base/BaseDataBindingActivity;
.source "FilmCutActivity.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcn/upus/app/upprinting/base/BaseDataBindingActivity<",
        "Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;",
        ">;"
    }
.end annotation


# instance fields
.field public A:J

.field public B:Z

.field public C:I

.field public D:I

.field public E:I

.field public F:Ljava/lang/String;

.field public G:Ljava/lang/String;

.field public H:Ljava/lang/String;

.field public I:Ljava/lang/String;

.field public J:Ljava/lang/String;

.field public K:Ljava/lang/String;

.field public L:Ljava/lang/String;

.field public M:Ljava/lang/String;

.field public N:Ljava/lang/String;

.field public O:Ljava/lang/String;

.field public P:Landroid/graphics/Bitmap;

.field public Q:Ljava/lang/String;

.field public R:F

.field public S:F

.field public T:Z

.field public U:Ljava/lang/String;

.field public V:Ljava/lang/String;

.field public W:Ljava/lang/String;

.field public X:Ljava/lang/String;

.field public Y:Ljava/lang/String;

.field public Z:Ljava/lang/String;

.field public a0:Ljava/lang/String;

.field public b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

.field public c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

.field public d0:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/widget/CheckBox;",
            ">;"
        }
    .end annotation
.end field

.field public e0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/PartHistoryBean;",
            ">;"
        }
    .end annotation
.end field

.field public f0:I

.field public g0:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/SetCutAngleDialog;",
            ">;"
        }
    .end annotation
.end field

.field public h0:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/InputDialog;",
            ">;"
        }
    .end annotation
.end field

.field public i0:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/CutMoveDialog;",
            ">;"
        }
    .end annotation
.end field

.field public k:Z

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:Z

.field public r:Z

.field public s:I

.field public t:F

.field public u:Z

.field public v:Ljava/lang/String;

.field public w:F

.field public x:Ljava/lang/String;

.field public y:I

.field public z:J


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    .line 3
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->l:Z

    .line 4
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m:Z

    .line 5
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n:Z

    .line 6
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->o:Z

    const/4 v1, 0x1

    .line 7
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->p:Z

    .line 8
    iput-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->q:Z

    .line 9
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r:Z

    .line 10
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    const/high16 v2, 0x3f800000    # 1.0f

    .line 11
    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    .line 12
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->u:Z

    const/4 v0, 0x0

    .line 13
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    const/4 v2, -0x1

    .line 14
    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->E:I

    const-string v2, ""

    .line 15
    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->H:Ljava/lang/String;

    .line 16
    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->I:Ljava/lang/String;

    .line 17
    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    .line 18
    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->K:Ljava/lang/String;

    .line 19
    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    .line 20
    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M:Ljava/lang/String;

    .line 21
    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Q:Ljava/lang/String;

    .line 22
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    .line 23
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    .line 24
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    .line 25
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->f0:I

    const/4 v0, 0x0

    .line 26
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->g0:Ljava/lang/ref/WeakReference;

    .line 27
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->i0:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public static A(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static synthetic B(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->j0()V

    return-void
.end method

.method public static C(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V
    .locals 4

    if-eqz p0, :cond_0

    .line 1
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const v1, 0x7f11024b

    .line 2
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(I)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lc/b/a/a/l/b/i5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/i5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    const v3, 0x7f11009d

    .line 3
    invoke-virtual {v1, v3, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lc/b/a/a/l/b/h5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/h5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    const p0, 0x7f11009c

    .line 4
    invoke-virtual {v1, p0, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 5
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    .line 6
    invoke-virtual {p0}, Landroid/app/AlertDialog;->show()V

    .line 7
    invoke-static {p0}, Lc/b/a/a/k/a;->u(Landroid/app/Dialog;)V

    return-void

    :cond_0
    const/4 p0, 0x0

    .line 8
    throw p0
.end method

.method public static D(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static E(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static synthetic F(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k0(I)V

    return-void
.end method

.method public static O(Landroid/content/Context;Lcn/upus/app/upprinting/data/bean/CutSettings;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    const-string v2, "\u5fb7\u56fd\u5ba2\u6237\u9700\u6c42"

    aput-object v2, v0, v1

    .line 1
    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 2
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "cutSettings"

    .line 3
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    const-string p1, "partno"

    .line 4
    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "pltCode"

    .line 5
    invoke-virtual {v0, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "pltVersion"

    .line 6
    invoke-virtual {v0, p1, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "cameraCutout"

    .line 7
    invoke-virtual {v0, p1, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "bladePosition"

    .line 8
    invoke-virtual {v0, p1, p6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 9
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public static P(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v1, 0x0

    const-string v2, "\u975e\u5fb7\u56fd\u5ba2\u6237\u9700\u6c42"

    aput-object v2, v0, v1

    .line 1
    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 2
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "partno"

    .line 3
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "pltCode"

    .line 4
    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "pltVersion"

    .line 5
    invoke-virtual {v0, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 6
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public static p(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0(Ljava/lang/String;)V

    .line 2
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    .line 3
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public static synthetic q(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Z)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->o0(Z)V

    return-void
.end method

.method public static r(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V
    .locals 8

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    if-eqz v0, :cond_1

    .line 2
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getId()Ljava/lang/String;

    move-result-object v0

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getIconPath()Ljava/lang/String;

    move-result-object v1

    .line 4
    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFilePath()Ljava/lang/String;

    move-result-object v2

    .line 5
    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getCategoryOneId()Ljava/lang/String;

    move-result-object v3

    .line 6
    invoke-static {v2}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 7
    invoke-static {v2}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1

    .line 8
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v6, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    const-string v7, "prCustom/"

    invoke-static {v5, v6, v7, v4}, Ld/a/a/a/a;->w(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 9
    invoke-static {v4}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_0

    move-object v2, v4

    .line 10
    :cond_0
    invoke-static {p0, v0, v1, v2, v3}, Lcn/upus/app/upprinting/ui/activity/ProfileCustomActivity;->z(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    return-void
.end method

.method public static s(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Ljava/lang/String;Z)V
    .locals 2

    if-eqz p0, :cond_0

    .line 1
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    new-instance v1, Lc/b/a/a/l/b/a5;

    invoke-direct {v1, p0, p2, p1}, Lc/b/a/a/l/b/a5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;ZLjava/lang/String;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 3
    invoke-static {p1, v0}, Lc/b/a/a/h/c/e;->m(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void

    :cond_0
    const/4 p0, 0x0

    .line 4
    throw p0
.end method

.method public static t(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Ljava/lang/String;)V
    .locals 2

    if-eqz p0, :cond_0

    const-string v0, ";BD:100,10,5;BD:100,4;"

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    invoke-virtual {v0}, Landroidx/databinding/ViewDataBinding;->getRoot()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/b5;

    invoke-direct {v1, p0, p1}, Lc/b/a/a/l/b/b5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Ljava/lang/String;)V

    const-wide/16 p0, 0x32

    invoke-virtual {v0, v1, p0, p1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_0
    const/4 p0, 0x0

    .line 4
    throw p0
.end method

.method public static u(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static synthetic v(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Z)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->q0(Z)V

    return-void
.end method

.method public static w(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 14

    move-object v0, p0

    if-eqz v0, :cond_1

    .line 1
    new-instance v13, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v13}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    new-instance v1, Lc/b/a/a/l/b/c5;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/c5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v13, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    const-string v1, "material"

    .line 3
    invoke-static {v1}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "1"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 4
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/CutSettings;->getId()Ljava/lang/String;

    move-result-object v8

    .line 5
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {v1}, Lc/b/a/a/m/d;->c0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v9

    .line 6
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {v1}, Lc/b/a/a/m/d;->d0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    .line 7
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    iget-object v3, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N:Ljava/lang/String;

    iget-object v4, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->O:Ljava/lang/String;

    iget v6, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->y:I

    iget-object v11, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->X:Ljava/lang/String;

    iget-object v12, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Y:Ljava/lang/String;

    const-string v0, "on"

    move-object v5, p1

    move-object/from16 v7, p2

    invoke-static/range {v0 .. v13}, Lc/b/a/a/h/c/e;->M(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    goto :goto_0

    .line 8
    :cond_0
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    iget-object v3, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N:Ljava/lang/String;

    iget-object v4, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->O:Ljava/lang/String;

    iget v6, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->y:I

    const-string v0, "on"

    const-string v8, ""

    move-object v5, p1

    move-object/from16 v7, p2

    move-object v9, v13

    invoke-static/range {v0 .. v9}, Lc/b/a/a/h/c/e;->L(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    :goto_0
    return-void

    :cond_1
    const/4 v0, 0x0

    .line 9
    throw v0
.end method

.method public static synthetic x(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->f0()V

    return-void
.end method

.method public static synthetic y(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->p0()V

    return-void
.end method

.method public static z(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method


# virtual methods
.method public final G()V
    .locals 8

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "CutHistory"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v2, :cond_2

    .line 4
    new-instance v2, Lcom/google/gson/Gson;

    invoke-direct {v2}, Lcom/google/gson/Gson;-><init>()V

    new-instance v5, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$b;

    invoke-direct {v5, p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$b;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v5}, Lcom/google/gson/reflect/TypeToken;->getType()Ljava/lang/reflect/Type;

    move-result-object v5

    invoke-virtual {v2, v0, v5}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    .line 5
    new-instance v2, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$c;

    invoke-direct {v2, p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$c;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-static {v0, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v2, 0x0

    .line 6
    :goto_0
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    if-ge v3, v5, :cond_1

    .line 7
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;

    .line 8
    invoke-virtual {v5, v3}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->setSort(I)V

    .line 9
    invoke-virtual {v5}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->getPartno()Ljava/lang/String;

    move-result-object v6

    iget-object v7, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v7}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getPartno()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    .line 10
    invoke-virtual {v5}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->setCount()V

    .line 11
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    invoke-virtual {v5, v2}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->setSort(I)V

    const/4 v2, 0x1

    :cond_0
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_1
    if-nez v2, :cond_3

    .line 12
    new-instance v2, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;

    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getPartno()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v5

    invoke-direct {v2, v3, v4, v5}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;-><init>(Ljava/lang/String;II)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 13
    :cond_2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 14
    new-instance v2, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;

    iget-object v5, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v5}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getPartno()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v2, v5, v4, v3}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;-><init>(Ljava/lang/String;II)V

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 15
    :cond_3
    :goto_1
    sput-boolean v4, Lcn/upus/app/upprinting/MApp;->D:Z

    .line 16
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    invoke-static {v0}, Lcom/blankj/utilcode/util/GsonUtils;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 17
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2, v1, v0}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method

.method public final H()V
    .locals 5

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-virtual {v0}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getUvHeightCalibration()Ljava/lang/String;

    move-result-object v0

    .line 4
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    .line 5
    :try_start_0
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 6
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_0
    const/4 v0, 0x0

    .line 7
    :goto_0
    new-instance v1, Lc/b/a/a/l/f/g;

    iget v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    float-to-int v3, v3

    mul-int/lit8 v3, v3, 0x28

    iget v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    float-to-int v4, v4

    mul-int/lit8 v4, v4, 0x28

    invoke-direct {v1, p0, v3, v4, v0}, Lc/b/a/a/l/f/g;-><init>(Landroid/content/Context;III)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/String;

    .line 8
    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    aput-object v3, v0, v2

    invoke-virtual {v1, v0}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    :cond_1
    return-void
.end method

.method public final I(Ljava/lang/String;)Landroid/widget/CheckBox;
    .locals 4

    .line 1
    invoke-static {p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v0

    .line 2
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/4 v3, -0x2

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v2, 0x5

    .line 3
    invoke-virtual {v1, v2, v2, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    const/high16 v3, 0x3f800000    # 1.0f

    .line 4
    iput v3, v1, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 5
    new-instance v3, Landroid/widget/CheckBox;

    invoke-direct {v3, p0}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 6
    invoke-virtual {v3, v1}, Landroid/widget/CheckBox;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 7
    invoke-virtual {v3, v2}, Landroid/widget/CheckBox;->setTextAlignment(I)V

    .line 8
    invoke-virtual {v3, v0}, Landroid/widget/CheckBox;->setTextColor(I)V

    const v0, 0x7f08007b

    .line 9
    invoke-virtual {v3, v0}, Landroid/widget/CheckBox;->setButtonDrawable(I)V

    .line 10
    invoke-static {v3}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 11
    invoke-virtual {v3, p1}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41400000    # 12.0f

    .line 12
    invoke-virtual {v3, p1}, Landroid/widget/CheckBox;->setTextSize(F)V

    return-object v3
.end method

.method public final J(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v0, "\\*"

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 2
    array-length v0, p1

    const/4 v1, 0x2

    if-ne v1, v0, :cond_0

    const/4 v0, 0x0

    .line 3
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x1

    .line 4
    aget-object p1, p1, v1

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    const-string v1, " W:"

    const-string v2, " L:"

    const-string v3, " mm"

    .line 5
    invoke-static {v1, p1, v2, v0, v3}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    const-string p1, ""

    :goto_0
    return-object p1
.end method

.method public final K(Ljava/lang/String;)Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;
    .locals 5

    const-string v0, "material"

    const-string v1, "1"

    .line 1
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v3, "remark"

    .line 2
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "uuid"

    .line 3
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->O:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "feedBack"

    .line 4
    invoke-virtual {v2, v3, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 5
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v3, ""

    if-eqz p1, :cond_0

    :try_start_1
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/CutSettings;->getId()Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    move-object p1, v3

    :goto_0
    const-string v4, "materialId"

    .line 6
    invoke-virtual {v2, v4, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 7
    iget p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->y:I

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string v4, "packageType"

    .line 8
    invoke-virtual {v2, v4, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 9
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_1

    const-string p1, "productId"

    .line 10
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    invoke-virtual {v2, p1, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 11
    iput-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    goto :goto_1

    .line 12
    :cond_1
    iput-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    const-string p1, "partno"

    .line 13
    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-virtual {v2, p1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 14
    :goto_1
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2

    .line 15
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {p1}, Lc/b/a/a/m/d;->c0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "pressure"

    .line 16
    invoke-virtual {v2, v0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 17
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {p1}, Lc/b/a/a/m/d;->d0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string v0, "speed"

    .line 18
    invoke-virtual {v2, v0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "pltCode"

    .line 19
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->X:Ljava/lang/String;

    invoke-virtual {v2, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "pltVersion"

    .line 20
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Y:Ljava/lang/String;

    invoke-virtual {v2, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_2

    :catch_0
    move-exception p1

    .line 21
    invoke-virtual {p1}, Lorg/json/JSONException;->printStackTrace()V

    .line 22
    :cond_2
    :goto_2
    new-instance p1, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    invoke-direct {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;-><init>()V

    const/4 v0, 0x0

    .line 23
    invoke-virtual {p1, v0}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;->setIsUpdate(Z)V

    .line 24
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;->setJson(Ljava/lang/String;)V

    return-object p1
.end method

.method public final L()I
    .locals 3

    const/4 v0, 0x0

    .line 1
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 2
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_0

    .line 3
    instance-of v2, v1, Landroid/widget/CheckBox;

    if-eqz v2, :cond_0

    .line 4
    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_1
    return v0
.end method

.method public final M()V
    .locals 11

    const-string v0, ","

    const-string v1, "SJM="

    const-string v2, "FSIZE"

    const-string v3, ";"

    .line 1
    sget-boolean v4, Lc/b/a/a/k/d;->j:Z

    if-eqz v4, :cond_0

    const v4, 0x7f1100da

    .line 2
    invoke-static {v4}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v5, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v5, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v5, v5, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 5
    :cond_0
    :try_start_0
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_1

    return-void

    .line 6
    :cond_1
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    invoke-virtual {v4, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    return-void

    .line 7
    :cond_2
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 8
    array-length v5, v4

    if-nez v5, :cond_3

    return-void

    :cond_3
    const/4 v5, 0x0

    .line 9
    aget-object v4, v4, v5

    .line 10
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_4

    return-void

    .line 11
    :cond_4
    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v7, 0x1

    if-eqz v6, :cond_8

    .line 12
    invoke-virtual {v4, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 13
    array-length v4, v1

    if-nez v4, :cond_5

    return-void

    .line 14
    :cond_5
    aget-object v1, v1, v7

    const-string v4, " "

    .line 15
    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 16
    array-length v6, v4

    const/4 v8, 0x2

    if-ne v8, v6, :cond_6

    .line 17
    aget-object v4, v4, v5

    iput-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->G:Ljava/lang/String;

    :cond_6
    const/4 v4, 0x0

    .line 18
    iget v6, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v9, ";SJM="

    cmpg-float v4, v4, v6

    if-gez v4, :cond_7

    :try_start_1
    iget v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    const/high16 v6, 0x43200000    # 160.0f

    cmpg-float v4, v4, v6

    if-gez v4, :cond_7

    .line 19
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 20
    array-length v6, v4

    if-ne v6, v8, :cond_9

    .line 21
    aget-object v6, v4, v7

    invoke-virtual {v6, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    .line 22
    array-length v10, v6

    if-ne v10, v8, :cond_9

    .line 23
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v4, v4, v5

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v2, v6, v7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v6, v5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    .line 24
    :cond_7
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_8
    const-string v0, "012345678901238"

    .line 25
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->G:Ljava/lang/String;

    .line 26
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "IN"

    const-string v2, ""

    invoke-virtual {v4, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_9
    :goto_0
    new-array v0, v7, [Ljava/lang/Object;

    .line 27
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u83b7\u53d6\u5207\u5272\u6700\u5c0f\u5c3a\u5bf8 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v5

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 28
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    .line 29
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_1
    return-void
.end method

.method public final N()V
    .locals 15

    .line 1
    invoke-static {p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v0

    .line 2
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Q:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x0

    if-nez v1, :cond_c

    sget-object v1, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    if-eqz v1, :cond_c

    .line 3
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_c

    .line 4
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    const/4 v3, 0x1

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setEnabled(Z)V

    .line 6
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v1, v3}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Q:Ljava/lang/String;

    const-string v4, ","

    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 9
    array-length v4, v1

    const/4 v5, 0x2

    if-eq v5, v4, :cond_0

    return-void

    .line 10
    :cond_0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v6, v1, v3

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "*"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v6, v1, v2

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 11
    aget-object v6, v1, v3

    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v6

    .line 12
    aget-object v1, v1, v2

    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    const v7, 0x7f060077

    const/4 v8, 0x0

    cmpl-float v6, v8, v6

    if-nez v6, :cond_2

    cmpl-float v1, v8, v1

    if-nez v1, :cond_2

    const/4 v0, 0x0

    .line 13
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_e

    .line 14
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_1

    .line 15
    instance-of v3, v1, Landroid/widget/CheckBox;

    if-eqz v3, :cond_1

    .line 16
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3, v7}, Landroid/content/res/Resources;->getColor(I)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 17
    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 18
    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_1
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 19
    :cond_2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    const/16 v6, 0x320

    .line 20
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v8, "BackEdgeSize"

    invoke-virtual {v1, v8, v6}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v1

    .line 21
    iget v6, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    int-to-float v1, v1

    const/high16 v8, 0x42200000    # 40.0f

    div-float/2addr v1, v8

    add-float/2addr v1, v6

    const/high16 v6, 0x3f800000    # 1.0f

    add-float/2addr v1, v6

    const/4 v6, 0x0

    .line 22
    :goto_1
    sget-object v8, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    const/high16 v9, 0x40800000    # 4.0f

    const-string v10, "VF"

    const/high16 v11, 0x40000000    # 2.0f

    const-string v12, "\\*"

    if-ge v6, v8, :cond_8

    .line 23
    sget-object v8, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v8, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 24
    iget-object v13, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v13, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroid/widget/CheckBox;

    .line 25
    invoke-virtual {v8, v12}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    .line 26
    array-length v14, v12

    if-eq v5, v14, :cond_3

    goto :goto_3

    .line 27
    :cond_3
    aget-object v5, v12, v2

    invoke-static {v5}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v5

    .line 28
    aget-object v12, v12, v3

    invoke-static {v12}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v12

    if-eqz v13, :cond_7

    .line 29
    instance-of v14, v13, Landroid/widget/CheckBox;

    if-eqz v14, :cond_7

    .line 30
    iget v14, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    add-float/2addr v14, v11

    .line 31
    iget-object v11, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->x:Ljava/lang/String;

    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_4

    iget-object v11, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->x:Ljava/lang/String;

    invoke-virtual {v11, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_4

    .line 32
    iget v10, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    add-float v14, v10, v9

    .line 33
    :cond_4
    iget v9, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    cmpg-float v9, v12, v9

    if-gtz v9, :cond_6

    cmpl-float v9, v12, v14

    if-ltz v9, :cond_6

    cmpl-float v5, v5, v1

    if-ltz v5, :cond_6

    .line 34
    invoke-virtual {v13, v0}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 35
    invoke-virtual {v13, v3}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 36
    invoke-virtual {v8, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_5

    const/4 v5, 0x1

    goto :goto_2

    :cond_5
    const/4 v5, 0x0

    :goto_2
    invoke-virtual {v13, v5}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_3

    .line 37
    :cond_6
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v7}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {v13, v5}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 38
    invoke-virtual {v13, v2}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 39
    invoke-virtual {v13, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_7
    :goto_3
    add-int/lit8 v6, v6, 0x1

    const/4 v5, 0x2

    goto/16 :goto_1

    .line 40
    :cond_8
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    .line 41
    iget-object v4, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "IS_re_material"

    invoke-virtual {v4, v5, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v4

    .line 42
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v5

    const-string v6, "lastMaterialSize"

    invoke-static {v6}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v7}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getCategoryOneId()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-string v7, ""

    invoke-virtual {v5, v6, v7}, Lc/b/a/a/m/f;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v4, :cond_e

    .line 43
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_e

    const/4 v4, 0x0

    .line 44
    :goto_4
    sget-object v6, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v4, v6, :cond_e

    .line 45
    sget-object v6, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 46
    iget-object v7, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v7, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/widget/CheckBox;

    .line 47
    invoke-virtual {v6, v12}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    .line 48
    array-length v13, v8

    const/4 v14, 0x2

    if-eq v14, v13, :cond_9

    goto :goto_5

    .line 49
    :cond_9
    aget-object v13, v8, v2

    invoke-static {v13}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v13

    .line 50
    aget-object v8, v8, v3

    invoke-static {v8}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v8

    if-eqz v7, :cond_b

    .line 51
    instance-of v14, v7, Landroid/widget/CheckBox;

    if-eqz v14, :cond_b

    .line 52
    iget v14, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    add-float/2addr v14, v11

    .line 53
    iget-object v11, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->x:Ljava/lang/String;

    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v11

    if-nez v11, :cond_a

    iget-object v11, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->x:Ljava/lang/String;

    invoke-virtual {v11, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_a

    .line 54
    iget v11, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    add-float v14, v11, v9

    .line 55
    :cond_a
    iget v11, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    cmpg-float v11, v8, v11

    if-gtz v11, :cond_b

    cmpl-float v8, v8, v14

    if-ltz v8, :cond_b

    cmpl-float v8, v13, v1

    if-ltz v8, :cond_b

    .line 56
    invoke-virtual {v7, v0}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 57
    invoke-virtual {v7, v3}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 58
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_b

    .line 59
    invoke-virtual {v7, v3}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_b
    :goto_5
    add-int/lit8 v4, v4, 0x1

    const/high16 v11, 0x40000000    # 2.0f

    goto :goto_4

    :cond_c
    const/4 v0, 0x0

    .line 60
    :goto_6
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_e

    .line 61
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_d

    .line 62
    instance-of v3, v1, Landroid/widget/CheckBox;

    if-eqz v3, :cond_d

    .line 63
    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 64
    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_d
    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    :cond_e
    return-void
.end method

.method public synthetic Q(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 1
    check-cast p1, Landroid/widget/CheckBox;

    invoke-virtual {p0, p1, p2}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->g0(Landroid/widget/CheckBox;Z)V

    return-void
.end method

.method public synthetic R(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 1
    check-cast p1, Landroid/widget/CheckBox;

    invoke-virtual {p0, p1, p2}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->g0(Landroid/widget/CheckBox;Z)V

    return-void
.end method

.method public S(Landroid/view/View;)Z
    .locals 1

    .line 1
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-static {p1}, Lc/a/a/j/a;->c(Ljava/lang/String;)V

    .line 2
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getDetailIcon()Ljava/lang/String;

    move-result-object p1

    const-string v0, "icon"

    invoke-virtual {p0, p1, v0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0(Ljava/lang/String;Ljava/lang/String;)V

    .line 3
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFile()Ljava/lang/String;

    move-result-object p1

    const-string v0, "file"

    invoke-virtual {p0, p1, v0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0(Ljava/lang/String;Ljava/lang/String;)V

    .line 4
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 5
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    const/4 p1, 0x0

    return p1
.end method

.method public T(Landroid/view/View;)Z
    .locals 0

    const/4 p1, 0x0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->o0(Z)V

    .line 2
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    const/4 p1, 0x1

    return p1
.end method

.method public U(Landroid/view/View;)Z
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0()V

    .line 2
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    const/4 p1, 0x0

    return p1
.end method

.method public synthetic V(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 1
    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->p:Z

    if-eqz p1, :cond_0

    .line 2
    invoke-virtual {p0, p2}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0(Z)V

    :cond_0
    return-void
.end method

.method public W(Landroid/widget/CompoundButton;Z)V
    .locals 1

    .line 1
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    .line 3
    iput-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m:Z

    if-eqz p2, :cond_0

    .line 4
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    const/high16 p2, -0x40800000    # -1.0f

    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    mul-float v0, v0, p2

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setScaleX(F)V

    goto :goto_0

    .line 6
    :cond_0
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    const/high16 p2, 0x3f800000    # 1.0f

    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    mul-float v0, v0, p2

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setScaleX(F)V

    .line 8
    :goto_0
    iget p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k0(I)V

    .line 9
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->j0()V

    return-void
.end method

.method public X(Landroid/widget/CompoundButton;Z)V
    .locals 1

    .line 1
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    .line 3
    iput-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n:Z

    if-eqz p2, :cond_0

    .line 4
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    iget p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    const/high16 v0, -0x40800000    # -1.0f

    mul-float p2, p2, v0

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setScaleY(F)V

    .line 6
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    iget p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    mul-float p2, p2, v0

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setScaleX(F)V

    goto :goto_0

    .line 8
    :cond_0
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    iget p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    const/high16 v0, 0x3f800000    # 1.0f

    mul-float p2, p2, v0

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setScaleY(F)V

    .line 10
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    iget p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    mul-float p2, p2, v0

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setScaleX(F)V

    .line 12
    :goto_0
    iget p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k0(I)V

    .line 13
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->j0()V

    return-void
.end method

.method public Y(Landroid/widget/CompoundButton;Z)V
    .locals 3

    .line 1
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    const/4 p1, 0x0

    if-eqz p2, :cond_7

    .line 3
    iget-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r:Z

    const/16 v0, 0x8

    if-eqz p2, :cond_0

    .line 4
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->a:Landroid/widget/Button;

    invoke-virtual {p2, v0}, Landroid/widget/Button;->setVisibility(I)V

    .line 6
    :cond_0
    iget-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->l:Z

    if-eqz p2, :cond_1

    .line 7
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->f:Landroid/widget/CheckBox;

    invoke-virtual {p2, v0}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 9
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->f:Landroid/widget/CheckBox;

    invoke-virtual {p2, p1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 11
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {p2, v0}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 13
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 14
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {p2, p1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 15
    :cond_1
    iget-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    if-eqz p2, :cond_4

    const/4 p2, 0x0

    .line 16
    :goto_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p2, v0, :cond_4

    .line 17
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/widget/CheckBox;

    if-eqz v0, :cond_3

    .line 18
    instance-of v1, v0, Landroid/widget/CheckBox;

    if-eqz v1, :cond_3

    .line 19
    invoke-virtual {v0}, Landroid/widget/CheckBox;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 20
    invoke-virtual {v0, p1}, Landroid/widget/CheckBox;->setEnabled(Z)V

    const-string v2, "W:190 L:120 mm"

    .line 21
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 22
    invoke-static {p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v1

    .line 23
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setTextColor(I)V

    const/4 v1, 0x1

    .line 24
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 25
    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_1

    .line 26
    :cond_2
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060077

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 27
    invoke-virtual {v0, p1}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 28
    invoke-virtual {v0, p1}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_3
    :goto_1
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    .line 29
    :cond_4
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->K:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_6

    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->P:Landroid/graphics/Bitmap;

    if-nez p1, :cond_5

    goto :goto_2

    .line 30
    :cond_5
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 31
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-virtual {p2, p1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    goto :goto_3

    .line 32
    :cond_6
    :goto_2
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->H()V

    .line 33
    :goto_3
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 34
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    const/high16 p2, -0x40800000    # -1.0f

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setScaleX(F)V

    goto :goto_4

    .line 35
    :cond_7
    iget-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r:Z

    if-eqz p2, :cond_8

    .line 36
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 37
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->a:Landroid/widget/Button;

    invoke-virtual {p2, p1}, Landroid/widget/Button;->setVisibility(I)V

    .line 38
    :cond_8
    iget-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    if-eqz p2, :cond_9

    .line 39
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N()V

    .line 40
    :cond_9
    iget-boolean p2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->l:Z

    if-eqz p2, :cond_a

    .line 41
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 42
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->f:Landroid/widget/CheckBox;

    invoke-virtual {p2, p1}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 43
    iget-object p2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 44
    check-cast p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p2, p2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {p2, p1}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 45
    :cond_a
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r0()V

    .line 46
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 47
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    const/high16 p2, 0x3f800000    # 1.0f

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setScaleX(F)V

    :goto_4
    return-void
.end method

.method public Z(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 2
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 3
    new-instance v1, Lc/b/a/a/l/b/a5;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2, p1}, Lc/b/a/a/l/b/a5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;ZLjava/lang/String;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 4
    invoke-static {p1, v0}, Lc/b/a/a/h/c/e;->m(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void
.end method

.method public final a0()V
    .locals 7

    const-string v0, "/"

    const/4 v1, 0x2

    :try_start_0
    new-array v1, v1, [Ljava/lang/Object;

    const/4 v2, 0x0

    const-string v3, "filePath:"

    aput-object v3, v1, v2

    .line 1
    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFilePath()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    .line 2
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFilePath()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v2, "file"

    if-eqz v1, :cond_0

    .line 3
    :try_start_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFile()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 4
    :cond_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFilePath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 5
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFile()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_1

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    .line 6
    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFile()Ljava/lang/String;

    move-result-object v4

    array-length v5, v1

    sub-int/2addr v5, v3

    aget-object v1, v1, v5

    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFile()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 8
    :cond_1
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFilePath()Ljava/lang/String;

    move-result-object v1

    .line 9
    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 10
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v5, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "prCustom/"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x2f

    .line 11
    invoke-virtual {v1, v5}, Ljava/lang/String;->indexOf(I)I

    move-result v5

    const/4 v6, -0x1

    if-ne v5, v6, :cond_2

    .line 12
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->getFileExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 13
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v5, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 14
    :cond_2
    invoke-static {v1}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_3

    .line 15
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFile()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 16
    :cond_3
    invoke-static {v4}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_4

    goto :goto_0

    :cond_4
    move-object v4, v1

    .line 17
    :goto_0
    new-instance v0, Ljava/io/FileInputStream;

    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 18
    invoke-virtual {v0}, Ljava/io/FileInputStream;->available()I

    move-result v1

    if-lez v1, :cond_5

    .line 19
    new-array v1, v1, [B

    .line 20
    invoke-virtual {v0, v1}, Ljava/io/FileInputStream;->read([B)I

    .line 21
    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V

    .line 22
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    .line 23
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->H:Ljava/lang/String;

    goto :goto_1

    .line 24
    :cond_5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getFile()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0, v2}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    .line 25
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_1
    return-void
.end method

.method public final b0(Z)V
    .locals 5

    const/4 v0, 0x0

    if-eqz p1, :cond_1

    .line 1
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    if-nez p1, :cond_0

    .line 2
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    .line 3
    :cond_0
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    new-instance v1, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getPartno()Ljava/lang/String;

    move-result-object v2

    iget v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->f0:I

    const/4 v4, 0x1

    add-int/2addr v3, v4

    invoke-direct {v1, v2, v4, v3}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;-><init>(Ljava/lang/String;II)V

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$d;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$d;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-static {p1, v1}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 5
    :goto_0
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    if-ge v0, p1, :cond_4

    .line 6
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;

    invoke-virtual {p1, v0}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->setSort(I)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 7
    :cond_1
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    if-eqz p1, :cond_4

    const/4 p1, 0x0

    .line 8
    :goto_1
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_3

    .line 9
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;

    .line 10
    invoke-virtual {v1, v0}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->setSort(I)V

    .line 11
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->getPartno()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2

    move-object p1, v1

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    if-eqz p1, :cond_4

    .line 12
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 13
    :cond_4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-static {v0}, Lcom/blankj/utilcode/util/GsonUtils;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 14
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "CutFavorite"

    invoke-virtual {p1, v1, v0}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method

.method public final c0(Ljava/lang/String;)V
    .locals 14

    .line 1
    new-instance v12, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v12}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->y:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    .line 3
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->K(Ljava/lang/String;)Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    move-result-object v13

    const-string v0, "material"

    .line 4
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/CutSettings;->getId()Ljava/lang/String;

    move-result-object v7

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {v0}, Lc/b/a/a/m/d;->c0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {v0}, Lc/b/a/a/m/d;->d0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v9

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N:Ljava/lang/String;

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->O:Ljava/lang/String;

    iget-object v10, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->X:Ljava/lang/String;

    iget-object v11, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Y:Ljava/lang/String;

    const-string v0, "on"

    move-object v6, p1

    invoke-static/range {v0 .. v13}, Lc/b/a/a/h/c/e;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)V

    goto :goto_0

    .line 9
    :cond_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N:Ljava/lang/String;

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->O:Ljava/lang/String;

    const-string v0, "on"

    const-string v7, ""

    move-object v6, p1

    move-object v8, v12

    move-object v9, v13

    invoke-static/range {v0 .. v9}, Lc/b/a/a/h/c/e;->g(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)V

    :goto_0
    return-void
.end method

.method public final d0()V
    .locals 3

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    const v0, 0x7f1100da

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 5
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 6
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v1, 0x0

    const-string v2, "ID_abnormal"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    const v0, 0x7f1100cf

    .line 7
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 10
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 11
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    goto :goto_1

    .line 12
    :cond_3
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    .line 13
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    new-instance v1, Lc/b/a/a/l/b/b0;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/b0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    .line 14
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->b:Lcn/upus/app/upprinting/ui/dialog/InputDialog$a;

    .line 15
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f110266

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 16
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->c:Ljava/lang/String;

    .line 17
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    .line 18
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->d:Ljava/lang/String;

    .line 19
    iput v2, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->e:I

    .line 20
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "input"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public final e0(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    const-string v0, "/"

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    const p1, 0x7f1100ae

    .line 2
    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    return-void

    .line 3
    :cond_0
    :try_start_0
    invoke-static {p1}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "\\?"

    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    aget-object v1, v1, v2

    .line 4
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\\."

    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    aget-object v4, v4, v5

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {v1, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 5
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->createOrExistsDir(Ljava/lang/String;)Z

    .line 7
    invoke-static {p0}, Lcom/arialyy/aria/core/Aria;->download(Ljava/lang/Object;)Lcom/arialyy/aria/core/download/DownloadReceiver;

    move-result-object v2

    .line 8
    invoke-virtual {v2, p1}, Lcom/arialyy/aria/core/download/DownloadReceiver;->load(Ljava/lang/String;)Lcom/arialyy/aria/core/download/target/HttpBuilderTarget;

    move-result-object p1

    .line 9
    invoke-virtual {p1, p2}, Lcom/arialyy/aria/core/inf/AbsTarget;->setExtendField(Ljava/lang/String;)Lcom/arialyy/aria/core/inf/AbsTarget;

    move-result-object p1

    check-cast p1, Lcom/arialyy/aria/core/download/target/HttpBuilderTarget;

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    .line 10
    invoke-virtual {p1, p2}, Lcom/arialyy/aria/core/download/target/HttpBuilderTarget;->setFilePath(Ljava/lang/String;)Lcom/arialyy/aria/core/download/target/HttpBuilderTarget;

    move-result-object p1

    .line 11
    invoke-virtual {p1}, Lcom/arialyy/aria/core/common/AbsBuilderTarget;->ignoreFilePathOccupy()Lcom/arialyy/aria/core/common/AbsBuilderTarget;

    move-result-object p1

    check-cast p1, Lcom/arialyy/aria/core/download/target/HttpBuilderTarget;

    .line 12
    invoke-virtual {p1}, Lcom/arialyy/aria/core/common/AbsBuilderTarget;->create()J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 13
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public final f0()V
    .locals 4

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    const v0, 0x7f1100da

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 5
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 6
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v1, 0x0

    const-string v2, "ID_abnormal"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    const v0, 0x7f1100cf

    .line 7
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 10
    :cond_1
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    const/4 v1, 0x0

    cmpl-float v2, v0, v1

    if-lez v2, :cond_2

    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    cmpl-float v1, v2, v1

    if-lez v1, :cond_2

    cmpl-float v0, v0, v2

    if-lez v0, :cond_2

    const v0, 0x7f1100e7

    .line 11
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    return-void

    .line 12
    :cond_2
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    if-eqz v0, :cond_3

    .line 13
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L()I

    move-result v0

    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->E:I

    if-gez v0, :cond_3

    const v0, 0x7f1100d1

    .line 14
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    :cond_3
    const-string v0, ";BD:100,10,5;BD:100,3;"

    .line 15
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 16
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    invoke-virtual {v0}, Landroidx/databinding/ViewDataBinding;->getRoot()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/z4;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/z4;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    const-wide/16 v2, 0x32

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public g()I
    .locals 1

    const v0, 0x7f0c0085

    return v0
.end method

.method public final g0(Landroid/widget/CheckBox;Z)V
    .locals 3

    if-eqz p1, :cond_1

    .line 1
    instance-of v0, p1, Landroid/widget/CheckBox;

    if-eqz v0, :cond_1

    if-eqz p2, :cond_1

    const/4 p2, 0x0

    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_0

    .line 4
    instance-of v2, v1, Landroid/widget/CheckBox;

    if-eqz v2, :cond_0

    if-eq v1, p1, :cond_0

    .line 5
    invoke-virtual {v1, p2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final h0(Ljava/lang/String;)V
    .locals 17

    move-object/from16 v0, p0

    .line 1
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    move-object/from16 v2, p1

    invoke-static {v1, v2}, Lc/b/a/a/m/d;->K(Lcn/upus/app/upprinting/data/bean/CutSettings;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    iget v2, v0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    const/4 v3, 0x0

    cmpg-float v3, v3, v2

    if-gez v3, :cond_9

    const/high16 v3, 0x43200000    # 160.0f

    cmpg-float v2, v2, v3

    if-gez v2, :cond_9

    const-string v2, ";"

    .line 3
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 4
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v5, 0x0

    .line 5
    :goto_0
    array-length v6, v1

    const-string v7, " "

    if-ge v5, v6, :cond_8

    .line 6
    aget-object v6, v1, v5

    .line 7
    array-length v8, v1

    const/4 v9, 0x1

    sub-int/2addr v8, v9

    const-string v10, ","

    if-eq v5, v8, :cond_1

    const-string v7, "FSIZE"

    .line 8
    invoke-virtual {v6, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_0

    .line 9
    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    .line 10
    aget-object v8, v6, v9

    invoke-virtual {v8, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    .line 11
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v6, v6, v4

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v6, v8, v9

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v6, v8, v4

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 12
    :cond_0
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 13
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_5

    :cond_1
    const-string v8, ""

    const-string v11, " @"

    .line 14
    invoke-virtual {v6, v11, v8}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    .line 15
    invoke-virtual {v6, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x0

    .line 16
    :goto_1
    array-length v12, v6

    if-ge v11, v12, :cond_7

    .line 17
    aget-object v12, v6, v11

    .line 18
    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v13

    if-eqz v13, :cond_2

    goto :goto_2

    .line 19
    :cond_2
    invoke-virtual {v12, v4, v9}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v13

    const-string v14, "U"

    .line 20
    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    const-string v9, "D"

    if-nez v15, :cond_4

    invoke-virtual {v13, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_3

    goto :goto_3

    .line 21
    :cond_3
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_2
    move-object/from16 v16, v1

    const/4 v1, 0x0

    const/4 v13, 0x1

    goto :goto_4

    .line 22
    :cond_4
    :goto_3
    invoke-virtual {v12, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v15

    if-eqz v15, :cond_5

    const/4 v4, 0x2

    move-object/from16 v16, v1

    .line 23
    array-length v1, v15

    if-ne v4, v1, :cond_6

    .line 24
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    .line 25
    aget-object v4, v15, v1

    const/4 v13, 0x1

    .line 26
    aget-object v12, v15, v13

    .line 27
    invoke-virtual {v4, v14, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 28
    invoke-virtual {v4, v9, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 29
    invoke-virtual {v12, v14, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 30
    invoke-virtual {v12, v9, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    .line 31
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_4

    :cond_5
    move-object/from16 v16, v1

    :cond_6
    const/4 v1, 0x0

    const/4 v13, 0x1

    .line 32
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_4
    add-int/lit8 v11, v11, 0x1

    move-object/from16 v1, v16

    const/4 v4, 0x0

    const/4 v9, 0x1

    goto/16 :goto_1

    :cond_7
    :goto_5
    move-object/from16 v16, v1

    const/4 v1, 0x0

    add-int/lit8 v5, v5, 0x1

    move-object/from16 v1, v16

    const/4 v4, 0x0

    goto/16 :goto_0

    :cond_8
    const-string v1, "U0,0"

    .line 33
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "@ "

    .line 35
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 37
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    .line 38
    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d([B)V

    goto :goto_6

    .line 39
    :cond_9
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    .line 40
    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d([B)V

    :goto_6
    return-void
.end method

.method public i0(Ljava/lang/String;)V
    .locals 3

    .line 1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_3

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M:Ljava/lang/String;

    const-string v1, "0"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    const v1, 0x7f1101ae

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v0, 0x1

    .line 5
    sput-boolean v0, Lc/b/a/a/k/d;->j:Z

    .line 6
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0(Ljava/lang/String;)V

    .line 7
    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->T:Z

    if-eqz p1, :cond_3

    .line 8
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->l0()V

    .line 9
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->G()V

    .line 10
    iget p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->D:I

    add-int/2addr p1, v0

    iput p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->D:I

    .line 11
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->D:I

    .line 12
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "N_cutNumber2"

    invoke-virtual {p1, v1, v0}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    const-string p1, "Y"

    .line 13
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0(Ljava/lang/String;)V

    goto/16 :goto_2

    .line 14
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M:Ljava/lang/String;

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    .line 15
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_1

    goto :goto_0

    .line 16
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 17
    :cond_2
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 18
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/fragment/app/DialogFragment;->setCancelable(Z)V

    .line 19
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v2, Lc/b/a/a/l/b/e5;

    invoke-direct {v2, p0, p1}, Lc/b/a/a/l/b/e5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Ljava/lang/String;)V

    .line 20
    iput-object v2, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 21
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    .line 22
    iput v1, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->g:I

    .line 23
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f11009d

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 24
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->f:Ljava/lang/String;

    .line 25
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f110065

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 26
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 27
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "customdialog"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    :cond_3
    :goto_2
    return-void
.end method

.method public final j0()V
    .locals 8

    .line 1
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    int-to-double v0, v0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    div-double/2addr v0, v2

    double-to-float v0, v0

    .line 2
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string v3, "%.1f"

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 3
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->a:Landroid/widget/Button;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f1101d7

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\u00b0)"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 5
    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    if-nez v1, :cond_0

    .line 6
    invoke-static {p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v1

    .line 7
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->a:Landroid/widget/Button;

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    goto :goto_0

    .line 9
    :cond_0
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->a:Landroid/widget/Button;

    const v2, 0x7f0600e4

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackgroundResource(I)V

    :goto_0
    const/high16 v1, 0x3f800000    # 1.0f

    .line 11
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    .line 12
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const/high16 v2, 0x40a00000    # 5.0f

    div-float/2addr v1, v2

    float-to-int v1, v1

    .line 13
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    float-to-double v2, v2

    int-to-double v4, v1

    const-wide v6, 0x3fa47ae147ae147bL    # 0.04

    mul-double v4, v4, v6

    sub-double/2addr v2, v4

    double-to-float v1, v2

    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    .line 14
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m:Z

    const/high16 v3, -0x40800000    # -1.0f

    if-eqz v2, :cond_1

    mul-float v1, v1, v3

    .line 15
    :cond_1
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->t:F

    .line 16
    iget-boolean v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n:Z

    if-eqz v4, :cond_2

    mul-float v1, v2, v3

    mul-float v2, v2, v3

    .line 17
    :cond_2
    iget-object v4, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 18
    check-cast v4, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v4, v4, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-virtual {v4, v1}, Landroid/widget/ImageView;->setScaleX(F)V

    .line 19
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 20
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setScaleY(F)V

    .line 21
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 22
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    mul-float v0, v0, v3

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setRotation(F)V

    return-void
.end method

.method public final k0(I)V
    .locals 2

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    return-void

    .line 2
    :cond_0
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n:Z

    if-eqz v0, :cond_2

    :cond_1
    mul-int/lit8 p1, p1, -0x1

    .line 3
    :cond_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "BD:8,"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ";"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e([B)V

    return-void
.end method

.method public l()V
    .locals 11

    .line 1
    invoke-static {p0}, Lcom/arialyy/aria/core/Aria;->download(Ljava/lang/Object;)Lcom/arialyy/aria/core/download/DownloadReceiver;

    move-result-object v0

    invoke-virtual {v0}, Lcom/arialyy/aria/core/download/DownloadReceiver;->register()V

    .line 2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lcn/upus/app/upprinting/MApp;->F:Ljava/text/SimpleDateFormat;

    invoke-static {v1}, Lcom/blankj/utilcode/util/TimeUtils;->getNowString(Ljava/text/DateFormat;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "AppVersion:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3
    invoke-static {}, Lcom/blankj/utilcode/util/AppUtils;->getAppVersionName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "BinVersion:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 5
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "SVER"

    const-string v3, ""

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 6
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N:Ljava/lang/String;

    .line 7
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "-"

    invoke-virtual {v0, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->O:Ljava/lang/String;

    const-string v0, "cutBeforeCheck"

    .line 8
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M:Ljava/lang/String;

    .line 9
    invoke-static {}, Lc/b/a/a/m/d;->m0()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->F:Ljava/lang/String;

    .line 10
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 11
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "cutType"

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v4}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 12
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->y:I

    .line 13
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 14
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "SW_cutNumber"

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 15
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->B:Z

    .line 16
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const/16 v2, 0x64

    .line 17
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "N_standard"

    invoke-virtual {v0, v6, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 18
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->C:I

    .line 19
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 20
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "IS_material"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 21
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    .line 22
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 23
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "IS_Mirroring"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 24
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->l:Z

    .line 25
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 26
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "IS_angle"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 27
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r:Z

    .line 28
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 29
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "START_ET_LOCK"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 30
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->u:Z

    .line 31
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 32
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "IS_UVFlim"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 33
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->o:Z

    .line 34
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 35
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "MaxWidth"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    int-to-float v0, v0

    .line 36
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    .line 37
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 38
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "HVER"

    invoke-virtual {v0, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 39
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->x:Ljava/lang/String;

    .line 40
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 41
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "cutCountShow"

    invoke-virtual {v0, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "0"

    .line 42
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 43
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 44
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v2}, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->b(Ljava/lang/Boolean;)V

    goto :goto_0

    .line 45
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 46
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v2}, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->b(Ljava/lang/Boolean;)V

    .line 47
    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "partno"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    new-array v0, v4, [Ljava/lang/Object;

    const-string v2, "\u4ea7\u54c1\u5217\u8868\u4f20\u8fdb\u6765\u7684\u6807\u8bc6\u53f7\uff1a"

    .line 48
    invoke-static {v2}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v6, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v5

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 49
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-static {v0}, Lc/a/a/j/a;->z(Ljava/lang/String;)Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    .line 50
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "pltCode"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->X:Ljava/lang/String;

    .line 51
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "pltVersion"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Y:Ljava/lang/String;

    .line 52
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "cutSettings"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/data/bean/CutSettings;

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    .line 53
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "cameraCutout"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Z:Ljava/lang/String;

    .line 54
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v2, "bladePosition"

    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->a0:Ljava/lang/String;

    .line 55
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 56
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    new-instance v2, Lc/b/a/a/l/b/g0;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/g0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 57
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 58
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->d:Landroid/widget/ImageButton;

    new-instance v2, Lc/b/a/a/l/b/h0;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/h0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 59
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 60
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v2, Lc/b/a/a/l/b/j5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/j5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 61
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 62
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v2, Lc/b/a/a/l/b/d0;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/d0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 63
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 64
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v2, Lc/b/a/a/l/b/k5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/k5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 65
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 66
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->e:Landroid/widget/CheckBox;

    new-instance v2, Lc/b/a/a/l/b/e0;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/e0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 67
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 68
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->f:Landroid/widget/CheckBox;

    new-instance v2, Lc/b/a/a/l/b/c0;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/c0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 69
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 70
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->g:Landroid/widget/CheckBox;

    new-instance v2, Lc/b/a/a/l/b/a0;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/a0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 71
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 72
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    new-instance v2, Lc/b/a/a/l/b/j0;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/j0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 73
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 74
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->a:Landroid/widget/Button;

    new-instance v2, Lc/b/a/a/l/b/l5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/l5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 75
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 76
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->q:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v2, Lc/b/a/a/l/b/m5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/m5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 77
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 78
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->i:Landroid/widget/ImageButton;

    new-instance v2, Lc/b/a/a/l/b/n5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/n5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 79
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 80
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->j:Landroid/widget/ImageButton;

    new-instance v2, Lc/b/a/a/l/b/o5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/o5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 81
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 82
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->k:Landroid/widget/ImageButton;

    new-instance v2, Lc/b/a/a/l/b/p5;

    invoke-direct {v2, p0}, Lc/b/a/a/l/b/p5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 83
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    const/16 v2, 0x8

    const v6, 0x7f1100d4

    const/4 v7, 0x2

    if-eqz v0, :cond_11

    new-array v0, v4, [Ljava/lang/Object;

    const-string v8, "\u6570\u636e\u7f16\u53f7-\u6570\u636e\u7248\u672c\u53f7\uff1a"

    .line 84
    invoke-static {v8}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-object v9, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->X:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v9, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Y:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    aput-object v8, v0, v5

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 85
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->F:Ljava/lang/String;

    iget-object v8, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-static {v0, v8}, Lc/b/a/a/m/d;->f0(Ljava/lang/String;Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;)Ljava/lang/String;

    move-result-object v0

    .line 86
    iget-object v8, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->X:Ljava/lang/String;

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_1

    iget-object v8, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Y:Ljava/lang/String;

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_1

    const-string v8, "\n"

    .line 87
    invoke-static {v0, v8}, Ld/a/a/a/a;->C(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v8, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->X:Ljava/lang/String;

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Y:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 88
    :cond_1
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 89
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    invoke-virtual {v1, v0}, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->setTitle(Ljava/lang/String;)V

    .line 90
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r0()V

    .line 91
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    if-eqz v0, :cond_6

    .line 92
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_5

    const/4 v0, 0x0

    .line 93
    :goto_1
    sget-object v1, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_5

    .line 94
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 95
    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 96
    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 97
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    const/4 v10, -0x2

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 98
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v9

    if-nez v9, :cond_2

    .line 99
    invoke-virtual {v8, v5, v5, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_2

    :cond_2
    const/16 v9, 0xc

    .line 100
    invoke-virtual {v8, v5, v9, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 101
    :goto_2
    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 102
    sget-object v8, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v8, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 103
    invoke-virtual {p0, v8}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 104
    invoke-virtual {p0, v8}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->I(Ljava/lang/String;)Landroid/widget/CheckBox;

    move-result-object v8

    .line 105
    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 106
    new-instance v9, Lc/b/a/a/l/b/f0;

    invoke-direct {v9, p0}, Lc/b/a/a/l/b/f0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v8, v9}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 107
    iget-object v9, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v8, v0, 0x1

    .line 108
    sget-object v9, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    if-ge v8, v9, :cond_3

    .line 109
    sget-object v9, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v9, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 110
    invoke-virtual {p0, v8}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 111
    invoke-virtual {p0, v8}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->I(Ljava/lang/String;)Landroid/widget/CheckBox;

    move-result-object v8

    .line 112
    invoke-virtual {v1, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 113
    iget-object v9, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->d0:Ljava/util/ArrayList;

    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 114
    new-instance v9, Lc/b/a/a/l/b/i0;

    invoke-direct {v9, p0}, Lc/b/a/a/l/b/i0;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    invoke-virtual {v8, v9}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    goto :goto_4

    .line 115
    :cond_3
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v8, v5, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 116
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v9

    const/4 v10, 0x5

    if-nez v9, :cond_4

    .line 117
    invoke-virtual {v8, v10, v7, v10, v7}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_3

    .line 118
    :cond_4
    invoke-virtual {v8, v10, v10, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    :goto_3
    const/high16 v9, 0x3f800000    # 1.0f

    .line 119
    iput v9, v8, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 120
    new-instance v9, Landroid/widget/Space;

    invoke-direct {v9, p0}, Landroid/widget/Space;-><init>(Landroid/content/Context;)V

    .line 121
    invoke-virtual {v9, v8}, Landroid/widget/Space;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 122
    invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 123
    :goto_4
    iget-object v8, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 124
    check-cast v8, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v8, v8, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->m:Landroid/widget/LinearLayout;

    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x2

    goto/16 :goto_1

    .line 125
    :cond_5
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N()V

    .line 126
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 127
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setEnabled(Z)V

    .line 128
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 129
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v0, v5}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 130
    :cond_6
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->l:Z

    if-eqz v0, :cond_7

    .line 131
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 132
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->f:Landroid/widget/CheckBox;

    invoke-virtual {v0, v5}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 133
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 134
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {v0, v5}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 135
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 136
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->f:Landroid/widget/CheckBox;

    invoke-static {v0}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 137
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 138
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->g:Landroid/widget/CheckBox;

    invoke-static {v0}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 139
    :cond_7
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r:Z

    if-eqz v0, :cond_8

    .line 140
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 141
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->a:Landroid/widget/Button;

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 142
    :cond_8
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->u:Z

    if-eqz v0, :cond_9

    .line 143
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 144
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v0, v5}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 145
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 146
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_5

    .line 147
    :cond_9
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 148
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 149
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 150
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 151
    :goto_5
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 152
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "second_agent_id"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "2555"

    .line 153
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 154
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getIsBack()I

    move-result v0

    if-ne v0, v4, :cond_a

    .line 155
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 156
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->j:Landroid/widget/ImageButton;

    invoke-virtual {v0, v5}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 157
    :cond_a
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 158
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->k:Landroid/widget/ImageButton;

    invoke-virtual {v0, v5}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 159
    :cond_b
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 160
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "Print_Sel_Type"

    invoke-virtual {v0, v1, v7}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 161
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getPrint()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->v:Ljava/lang/String;

    const-string v8, "1"

    .line 162
    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_c

    if-nez v0, :cond_d

    :cond_c
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->v:Ljava/lang/String;

    const-string v8, "2"

    .line 163
    invoke-virtual {v8, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_e

    if-ne v0, v4, :cond_e

    .line 164
    :cond_d
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 165
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->q:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 166
    :cond_e
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 167
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "CutFavorite"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 168
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_12

    .line 169
    new-instance v1, Lcom/google/gson/Gson;

    invoke-direct {v1}, Lcom/google/gson/Gson;-><init>()V

    new-instance v3, Lc/b/a/a/l/b/d5;

    invoke-direct {v3, p0}, Lc/b/a/a/l/b/d5;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    .line 170
    invoke-virtual {v3}, Lcom/google/gson/reflect/TypeToken;->getType()Ljava/lang/reflect/Type;

    move-result-object v3

    .line 171
    invoke-virtual {v1, v0, v3}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/reflect/Type;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/List;

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    if-eqz v0, :cond_12

    const/4 v0, 0x0

    .line 172
    :goto_6
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_12

    .line 173
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->e0:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;

    .line 174
    iget v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->f0:I

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->getSort()I

    move-result v8

    if-ge v3, v8, :cond_f

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->getSort()I

    move-result v3

    goto :goto_7

    :cond_f
    iget v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->f0:I

    :goto_7
    iput v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->f0:I

    .line 175
    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/PartHistoryBean;->getPartno()Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_10

    .line 176
    iput-boolean v5, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->p:Z

    .line 177
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 178
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->e:Landroid/widget/CheckBox;

    invoke-virtual {v1, v4}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 179
    iput-boolean v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->p:Z

    :cond_10
    add-int/lit8 v0, v0, 0x1

    goto :goto_6

    .line 180
    :cond_11
    invoke-static {v6}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(I)V

    .line 181
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 182
    :cond_12
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->y:I

    if-ne v0, v7, :cond_13

    .line 183
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 184
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 185
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 186
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 187
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 188
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 189
    :cond_13
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    if-eqz v0, :cond_14

    .line 190
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->a0()V

    .line 191
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getId()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->V:Ljava/lang/String;

    .line 192
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M()V

    goto :goto_8

    .line 193
    :cond_14
    invoke-static {v6}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(I)V

    .line 194
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_8
    return-void
.end method

.method public final l0()V
    .locals 7

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    .line 3
    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->w:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    .line 4
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    .line 5
    iget-wide v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    const-wide/16 v3, 0x1

    sub-long/2addr v1, v3

    iput-wide v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    .line 6
    iget-wide v5, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->A:J

    add-long/2addr v5, v3

    iput-wide v5, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->A:J

    .line 7
    const-wide v1, 0x1869f
    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setBalaqty(J)V

    .line 8
    iget-wide v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->A:J

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setUseqty(J)V

    .line 9
    iget-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    .line 10
    iget-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->A:J

    .line 11
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 12
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v5

    if-lez v5, :cond_0

    .line 13
    iget-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v2

    int-to-long v2, v2

    add-long/2addr v0, v2

    .line 14
    iget-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->A:J

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    int-to-long v4, v4

    sub-long/2addr v2, v4

    .line 15
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    .line 16
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 17
    iget-object v3, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "USEQTY"

    invoke-virtual {v3, v4, v2}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 18
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 19
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 20
    iget-object v1, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "BALAQTY"

    invoke-virtual {v1, v2, v0}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method

.method public final m0()V
    .locals 6

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getCategoryOneId()Ljava/lang/String;

    move-result-object v0

    .line 2
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getPrint()Ljava/lang/String;

    move-result-object v1

    .line 3
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->o:Z

    const/16 v3, 0x8

    if-eqz v2, :cond_2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_0

    const-string v2, "1"

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2

    .line 4
    :cond_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2

    const-wide/32 v1, 0x6ab07e

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    cmp-long v0, v1, v4

    if-nez v0, :cond_2

    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    const v1, 0x4323ca3d    # 163.79f

    cmpl-float v0, v1, v0

    if-lez v0, :cond_2

    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    const/high16 v1, 0x429f0000    # 79.5f

    cmpl-float v0, v1, v0

    if-lez v0, :cond_2

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-static {v0}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 9
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r:Z

    if-eqz v0, :cond_3

    .line 10
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    if-lez v0, :cond_1

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-virtual {v0, v3}, Landroid/widget/CheckBox;->setVisibility(I)V

    goto :goto_0

    .line 13
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 14
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setVisibility(I)V

    goto :goto_0

    .line 15
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 16
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-virtual {v0, v3}, Landroid/widget/CheckBox;->setVisibility(I)V

    :cond_3
    :goto_0
    return-void
.end method

.method public final n0()V
    .locals 9

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    .line 2
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->K:Ljava/lang/String;

    .line 5
    :cond_0
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    const/4 v3, 0x1

    const-string v4, "BD:33,190,120;"

    const/4 v5, 0x0

    if-eqz v2, :cond_4

    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->E:I

    const/4 v6, -0x1

    if-le v2, v6, :cond_4

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_4

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    const-string v6, "PAGE="

    invoke-virtual {v2, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 6
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->E:I

    if-ltz v2, :cond_2

    .line 7
    sget-object v4, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 8
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    const-string v6, "lastMaterialSize"

    invoke-static {v6}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v7}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getCategoryOneId()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 9
    iget-object v4, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v4, v6, v2}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    const-string v4, "\\*"

    .line 10
    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    .line 11
    array-length v6, v2

    if-eq v4, v6, :cond_1

    return-void

    .line 12
    :cond_1
    aget-object v4, v2, v3

    invoke-static {v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v4

    .line 13
    aget-object v2, v2, v5

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    const-string v6, "BD:33,"

    const-string v7, ","

    const-string v8, ";"

    .line 14
    invoke-static {v6, v4, v7, v2, v8}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    goto :goto_0

    :cond_2
    if-eqz v1, :cond_3

    .line 15
    iput-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    .line 16
    :cond_3
    :goto_0
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    invoke-static {v2, v4, v0}, Ld/a/a/a/a;->v(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_4
    if-eqz v1, :cond_5

    .line 17
    iput-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    .line 18
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    invoke-static {v2, v4, v0}, Ld/a/a/a/a;->v(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 19
    :cond_5
    :goto_1
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m:Z

    if-nez v2, :cond_6

    if-eqz v1, :cond_7

    :cond_6
    const-string v1, "BD:8;"

    .line 20
    invoke-static {v1, v0}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_7
    new-array v1, v3, [Ljava/lang/Object;

    const-string v2, "\u5207\u5272\uff1a"

    .line 21
    invoke-static {v2, v0}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v5

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 22
    iget-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n:Z

    if-eqz v1, :cond_8

    .line 23
    new-instance v1, Lc/b/a/a/l/f/a;

    invoke-direct {v1, p0, v0}, Lc/b/a/a/l/f/a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    new-array v0, v5, [Ljava/lang/String;

    invoke-virtual {v1, v0}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto :goto_2

    .line 24
    :cond_8
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->i0(Ljava/lang/String;)V

    :goto_2
    return-void
.end method

.method public final o0(Z)V
    .locals 3

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "N_cutNumber2"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 3
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->D:I

    .line 4
    iget-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->B:Z

    if-eqz v1, :cond_2

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->C:I

    if-lt v0, v1, :cond_2

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 6
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 7
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 8
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$a;

    invoke-direct {v1, p0, p1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$a;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;Z)V

    .line 9
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 10
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    const v0, 0x7f110054

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 11
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->e:Ljava/lang/String;

    .line 12
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->D:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v1, 0x7f11007c

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 13
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 14
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "customdialog"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    goto :goto_2

    :cond_2
    if-eqz p1, :cond_3

    .line 15
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->f0()V

    goto :goto_2

    .line 16
    :cond_3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->p0()V

    :goto_2
    return-void
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 4
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/FragmentActivity;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p3, :cond_2

    const-string v2, "savePath"

    .line 2
    invoke-virtual {p3, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    if-ne p2, v1, :cond_1

    .line 3
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 4
    iget-object p3, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast p3, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p3, p3, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-virtual {p3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result p3

    if-eqz p3, :cond_0

    .line 6
    iget-object p3, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast p3, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p3, p3, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->h:Landroid/widget/CheckBox;

    invoke-virtual {p3, v0}, Landroid/widget/CheckBox;->setChecked(Z)V

    const/4 p3, 0x0

    .line 8
    iput-object p3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->P:Landroid/graphics/Bitmap;

    const-string p3, ""

    .line 9
    iput-object p3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->K:Ljava/lang/String;

    .line 10
    :cond_0
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->r0()V

    .line 11
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->a0()V

    .line 12
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M()V

    goto :goto_0

    :cond_1
    if-nez p2, :cond_2

    .line 13
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    .line 14
    iput-object p3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->I:Ljava/lang/String;

    .line 15
    iput-object p3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->J:Ljava/lang/String;

    .line 16
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->q:Z

    .line 17
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object p3

    const v2, 0x7f08005d

    invoke-virtual {p3, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    .line 18
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 19
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->j:Landroid/widget/ImageButton;

    invoke-static {v2, p3}, Lc/b/a/a/m/d;->J0(Landroid/widget/ImageButton;Landroid/graphics/drawable/Drawable;)V

    .line 20
    iget-object p3, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    if-eqz p3, :cond_2

    .line 21
    invoke-virtual {p3}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getIconPath()Ljava/lang/String;

    move-result-object p3

    invoke-static {p3}, Lcom/blankj/utilcode/util/FileUtils;->getFileNameNoExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    .line 22
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "tempCustom/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, ".png"

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    new-array v2, v1, [Ljava/lang/Object;

    const-string v3, "imgPath\uff1a"

    .line 23
    invoke-static {v3, p3}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v0

    invoke-static {v2}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 24
    invoke-static {p3}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p3

    .line 25
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 26
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-virtual {v2, p3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_2
    :goto_0
    const/4 p3, 0x2

    if-ne p1, p3, :cond_3

    if-ne p2, v1, :cond_3

    new-array p1, v1, [Ljava/lang/Object;

    const-string p2, "---------- \u5207\u819c\u5df2\u7ecf\u53d6\u6d88\uff01----------"

    aput-object p2, p1, v0

    .line 27
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto :goto_1

    :cond_3
    if-ne p1, p3, :cond_4

    if-ne p2, p3, :cond_4

    .line 28
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n0()V

    :cond_4
    :goto_1
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    const-string v0, "page_onCreate"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onCreate"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    .line 3
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->h0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 5
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->i0:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->i0:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CutMoveDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    .line 7
    :cond_2
    invoke-static {p0}, Lcom/arialyy/aria/core/Aria;->download(Ljava/lang/Object;)Lcom/arialyy/aria/core/download/DownloadReceiver;

    move-result-object v0

    invoke-virtual {v0}, Lcom/arialyy/aria/core/download/DownloadReceiver;->unRegister()V

    .line 8
    invoke-static {}, Lc/b/a/a/m/b;->a()Lc/b/a/a/m/b;

    move-result-object v0

    invoke-virtual {v0}, Lc/b/a/a/m/b;->b()V

    const/4 v0, 0x0

    .line 9
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k0(I)V

    .line 10
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onDestroy()V

    return-void
.end method

.method public onEvent(Lcn/upus/app/upprinting/data/bean/event/MessageEvent;)V
    .locals 11

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object v0

    const-string v1, "home"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "1"

    const/4 v2, 0x1

    const-string v3, ""

    const-string v4, "part_no"

    const/4 v5, 0x0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object v0

    const-string v6, "back"

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 2
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 3
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0, v4, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 4
    sget-boolean v6, Lc/b/a/a/k/d;->j:Z

    if-eqz v6, :cond_1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_1

    iget-object v6, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-array v0, v2, [Ljava/lang/Object;

    const-string v6, "\u5f53\u524d\u9700\u8981\u786e\u8ba4\u653e\u819c\u624d\u80fd\u5207\u5272\uff0c\u5728\u5207\u5272\u8fc7\u7a0b\u4e2d\u56e0\u4e3a\u5f02\u5e38\u63a8\u51fa\u4e86\u5207\u5272\u9875\u9762\uff0c\u56e0\u6b64\u751f\u6210\u79bb\u7ebf\u5207\u5272\u6570\u636e\u5e76\u4fdd\u5b58"

    aput-object v6, v0, v5

    .line 5
    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 6
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 7
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "BALAQTY"

    invoke-virtual {v0, v6, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 8
    invoke-static {v0}, Lc/b/a/a/k/a;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    new-array v0, v2, [Ljava/lang/Object;

    const-string v8, "\u5f53\u524d\u7684\u5269\u4f59\u5207\u5272\u6570\uff1a"

    .line 9
    invoke-static {v8}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    iget-wide v9, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    invoke-virtual {v8, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v9, "\u3001\u5b58\u50a8\u7684\u5269\u4f59\u5207\u5272\u6570\uff1a"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v0, v5

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v0, "Y/N"

    .line 10
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->K(Ljava/lang/String;)Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    move-result-object v0

    .line 11
    invoke-static {v0}, Lc/a/a/j/a;->o(Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)Z

    .line 12
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    .line 13
    invoke-static {}, Lc/b/a/a/k/a;->x()V

    .line 14
    :cond_1
    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onEvent(Lcn/upus/app/upprinting/data/bean/event/MessageEvent;)V

    .line 15
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object v0

    const-string v6, "cut_finish"

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 16
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    const v6, 0x7f1101d8

    invoke-virtual {p0, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 18
    invoke-virtual {p0, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 19
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 20
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0, v4, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v2, v2, [Ljava/lang/Object;

    const-string v3, "\u6b63\u5728\u5207\u5272\u7684\u6807\u8bc6\u53f7\uff1a"

    const-string v6, "\u3001\u4ea7\u54c1\u5217\u8868\u4f20\u8fdb\u6765\u7684\u6807\u8bc6\u53f7\uff1a"

    .line 21
    invoke-static {v3, v0, v6}, Ld/a/a/a/a;->D(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v6, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v5

    invoke-static {v2}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 22
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_5

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->W:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5

    .line 23
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 24
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0, v4}, Lcom/tencent/mmkv/MMKV;->o(Ljava/lang/String;)V

    .line 25
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 26
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 27
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 28
    :cond_3
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 29
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0, v5}, Landroidx/fragment/app/DialogFragment;->setCancelable(Z)V

    .line 30
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$e;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$e;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    .line 31
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 32
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    .line 33
    iput v5, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->g:I

    .line 34
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f11007d

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 35
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 36
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f11008d

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 37
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->f:Ljava/lang/String;

    .line 38
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f110073

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 39
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->e:Ljava/lang/String;

    .line 40
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "customdialog"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    goto :goto_2

    .line 41
    :cond_4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->M:Ljava/lang/String;

    const-string v1, "0"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 42
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->q:Z

    if-eqz v0, :cond_6

    .line 43
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_2

    .line 44
    :cond_5
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->q:Z

    if-eqz v0, :cond_6

    .line 45
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 46
    :cond_6
    :goto_2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object p1

    const-string v0, "recharge_finish"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    .line 47
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getBalaqty()J

    move-result-wide v0

    iput-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    .line 48
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getUseqty()J

    move-result-wide v0

    iput-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->A:J

    :cond_7
    return-void
.end method

.method public onPause()V
    .locals 2

    const-string v0, "onPause"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onPause()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onRestart()V
    .locals 2

    const-string v0, "page_onReStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onRestart()V

    return-void
.end method

.method public onResume()V
    .locals 4

    const-string v0, "onResume"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 1
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onResume()V

    .line 2
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getBalaqty()J

    move-result-wide v2

    iput-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    .line 3
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getUseqty()J

    move-result-wide v2

    iput-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->A:J

    const-string v2, "page_onResume"

    const/4 v3, 0x0

    .line 4
    invoke-static {p0, v2, v3}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onSerialPortEvent(Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;)V
    .locals 14
    .annotation runtime Li/b/a/k;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;->getData()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "\u63a5\u6536\u5230\u7684\u4ea7\u54c1\u5207\u5272\u4e32\u53e3\u6570\u636e\uff1a"

    .line 2
    invoke-static {v2, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v1, "FSIZE="

    .line 3
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    const-string v4, ","

    const-string v5, ";"

    const/4 v6, 0x2

    if-eqz v2, :cond_b

    .line 4
    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L:Ljava/lang/String;

    .line 5
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const-string v7, ""

    if-eqz v2, :cond_8

    .line 6
    invoke-virtual {p1, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 7
    array-length v8, v2

    if-ge v8, v6, :cond_0

    return-void

    .line 8
    :cond_0
    aget-object v2, v2, v3

    .line 9
    invoke-virtual {v2, v1, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 10
    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 11
    array-length v2, v1

    const-string v4, " mm"

    const-string v8, " L:"

    const-string v9, "W:"

    const/high16 v10, 0x42200000    # 40.0f

    if-ne v2, v6, :cond_3

    .line 12
    aget-object v2, v1, v3

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v10

    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    .line 13
    aget-object v1, v1, v0

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v10

    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    .line 14
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    float-to-int v6, v2

    float-to-int v1, v1

    int-to-float v10, v6

    cmpg-float v2, v10, v2

    if-gez v2, :cond_1

    add-int/lit8 v6, v6, 0x1

    :cond_1
    int-to-float v2, v1

    .line 15
    iget v10, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    cmpg-float v2, v2, v10

    if-gez v2, :cond_2

    add-int/lit8 v1, v1, 0x1

    .line 16
    :cond_2
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->r:Landroid/widget/TextView;

    invoke-static {v9, v6, v8, v1, v4}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 18
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m0()V

    goto/16 :goto_0

    .line 19
    :cond_3
    array-length v2, v1

    const/4 v11, 0x4

    if-ne v2, v11, :cond_8

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->G:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_8

    const/4 v2, 0x3

    .line 20
    aget-object v2, v1, v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    .line 21
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m:Z

    if-nez v2, :cond_4

    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n:Z

    if-eqz v2, :cond_5

    .line 22
    :cond_4
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    mul-int/lit8 v2, v2, -0x1

    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->s:I

    .line 23
    :cond_5
    aget-object v2, v1, v6

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    rem-int/lit8 v2, v2, 0xb

    .line 24
    iget-object v6, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->G:Ljava/lang/String;

    add-int/lit8 v12, v2, 0x2

    invoke-virtual {v6, v2, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    .line 25
    iget-object v13, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->G:Ljava/lang/String;

    add-int/2addr v2, v11

    invoke-virtual {v13, v12, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const/16 v11, 0x10

    .line 26
    invoke-static {v6, v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v6

    .line 27
    invoke-static {v2, v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v2

    .line 28
    aget-object v11, v1, v3

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    add-int/2addr v11, v6

    int-to-float v6, v11

    div-float/2addr v6, v10

    iput v6, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    .line 29
    aget-object v1, v1, v0

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    add-int/2addr v1, v2

    int-to-float v1, v1

    div-float/2addr v1, v10

    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    .line 30
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    float-to-int v6, v2

    float-to-int v1, v1

    int-to-float v10, v6

    cmpg-float v2, v10, v2

    if-gez v2, :cond_6

    add-int/lit8 v6, v6, 0x1

    :cond_6
    int-to-float v2, v1

    .line 31
    iget v10, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->S:F

    cmpg-float v2, v2, v10

    if-gez v2, :cond_7

    add-int/lit8 v1, v1, 0x1

    .line 32
    :cond_7
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 33
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->r:Landroid/widget/TextView;

    invoke-static {v9, v6, v8, v1, v4}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 34
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->m0()V

    .line 35
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->j0()V

    :cond_8
    :goto_0
    const-string v1, "PAGE="

    .line 36
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_12

    .line 37
    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 38
    array-length v1, p1

    const/4 v2, 0x2

    if-ge v1, v2, :cond_9

    return-void

    .line 39
    :cond_9
    aget-object p1, p1, v0

    .line 40
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_a

    .line 41
    invoke-virtual {p1, v5, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 42
    :cond_a
    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Q:Ljava/lang/String;

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u9ed8\u8ba4\u5207\u5272\u5c3a\u5bf8\uff1a"

    .line 43
    invoke-static {v0}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Q:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    aput-object v0, p1, v3

    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 44
    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    if-eqz p1, :cond_12

    .line 45
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->N()V

    goto/16 :goto_2

    :cond_b
    const-string v1, "RCMD=10,"

    .line 46
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_10

    const-string v1, "RCMD=10,1;"

    .line 47
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_c

    .line 48
    sput-boolean v0, Lc/b/a/a/k/d;->j:Z

    .line 49
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 50
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    const v1, 0x7f1100da

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u5f53\u524d\u8bbe\u5907\u5de5\u4f5c\u72b6\u6001\uff1a\u8bbe\u5907\u5de5\u4f5c/\u91cd\u7f6e"

    aput-object v0, p1, v3

    .line 51
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto/16 :goto_2

    :cond_c
    const-string v1, "RCMD=10,0;"

    .line 52
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_12

    .line 53
    invoke-virtual {p1, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 54
    array-length v1, p1

    const-string v2, "\u83b7\u53d6\u673a\u5668\u72b6\u6001\uff1a\u6570\u636e\u9519\u8bef"

    const v5, 0x7f1100d4

    const-string v6, " "

    const v7, 0x7f1100d9

    const/4 v8, 0x2

    if-eq v1, v8, :cond_d

    .line 55
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 56
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v7}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    aput-object v2, p1, v3

    .line 57
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    return-void

    .line 58
    :cond_d
    aget-object p1, p1, v0

    invoke-virtual {p1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 59
    array-length v1, p1

    const/4 v4, 0x2

    if-lt v1, v4, :cond_f

    aget-object v1, p1, v0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_e

    goto :goto_1

    .line 60
    :cond_e
    aget-object p1, p1, v0

    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/cut/cutjni/JniUtils;->getHandshake(J)[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u4e00\u6b21\u53d1\u5b8c\u63e1\u624b\u6570\u636e"

    aput-object v0, p1, v3

    .line 61
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto :goto_2

    .line 62
    :cond_f
    :goto_1
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 63
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v7}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    aput-object v2, p1, v3

    .line 64
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    return-void

    :cond_10
    const-string v1, "RCMD=12,"

    .line 65
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_12

    const-string v1, "RCMD=12,0;"

    .line 66
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_12

    new-array p1, v0, [Ljava/lang/Object;

    const-string v1, "\u63e1\u624b\u6210\u529f\uff0c\u5f00\u59cb\u5207\u5272"

    aput-object v1, p1, v3

    .line 67
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string p1, "material"

    .line 68
    invoke-static {p1}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "1"

    .line 69
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_11

    .line 70
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/CutSettings;->getFilmSize()Ljava/lang/String;

    move-result-object p1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "\u5207\u5272\u5c3a\u5bf8\uff08\u5fb7\u56fd\u5ba2\u6237\uff09\uff1a"

    .line 71
    invoke-static {v1, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 72
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->c0:Lcn/upus/app/upprinting/data/bean/CutSettings;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->Z:Ljava/lang/String;

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->a0:Ljava/lang/String;

    invoke-static {p0, v0, p1, v1, v2}, Lcn/upus/app/upprinting/ui/activity/setting/SettingSureActivity;->p(Landroid/app/Activity;Lcn/upus/app/upprinting/data/bean/CutSettings;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_2

    .line 73
    :cond_11
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->n0()V

    :cond_12
    :goto_2
    return-void
.end method

.method public onStart()V
    .locals 2

    const-string v0, "page_onStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onStart"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStart()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onStop()V
    .locals 2

    const-string v0, "page_onStop"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStop()V

    return-void
.end method

.method public final p0()V
    .locals 12

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "cutNet"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 3
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v0

    if-nez v0, :cond_0

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    const v1, 0x7f1100ab

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 6
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 7
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "offCutMax"

    invoke-virtual {v0, v3, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    const v3, 0x7f1100ce

    if-lez v0, :cond_1

    .line 8
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_1

    .line 9
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-lt v4, v0, :cond_1

    .line 10
    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 13
    :cond_1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 14
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "ID_abnormal"

    invoke-virtual {v0, v4, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_2

    const v0, 0x7f1100cf

    .line 15
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 16
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 18
    :cond_2
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->R:F

    const/4 v4, 0x0

    cmpl-float v5, v0, v4

    if-lez v5, :cond_3

    iget v5, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->w:F

    cmpl-float v4, v5, v4

    if-lez v4, :cond_3

    cmpl-float v0, v0, v5

    if-lez v0, :cond_3

    const v0, 0x7f1100e7

    .line 19
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    return-void

    .line 20
    :cond_3
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->k:Z

    if-eqz v0, :cond_4

    .line 21
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->L()I

    move-result v0

    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->E:I

    if-gez v0, :cond_4

    const v0, 0x7f1100d1

    .line 22
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 23
    :cond_4
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->y:I

    if-ne v0, v1, :cond_5

    new-array v0, v1, [Ljava/lang/Object;

    const-string v3, "\u5269\u4f59\u5207\u5272\u6570\uff1a"

    .line 24
    invoke-static {v3}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v4, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 25
    iget-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->z:J

    const-wide/16 v4, 0x1

    cmp-long v0, v2, v4

    if-gez v0, :cond_7

    const v0, 0x7f1100cd

    .line 26
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 27
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 28
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 29
    :cond_5
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-wide/16 v4, 0x0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 30
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    const-string v2, "netCurrentTime"

    invoke-virtual {v0, v2, v6, v7}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v6

    .line 31
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 32
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    const-string v2, "cutCurrentTime"

    invoke-virtual {v0, v2, v8, v9}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v8

    .line 33
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 34
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const-string v2, "cutEndTime"

    invoke-virtual {v0, v2, v4, v5}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v4

    sub-long v6, v8, v6

    const-wide/32 v10, 0x5265c00

    cmp-long v0, v6, v10

    if-lez v0, :cond_6

    .line 35
    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 36
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 37
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_6
    cmp-long v0, v4, v8

    if-gez v0, :cond_7

    const v0, 0x7f1100d0

    .line 38
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 39
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 40
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 41
    :cond_7
    invoke-virtual {p0, v1}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->q0(Z)V

    return-void
.end method

.method public final q0(Z)V
    .locals 1

    .line 1
    iput-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->T:Z

    .line 2
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->p:Landroid/widget/TextView;

    const v0, 0x7f1100d9

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x0

    .line 4
    sput-boolean p1, Lc/b/a/a/k/d;->j:Z

    .line 5
    invoke-static {}, Lc/b/a/a/k/a;->t()[B

    move-result-object p1

    .line 6
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    return-void
.end method

.method public final r0()V
    .locals 5

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    if-eqz v0, :cond_4

    .line 2
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getIconPath()Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->getFileNameNoExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "prCustom/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, ".png"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 5
    invoke-static {v2}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 6
    invoke-static {v2}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 7
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 9
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f08005d

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 10
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->i:Landroid/widget/ImageButton;

    invoke-static {v1, v0}, Lc/b/a/a/m/d;->J0(Landroid/widget/ImageButton;Landroid/graphics/drawable/Drawable;)V

    goto/16 :goto_1

    .line 12
    :cond_0
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const v3, 0x7f08005f

    if-nez v2, :cond_3

    const/16 v2, 0x2f

    .line 13
    invoke-virtual {v0, v2}, Ljava/lang/String;->indexOf(I)I

    move-result v2

    const/4 v4, -0x1

    if-ne v2, v4, :cond_1

    .line 14
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->getFileExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "/"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 15
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-static {v2, v4, v0, v1}, Ld/a/a/a/a;->w(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 16
    :cond_1
    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 17
    sget-object v1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 18
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 19
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-static {v1, v0, v2}, Lc/b/a/a/m/m/a;->d(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    goto :goto_0

    .line 20
    :cond_2
    sget-object v0, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 21
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getDetailIcon()Ljava/lang/String;

    move-result-object v1

    .line 22
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 23
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-static {v0, v1, v2}, Lc/b/a/a/m/m/a;->c(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 24
    :goto_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 25
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->i:Landroid/widget/ImageButton;

    invoke-virtual {v0, v3}, Landroid/widget/ImageButton;->setBackgroundResource(I)V

    goto :goto_1

    .line 26
    :cond_3
    sget-object v0, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 27
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;->b0:Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/dbBean/PartListBean;->getDetailIcon()Ljava/lang/String;

    move-result-object v1

    .line 28
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 29
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->l:Landroid/widget/ImageView;

    invoke-static {v0, v1, v2}, Lc/b/a/a/m/m/a;->c(Landroid/content/Context;Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 30
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 31
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityFilmCutBinding;->i:Landroid/widget/ImageButton;

    invoke-virtual {v0, v3}, Landroid/widget/ImageButton;->setBackgroundResource(I)V

    .line 32
    :goto_1
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$f;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/FilmCutActivity$f;-><init>(Lcn/upus/app/upprinting/ui/activity/FilmCutActivity;)V

    const-wide/16 v2, 0x12c

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_4
    return-void
.end method
