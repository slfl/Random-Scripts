.class public Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;
.super Lcn/upus/app/upprinting/base/BaseDataBindingActivity;
.source "PltFileCutActivity.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcn/upus/app/upprinting/base/BaseDataBindingActivity<",
        "Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;",
        ">;"
    }
.end annotation


# instance fields
.field public A:I

.field public B:I

.field public C:Ljava/lang/String;

.field public D:Ljava/lang/String;

.field public E:Ljava/lang/String;

.field public F:Ljava/lang/String;

.field public G:Ljava/lang/String;

.field public H:Ljava/lang/String;

.field public I:Landroid/graphics/Bitmap;

.field public J:Landroid/graphics/Bitmap;

.field public K:Ljava/lang/String;

.field public L:F

.field public M:F

.field public N:Z

.field public O:Ljava/lang/String;

.field public P:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/widget/CheckBox;",
            ">;"
        }
    .end annotation
.end field

.field public Q:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/SetCutAngleDialog;",
            ">;"
        }
    .end annotation
.end field

.field public R:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/InputDialog;",
            ">;"
        }
    .end annotation
.end field

.field public S:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/CutMoveDialog;",
            ">;"
        }
    .end annotation
.end field

.field public T:Ljava/lang/String;

.field public U:Ljava/lang/String;

.field public k:Z

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:I

.field public r:F

.field public s:Z

.field public t:F

.field public u:Ljava/lang/String;

.field public v:I

.field public w:J

.field public x:J

.field public y:Z

.field public z:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->k:Z

    .line 3
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->l:Z

    .line 4
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->m:Z

    .line 5
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->n:Z

    .line 6
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->o:Z

    .line 7
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->p:Z

    .line 8
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->q:I

    const/high16 v1, 0x3f800000    # 1.0f

    .line 9
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->r:F

    .line 10
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->s:Z

    const/4 v0, 0x0

    .line 11
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    const/4 v1, -0x1

    .line 12
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->B:I

    const-string v1, ""

    .line 13
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D:Ljava/lang/String;

    .line 14
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->E:Ljava/lang/String;

    .line 15
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    .line 16
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->K:Ljava/lang/String;

    .line 17
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    .line 18
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    .line 19
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    const/4 v0, 0x0

    .line 20
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->Q:Ljava/lang/ref/WeakReference;

    .line 21
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->S:Ljava/lang/ref/WeakReference;

    return-void
.end method

.method public static synthetic A(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->U()V

    return-void
.end method

.method public static synthetic B(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->Q(I)V

    return-void
.end method

.method public static H(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "cutDataFilePath"

    .line 2
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "fileName"

    .line 3
    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 4
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public static synthetic p(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;Z)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->T(Z)V

    return-void
.end method

.method public static q(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V
    .locals 3

    if-eqz p0, :cond_4

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    const v0, 0x7f1100da

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_2

    .line 5
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 6
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v1, 0x0

    const-string v2, "ID_abnormal"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    const v0, 0x7f1100cf

    .line 7
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    .line 10
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 11
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    goto :goto_1

    .line 12
    :cond_3
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    .line 13
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    new-instance v1, Lc/b/a/a/l/b/r2;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r2;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    .line 14
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->b:Lcn/upus/app/upprinting/ui/dialog/InputDialog$a;

    .line 15
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f110266

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 16
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->c:Ljava/lang/String;

    .line 17
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    .line 18
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->d:Ljava/lang/String;

    .line 19
    iput v2, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->e:I

    .line 20
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p0

    const-string v1, "input"

    invoke-virtual {v0, p0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    :goto_2
    return-void

    :cond_4
    const/4 p0, 0x0

    .line 21
    throw p0
.end method

.method public static synthetic r(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P()V

    return-void
.end method

.method public static s(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    if-eqz p0, :cond_0

    .line 1
    new-instance v9, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v9}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    new-instance v0, Lc/b/a/a/l/b/v6;

    invoke-direct {v0, p0}, Lc/b/a/a/l/b/v6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v9, p0, v0}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 3
    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->G:Ljava/lang/String;

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->H:Ljava/lang/String;

    iget v6, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->v:I

    const-string v0, "on"

    const-string v1, "-10"

    const-string v2, ""

    const-string v8, "0"

    move-object v5, p1

    move-object v7, p2

    invoke-static/range {v0 .. v9}, Lc/b/a/a/h/c/e;->L(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void

    :cond_0
    const/4 p0, 0x0

    .line 4
    throw p0
.end method

.method public static t(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static u(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static v(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;Ljava/lang/String;Z)V
    .locals 2

    if-eqz p0, :cond_0

    .line 1
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    new-instance v1, Lc/b/a/a/l/b/t6;

    invoke-direct {v1, p0, p2, p1}, Lc/b/a/a/l/b/t6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;ZLjava/lang/String;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 3
    invoke-static {p1, v0}, Lc/b/a/a/h/c/e;->m(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void

    :cond_0
    const/4 p0, 0x0

    .line 4
    throw p0
.end method

.method public static w(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;Ljava/lang/String;)V
    .locals 2

    if-eqz p0, :cond_0

    const-string v0, ";BD:100,10,5;BD:100,4;"

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    invoke-virtual {v0}, Landroidx/databinding/ViewDataBinding;->getRoot()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/u6;

    invoke-direct {v1, p0, p1}, Lc/b/a/a/l/b/u6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;Ljava/lang/String;)V

    const-wide/16 p0, 0x32

    invoke-virtual {v0, v1, p0, p1}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void

    :cond_0
    const/4 p0, 0x0

    .line 4
    throw p0
.end method

.method public static x(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static synthetic y(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;Z)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->V(Z)V

    return-void
.end method

.method public static synthetic z(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->N()V

    return-void
.end method


# virtual methods
.method public final C(Ljava/lang/String;)Landroid/widget/CheckBox;
    .locals 4

    .line 1
    invoke-static {p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v0

    .line 2
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/4 v3, -0x2

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v2, 0x5

    .line 3
    invoke-virtual {v1, v2, v2, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    const/high16 v3, 0x3f800000    # 1.0f

    .line 4
    iput v3, v1, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 5
    new-instance v3, Landroid/widget/CheckBox;

    invoke-direct {v3, p0}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 6
    invoke-virtual {v3, v1}, Landroid/widget/CheckBox;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 7
    invoke-virtual {v3, v2}, Landroid/widget/CheckBox;->setTextAlignment(I)V

    .line 8
    invoke-virtual {v3, v0}, Landroid/widget/CheckBox;->setTextColor(I)V

    const v0, 0x7f08007b

    .line 9
    invoke-virtual {v3, v0}, Landroid/widget/CheckBox;->setButtonDrawable(I)V

    .line 10
    invoke-static {v3}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 11
    invoke-virtual {v3, p1}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41400000    # 12.0f

    .line 12
    invoke-virtual {v3, p1}, Landroid/widget/CheckBox;->setTextSize(F)V

    return-object v3
.end method

.method public final D(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v0, "\\*"

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 2
    array-length v0, p1

    const/4 v1, 0x2

    if-ne v1, v0, :cond_0

    const/4 v0, 0x0

    .line 3
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x1

    .line 4
    aget-object p1, p1, v1

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    const-string v1, " W:"

    const-string v2, " L:"

    const-string v3, " mm"

    .line 5
    invoke-static {v1, p1, v2, v0, v3}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    const-string p1, ""

    :goto_0
    return-object p1
.end method

.method public final E()I
    .locals 3

    const/4 v0, 0x0

    .line 1
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 2
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_0

    .line 3
    instance-of v2, v1, Landroid/widget/CheckBox;

    if-eqz v2, :cond_0

    .line 4
    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_0

    goto :goto_1

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_1
    return v0
.end method

.method public final F()V
    .locals 11

    const-string v0, ","

    const-string v1, "SJM="

    const-string v2, "FSIZE"

    const-string v3, ";"

    .line 1
    sget-boolean v4, Lc/b/a/a/k/d;->j:Z

    if-eqz v4, :cond_0

    const v4, 0x7f1100da

    .line 2
    invoke-static {v4}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v5, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v5, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v5, v5, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 5
    :cond_0
    :try_start_0
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D:Ljava/lang/String;

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_1

    return-void

    .line 6
    :cond_1
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D:Ljava/lang/String;

    invoke-virtual {v4, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    return-void

    .line 7
    :cond_2
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D:Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 8
    array-length v5, v4

    if-nez v5, :cond_3

    return-void

    :cond_3
    const/4 v5, 0x0

    .line 9
    aget-object v4, v4, v5

    .line 10
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_4

    return-void

    .line 11
    :cond_4
    invoke-virtual {v4, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v7, 0x1

    if-eqz v6, :cond_8

    .line 12
    invoke-virtual {v4, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 13
    array-length v4, v1

    if-nez v4, :cond_5

    return-void

    .line 14
    :cond_5
    aget-object v1, v1, v7

    const-string v4, " "

    .line 15
    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 16
    array-length v6, v4

    const/4 v8, 0x2

    if-ne v8, v6, :cond_6

    .line 17
    aget-object v4, v4, v5

    iput-object v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->C:Ljava/lang/String;

    :cond_6
    const/4 v4, 0x0

    .line 18
    iget v6, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v9, ";SJM="

    cmpg-float v4, v4, v6

    if-gez v4, :cond_7

    :try_start_1
    iget v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    const/high16 v6, 0x43200000    # 160.0f

    cmpg-float v4, v4, v6

    if-gez v4, :cond_7

    .line 19
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 20
    array-length v6, v4

    if-ne v6, v8, :cond_9

    .line 21
    aget-object v6, v4, v7

    invoke-virtual {v6, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v6

    .line 22
    array-length v10, v6

    if-ne v10, v8, :cond_9

    .line 23
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v4, v4, v5

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v2, v6, v7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v0, v6, v5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    .line 24
    :cond_7
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_8
    const-string v0, "012345678901238"

    .line 25
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->C:Ljava/lang/String;

    .line 26
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "IN"

    const-string v2, ""

    invoke-virtual {v4, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_9
    :goto_0
    new-array v0, v7, [Ljava/lang/Object;

    .line 27
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u83b7\u53d6\u5207\u5272\u6700\u5c0f\u5c3a\u5bf8 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v5

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 28
    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    .line 29
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_1
    return-void
.end method

.method public final G()V
    .locals 16

    move-object/from16 v0, p0

    .line 1
    invoke-static/range {p0 .. p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v1

    .line 2
    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->K:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v3, 0x0

    if-nez v2, :cond_c

    sget-object v2, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    if-eqz v2, :cond_c

    .line 3
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_c

    .line 4
    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->K:Ljava/lang/String;

    const-string v4, ","

    invoke-virtual {v2, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 5
    array-length v4, v2

    const/4 v5, 0x2

    if-eq v5, v4, :cond_0

    return-void

    .line 6
    :cond_0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    aget-object v7, v2, v6

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "*"

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v7, v2, v3

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    .line 7
    aget-object v7, v2, v6

    invoke-static {v7}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v7

    .line 8
    aget-object v2, v2, v3

    invoke-static {v2}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    const v8, 0x7f060077

    const/4 v9, 0x0

    cmpl-float v7, v9, v7

    if-nez v7, :cond_2

    cmpl-float v2, v9, v2

    if-nez v2, :cond_2

    const/4 v1, 0x0

    .line 9
    :goto_0
    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_e

    .line 10
    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/CheckBox;

    if-eqz v2, :cond_1

    .line 11
    instance-of v4, v2, Landroid/widget/CheckBox;

    if-eqz v4, :cond_1

    .line 12
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4, v8}, Landroid/content/res/Resources;->getColor(I)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 13
    invoke-virtual {v2, v3}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 14
    invoke-virtual {v2, v3}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    .line 15
    :goto_1
    sget-object v7, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    const/high16 v9, 0x41a80000    # 21.0f

    const/high16 v10, 0x40800000    # 4.0f

    const-string v11, "VF"

    const/high16 v12, 0x40000000    # 2.0f

    const-string v13, "\\*"

    if-ge v2, v7, :cond_8

    .line 16
    sget-object v7, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .line 17
    iget-object v14, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v14, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroid/widget/CheckBox;

    .line 18
    invoke-virtual {v7, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    .line 19
    array-length v15, v13

    if-eq v5, v15, :cond_3

    goto :goto_3

    .line 20
    :cond_3
    aget-object v15, v13, v3

    invoke-static {v15}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v15

    .line 21
    aget-object v13, v13, v6

    invoke-static {v13}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v13

    if-eqz v14, :cond_7

    .line 22
    instance-of v5, v14, Landroid/widget/CheckBox;

    if-eqz v5, :cond_7

    .line 23
    iget v5, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    add-float/2addr v5, v12

    .line 24
    iget-object v12, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->u:Ljava/lang/String;

    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_4

    iget-object v12, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->u:Ljava/lang/String;

    invoke-virtual {v12, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_4

    .line 25
    iget v5, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    add-float/2addr v5, v10

    .line 26
    :cond_4
    iget v10, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    cmpg-float v10, v13, v10

    if-gtz v10, :cond_6

    cmpl-float v5, v13, v5

    if-ltz v5, :cond_6

    iget v5, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    add-float/2addr v5, v9

    cmpl-float v5, v15, v5

    if-ltz v5, :cond_6

    .line 27
    invoke-virtual {v14, v1}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 28
    invoke-virtual {v14, v6}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 29
    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_5

    const/4 v5, 0x1

    goto :goto_2

    :cond_5
    const/4 v5, 0x0

    :goto_2
    invoke-virtual {v14, v5}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_3

    .line 30
    :cond_6
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v8}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {v14, v5}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 31
    invoke-virtual {v14, v3}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 32
    invoke-virtual {v14, v3}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_7
    :goto_3
    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    goto/16 :goto_1

    .line 33
    :cond_8
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 34
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "IS_re_material"

    invoke-virtual {v2, v4, v3}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v2

    .line 35
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    .line 36
    iget-object v4, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "lastMaterialSize"

    const-string v7, ""

    invoke-virtual {v4, v5, v7}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v2, :cond_e

    .line 37
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_e

    const/4 v2, 0x0

    .line 38
    :goto_4
    sget-object v5, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v2, v5, :cond_e

    .line 39
    sget-object v5, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 40
    iget-object v7, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/widget/CheckBox;

    .line 41
    invoke-virtual {v5, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v8

    .line 42
    array-length v14, v8

    const/4 v15, 0x2

    if-eq v15, v14, :cond_9

    goto :goto_5

    .line 43
    :cond_9
    aget-object v14, v8, v3

    invoke-static {v14}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v14

    .line 44
    aget-object v8, v8, v6

    invoke-static {v8}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v8

    if-eqz v7, :cond_b

    .line 45
    instance-of v15, v7, Landroid/widget/CheckBox;

    if-eqz v15, :cond_b

    .line 46
    iget v15, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    add-float/2addr v15, v12

    .line 47
    iget-object v12, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->u:Ljava/lang/String;

    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    if-nez v12, :cond_a

    iget-object v12, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->u:Ljava/lang/String;

    invoke-virtual {v12, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_a

    .line 48
    iget v12, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    add-float v15, v12, v10

    .line 49
    :cond_a
    iget v12, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    cmpg-float v12, v8, v12

    if-gtz v12, :cond_b

    cmpl-float v8, v8, v15

    if-ltz v8, :cond_b

    iget v8, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    add-float/2addr v8, v9

    cmpl-float v8, v14, v8

    if-ltz v8, :cond_b

    .line 50
    invoke-virtual {v7, v1}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 51
    invoke-virtual {v7, v6}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 52
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_b

    .line 53
    invoke-virtual {v7, v6}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_b
    :goto_5
    add-int/lit8 v2, v2, 0x1

    const/high16 v12, 0x40000000    # 2.0f

    goto :goto_4

    :cond_c
    const/4 v1, 0x0

    .line 54
    :goto_6
    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-ge v1, v2, :cond_e

    .line 55
    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/widget/CheckBox;

    if-eqz v2, :cond_d

    .line 56
    instance-of v4, v2, Landroid/widget/CheckBox;

    if-eqz v4, :cond_d

    .line 57
    invoke-virtual {v2, v3}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 58
    invoke-virtual {v2, v3}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_d
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    :cond_e
    return-void
.end method

.method public synthetic I(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 1
    check-cast p1, Landroid/widget/CheckBox;

    invoke-virtual {p0, p1, p2}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->O(Landroid/widget/CheckBox;Z)V

    return-void
.end method

.method public synthetic J(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 1
    check-cast p1, Landroid/widget/CheckBox;

    invoke-virtual {p0, p1, p2}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->O(Landroid/widget/CheckBox;Z)V

    return-void
.end method

.method public K(Landroid/view/View;)Z
    .locals 0

    const/4 p1, 0x0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->T(Z)V

    .line 2
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    const/4 p1, 0x1

    return p1
.end method

.method public L(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 2
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 3
    new-instance v1, Lc/b/a/a/l/b/t6;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2, p1}, Lc/b/a/a/l/b/t6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;ZLjava/lang/String;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 4
    invoke-static {p1, v0}, Lc/b/a/a/h/c/e;->m(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void
.end method

.method public final M()V
    .locals 5

    .line 1
    :try_start_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->T:Ljava/lang/String;

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->getFileName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 3
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v3, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "prCustom/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x2f

    .line 4
    invoke-virtual {v0, v3}, Ljava/lang/String;->indexOf(I)I

    move-result v3

    const/4 v4, -0x1

    if-ne v3, v4, :cond_0

    .line 5
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->getFileExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "/"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 6
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, Lc/b/a/a/h/a;->b:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 7
    :cond_0
    invoke-static {v0}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v1

    if-nez v1, :cond_1

    return-void

    .line 8
    :cond_1
    invoke-static {v2}, Lcom/blankj/utilcode/util/FileUtils;->isFileExists(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_2

    goto :goto_0

    :cond_2
    move-object v2, v0

    .line 9
    :goto_0
    new-instance v0, Ljava/io/FileInputStream;

    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-direct {v0, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 10
    invoke-virtual {v0}, Ljava/io/FileInputStream;->available()I

    move-result v1

    if-lez v1, :cond_3

    .line 11
    new-array v1, v1, [B

    .line 12
    invoke-virtual {v0, v1}, Ljava/io/FileInputStream;->read([B)I

    .line 13
    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V

    .line 14
    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    .line 15
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_3
    :goto_1
    return-void
.end method

.method public final N()V
    .locals 4

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    const v0, 0x7f1100da

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 5
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 6
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v1, 0x0

    const-string v2, "ID_abnormal"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    const v0, 0x7f1100cf

    .line 7
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 10
    :cond_1
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    const/4 v1, 0x0

    cmpl-float v2, v0, v1

    if-lez v2, :cond_2

    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    cmpl-float v1, v2, v1

    if-lez v1, :cond_2

    cmpl-float v0, v0, v2

    if-lez v0, :cond_2

    const v0, 0x7f1100e7

    .line 11
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    return-void

    .line 12
    :cond_2
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->k:Z

    if-eqz v0, :cond_3

    .line 13
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->E()I

    move-result v0

    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->B:I

    if-gez v0, :cond_3

    const v0, 0x7f1100d1

    .line 14
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    :cond_3
    const-string v0, ";BD:100,10,5;BD:100,3;"

    .line 15
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 16
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    invoke-virtual {v0}, Landroidx/databinding/ViewDataBinding;->getRoot()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/e7;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/e7;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    const-wide/16 v2, 0x32

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final O(Landroid/widget/CheckBox;Z)V
    .locals 3

    if-eqz p1, :cond_1

    .line 1
    instance-of v0, p1, Landroid/widget/CheckBox;

    if-eqz v0, :cond_1

    if-eqz p2, :cond_1

    const/4 p2, 0x0

    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_0

    .line 4
    instance-of v2, v1, Landroid/widget/CheckBox;

    if-eqz v2, :cond_0

    if-eq v1, p1, :cond_0

    .line 5
    invoke-virtual {v1, p2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final P()V
    .locals 8

    .line 1
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->q:I

    int-to-double v0, v0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    div-double/2addr v0, v2

    double-to-float v0, v0

    .line 2
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const/4 v2, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string v3, "%.1f"

    invoke-static {v1, v3, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 3
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->a:Landroid/widget/Button;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f1101d7

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "("

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\u00b0)"

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 5
    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->q:I

    if-nez v1, :cond_0

    .line 6
    invoke-static {p0}, Lc/b/a/a/m/d;->w0(Landroid/content/Context;)I

    move-result v1

    .line 7
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->a:Landroid/widget/Button;

    invoke-virtual {v2, v1}, Landroid/widget/Button;->setBackgroundColor(I)V

    goto :goto_0

    .line 9
    :cond_0
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->a:Landroid/widget/Button;

    const v2, 0x7f0600e4

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackgroundResource(I)V

    :goto_0
    const/high16 v1, 0x3f800000    # 1.0f

    .line 11
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->r:F

    .line 12
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const/high16 v2, 0x40a00000    # 5.0f

    div-float/2addr v1, v2

    float-to-int v1, v1

    .line 13
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->r:F

    float-to-double v2, v2

    int-to-double v4, v1

    const-wide v6, 0x3fa47ae147ae147bL    # 0.04

    mul-double v4, v4, v6

    sub-double/2addr v2, v4

    double-to-float v1, v2

    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->r:F

    .line 14
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->m:Z

    const/high16 v3, -0x40800000    # -1.0f

    if-eqz v2, :cond_1

    mul-float v1, v1, v3

    .line 15
    :cond_1
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->r:F

    .line 16
    iget-boolean v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->n:Z

    if-eqz v4, :cond_2

    mul-float v1, v2, v3

    mul-float v2, v2, v3

    .line 17
    :cond_2
    iget-object v4, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 18
    check-cast v4, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v4, v4, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->i:Landroid/widget/ImageView;

    invoke-virtual {v4, v1}, Landroid/widget/ImageView;->setScaleX(F)V

    .line 19
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 20
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->i:Landroid/widget/ImageView;

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setScaleY(F)V

    .line 21
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 22
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->i:Landroid/widget/ImageView;

    mul-float v0, v0, v3

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setRotation(F)V

    return-void
.end method

.method public final Q(I)V
    .locals 2

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    return-void

    .line 2
    :cond_0
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->m:Z

    if-nez v0, :cond_1

    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->n:Z

    if-eqz v0, :cond_2

    :cond_1
    mul-int/lit8 p1, p1, -0x1

    .line 3
    :cond_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "BD:8,"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ";"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 4
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e([B)V

    return-void
.end method

.method public final R()V
    .locals 3

    .line 1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->o:Z

    const/16 v1, 0x8

    if-eqz v0, :cond_1

    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    const v2, 0x4323ca3d    # 163.79f

    cmpl-float v0, v2, v0

    if-lez v0, :cond_1

    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    const/high16 v2, 0x429f0000    # 79.5f

    cmpl-float v0, v2, v0

    if-lez v0, :cond_1

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    invoke-static {v0}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 6
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->p:Z

    if-eqz v0, :cond_2

    .line 7
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->q:I

    if-lez v0, :cond_0

    .line 8
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setVisibility(I)V

    goto :goto_0

    .line 10
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {v0, v2}, Landroid/widget/CheckBox;->setVisibility(I)V

    goto :goto_0

    .line 12
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 13
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setVisibility(I)V

    :cond_2
    :goto_0
    return-void
.end method

.method public final S()V
    .locals 17

    move-object/from16 v1, p0

    .line 1
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D:Ljava/lang/String;

    .line 2
    iget-object v2, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {v2}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v2

    if-eqz v2, :cond_0

    .line 4
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->E:Ljava/lang/String;

    .line 5
    :cond_0
    iget-boolean v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->k:Z

    const/4 v4, 0x2

    const-string v5, ","

    const-string v6, ";"

    const-string v7, "BD:33,190,120;"

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v3, :cond_4

    iget v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->B:I

    const/4 v10, -0x1

    if-le v3, v10, :cond_4

    iget-object v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_4

    iget-object v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    const-string v10, "PAGE="

    invoke-virtual {v3, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_4

    .line 6
    iget v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->B:I

    if-ltz v3, :cond_2

    .line 7
    sget-object v7, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 8
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v7

    .line 9
    iget-object v7, v7, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v10, "lastMaterialSize"

    invoke-virtual {v7, v10, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    const-string v7, "\\*"

    .line 10
    invoke-virtual {v3, v7}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    .line 11
    array-length v7, v3

    if-eq v4, v7, :cond_1

    return-void

    .line 12
    :cond_1
    aget-object v7, v3, v8

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    .line 13
    aget-object v3, v3, v9

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const-string v10, "BD:33,"

    .line 14
    invoke-static {v10, v7, v5, v3, v6}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    goto :goto_0

    :cond_2
    if-eqz v2, :cond_3

    .line 15
    iput-object v7, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    .line 16
    :cond_3
    :goto_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    invoke-static {v3, v7, v0}, Ld/a/a/a/a;->v(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    goto :goto_1

    :cond_4
    if-eqz v2, :cond_5

    .line 17
    iput-object v7, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    .line 18
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v7, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    invoke-static {v3, v7, v0}, Ld/a/a/a/a;->v(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 19
    :cond_5
    :goto_1
    iget-boolean v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->m:Z

    if-nez v3, :cond_6

    if-eqz v2, :cond_7

    :cond_6
    const-string v2, "BD:8;"

    .line 20
    invoke-static {v2, v0}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_7
    new-array v2, v8, [Ljava/lang/Object;

    const-string v3, "\u5207\u5272\uff1a"

    .line 21
    invoke-static {v3, v0}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    aput-object v3, v2, v9

    invoke-static {v2}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 22
    iget-boolean v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->n:Z

    if-eqz v2, :cond_8

    .line 23
    new-instance v2, Lc/b/a/a/l/f/a;

    invoke-direct {v2, v1, v0}, Lc/b/a/a/l/f/a;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    new-array v0, v9, [Ljava/lang/String;

    invoke-virtual {v2, v0}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    goto/16 :goto_a

    .line 24
    :cond_8
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_14

    .line 25
    iget-object v2, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 26
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    const v3, 0x7f1101ae

    invoke-virtual {v1, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 27
    sput-boolean v8, Lc/b/a/a/k/d;->j:Z

    .line 28
    iget v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    const/4 v3, 0x0

    cmpg-float v3, v3, v2

    if-gez v3, :cond_12

    const/high16 v3, 0x43200000    # 160.0f

    cmpg-float v2, v2, v3

    if-gez v2, :cond_12

    .line 29
    invoke-virtual {v0, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    .line 30
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    .line 31
    :goto_2
    array-length v7, v0

    const-string v10, " "

    if-ge v3, v7, :cond_11

    .line 32
    aget-object v7, v0, v3

    .line 33
    array-length v11, v0

    sub-int/2addr v11, v8

    if-eq v3, v11, :cond_a

    const-string v10, "FSIZE"

    .line 34
    invoke-virtual {v7, v10}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_9

    .line 35
    invoke-virtual {v7, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    .line 36
    aget-object v11, v7, v8

    invoke-virtual {v11, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v11

    .line 37
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    aget-object v7, v7, v9

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v7, v11, v8

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget-object v7, v11, v9

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .line 38
    :cond_9
    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_7

    :cond_a
    const-string v11, ""

    const-string v12, " @"

    .line 40
    invoke-virtual {v7, v12, v11}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v7

    .line 41
    invoke-virtual {v7, v10}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x0

    .line 42
    :goto_3
    array-length v13, v7

    if-ge v12, v13, :cond_10

    .line 43
    aget-object v13, v7, v12

    .line 44
    invoke-static {v13}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_b

    goto :goto_4

    .line 45
    :cond_b
    invoke-virtual {v13, v9, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v8

    const-string v9, "U"

    .line 46
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    const-string v15, "D"

    if-nez v14, :cond_d

    invoke-virtual {v8, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_c

    goto :goto_5

    .line 47
    :cond_c
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_4
    move-object/from16 v16, v0

    goto :goto_6

    .line 48
    :cond_d
    :goto_5
    invoke-virtual {v13, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v14

    if-eqz v14, :cond_e

    move-object/from16 v16, v0

    .line 49
    array-length v0, v14

    if-ne v4, v0, :cond_f

    .line 50
    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    .line 51
    aget-object v0, v14, v0

    const/4 v8, 0x1

    .line 52
    aget-object v8, v14, v8

    .line 53
    invoke-virtual {v0, v9, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 54
    invoke-virtual {v0, v15, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 55
    invoke-virtual {v8, v9, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 56
    invoke-virtual {v8, v15, v11}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    .line 57
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_6

    :cond_e
    move-object/from16 v16, v0

    .line 58
    :cond_f
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_6
    add-int/lit8 v12, v12, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    move-object/from16 v0, v16

    goto/16 :goto_3

    :cond_10
    :goto_7
    move-object/from16 v16, v0

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    move-object/from16 v0, v16

    goto/16 :goto_2

    :cond_11
    const-string v0, "U0,0"

    .line 59
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 60
    invoke-virtual {v2, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "@ "

    .line 61
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 62
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 63
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    .line 64
    invoke-virtual {v1, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d([B)V

    goto :goto_8

    .line 65
    :cond_12
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    .line 66
    invoke-virtual {v1, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d([B)V

    .line 67
    :goto_8
    iget-boolean v0, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->N:Z

    if-eqz v0, :cond_14

    .line 68
    iget-object v0, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 69
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    .line 70
    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->s:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    .line 71
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    .line 72
    iget-wide v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    const-wide/16 v4, 0x1

    sub-long/2addr v2, v4

    iput-wide v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    .line 73
    iget-wide v6, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->x:J

    add-long/2addr v6, v4

    iput-wide v6, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->x:J

    .line 74
    const-wide v2, 0x1869f
    invoke-virtual {v0, v2, v3}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setBalaqty(J)V

    .line 75
    iget-wide v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->x:J

    invoke-virtual {v0, v2, v3}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setUseqty(J)V

    .line 76
    iget-wide v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    .line 77
    iget-wide v4, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->x:J

    .line 78
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v0

    if-eqz v0, :cond_13

    .line 79
    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v6

    if-lez v6, :cond_13

    .line 80
    iget-wide v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v4

    int-to-long v4, v4

    add-long/2addr v2, v4

    .line 81
    iget-wide v4, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->x:J

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    int-to-long v6, v0

    sub-long/2addr v4, v6

    .line 82
    :cond_13
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 83
    invoke-static {v4, v5}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 84
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "USEQTY"

    invoke-virtual {v0, v5, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 85
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 86
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 87
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "BALAQTY"

    invoke-virtual {v0, v3, v2}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 88
    iget v0, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->A:I

    add-int/lit8 v0, v0, 0x1

    iput v0, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->A:I

    .line 89
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    iget v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->A:I

    .line 90
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "N_cutNumber2"

    invoke-virtual {v0, v3, v2}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    const-string v10, "Y"

    .line 91
    new-instance v12, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v12}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 92
    iget v0, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->v:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v9

    .line 93
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v0, "remark"

    .line 94
    iget-object v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->G:Ljava/lang/String;

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "uuid"

    .line 95
    iget-object v3, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->H:Ljava/lang/String;

    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "feedBack"

    .line 96
    invoke-virtual {v2, v0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "materialId"

    const-string v3, "0"

    .line 97
    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "productId"

    const-string v3, "-10"

    .line 98
    invoke-virtual {v2, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_9

    :catch_0
    move-exception v0

    .line 99
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    .line 100
    :goto_9
    new-instance v13, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    invoke-direct {v13}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;-><init>()V

    const/4 v0, 0x0

    .line 101
    invoke-virtual {v13, v0}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;->setIsUpdate(Z)V

    .line 102
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v13, v0}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;->setJson(Ljava/lang/String;)V

    .line 103
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "custom:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->G:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    iget-object v8, v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->H:Ljava/lang/String;

    const-string v4, "on"

    const-string v5, "-10"

    const-string v6, ""

    const-string v11, "0"

    invoke-static/range {v4 .. v13}, Lc/b/a/a/h/c/e;->g(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)V

    :cond_14
    :goto_a
    return-void
.end method

.method public final T(Z)V
    .locals 3

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "N_cutNumber2"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 3
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->A:I

    .line 4
    iget-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->y:Z

    if-eqz v1, :cond_2

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->z:I

    if-lt v0, v1, :cond_2

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 6
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 7
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 8
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity$a;

    invoke-direct {v1, p0, p1}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity$a;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;Z)V

    .line 9
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 10
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    const v0, 0x7f110054

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 11
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->e:Ljava/lang/String;

    .line 12
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->A:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v1, 0x7f11007c

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 13
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 14
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "customdialog"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    goto :goto_2

    :cond_2
    if-eqz p1, :cond_3

    .line 15
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->N()V

    goto :goto_2

    .line 16
    :cond_3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->U()V

    :goto_2
    return-void
.end method

.method public final U()V
    .locals 12

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "cutNet"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 3
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v0

    if-nez v0, :cond_0

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    const v1, 0x7f1100ab

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 6
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 7
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "offCutMax"

    invoke-virtual {v0, v3, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    const v3, 0x7f1100ce

    if-lez v0, :cond_1

    .line 8
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_1

    .line 9
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-lt v4, v0, :cond_1

    .line 10
    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 13
    :cond_1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 14
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "ID_abnormal"

    invoke-virtual {v0, v4, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_2

    const v0, 0x7f1100cf

    .line 15
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 16
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 18
    :cond_2
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    const/4 v4, 0x0

    cmpl-float v5, v0, v4

    if-lez v5, :cond_3

    iget v5, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    cmpl-float v4, v5, v4

    if-lez v4, :cond_3

    cmpl-float v0, v0, v5

    if-lez v0, :cond_3

    const v0, 0x7f1100e7

    .line 19
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    return-void

    .line 20
    :cond_3
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->k:Z

    if-eqz v0, :cond_4

    .line 21
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->E()I

    move-result v0

    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->B:I

    .line 22
    :cond_4
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->v:I

    if-ne v0, v1, :cond_5

    new-array v0, v1, [Ljava/lang/Object;

    const-string v3, "\u5269\u4f59\u5207\u5272\u6570\uff1a"

    .line 23
    invoke-static {v3}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v4, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    aput-object v3, v0, v2

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 24
    iget-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    const-wide/16 v4, 0x1

    cmp-long v0, v2, v4

    if-gez v0, :cond_7

    const v0, 0x7f1100cd

    .line 25
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 26
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 27
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 28
    :cond_5
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-wide/16 v4, 0x0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 29
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    const-string v2, "netCurrentTime"

    invoke-virtual {v0, v2, v6, v7}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v6

    .line 30
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 31
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    const-string v2, "cutCurrentTime"

    invoke-virtual {v0, v2, v8, v9}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v8

    .line 32
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 33
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const-string v2, "cutEndTime"

    invoke-virtual {v0, v2, v4, v5}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v4

    sub-long v6, v8, v6

    const-wide/32 v10, 0x5265c00

    cmp-long v0, v6, v10

    if-lez v0, :cond_6

    .line 34
    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 35
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 36
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_6
    cmp-long v0, v4, v8

    if-gez v0, :cond_7

    const v0, 0x7f1100d0

    .line 37
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 38
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 39
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 40
    :cond_7
    invoke-virtual {p0, v1}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->V(Z)V

    return-void
.end method

.method public final V(Z)V
    .locals 1

    .line 1
    iput-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->N:Z

    .line 2
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    const v0, 0x7f1100d9

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 p1, 0x0

    .line 4
    sput-boolean p1, Lc/b/a/a/k/d;->j:Z

    .line 5
    invoke-static {}, Lc/b/a/a/k/a;->t()[B

    move-result-object p1

    .line 6
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    return-void
.end method

.method public final W()V
    .locals 5

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->J:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_0

    .line 2
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->i:Landroid/widget/ImageView;

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    goto :goto_0

    .line 4
    :cond_0
    new-instance v0, Lc/b/a/a/l/f/d;

    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->c:Landroid/content/Context;

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D:Ljava/lang/String;

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2, v3, v4}, Lc/b/a/a/l/f/d;-><init>(Landroid/content/Context;Ljava/lang/String;FZ)V

    const-string v1, ""

    .line 5
    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 6
    :goto_0
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity$b;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity$b;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    const-wide/16 v2, 0x12c

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public g()I
    .locals 1

    const v0, 0x7f0c0092

    return v0
.end method

.method public l()V
    .locals 7

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v1, Lcn/upus/app/upprinting/MApp;->F:Ljava/text/SimpleDateFormat;

    invoke-static {v1}, Lcom/blankj/utilcode/util/TimeUtils;->getNowString(Ljava/text/DateFormat;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "AppVersion:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2
    invoke-static {}, Lcom/blankj/utilcode/util/AppUtils;->getAppVersionName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "BinVersion:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 4
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, ""

    const-string v3, "SVER"

    invoke-virtual {v1, v3, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->G:Ljava/lang/String;

    .line 6
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "-"

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->H:Ljava/lang/String;

    .line 7
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 8
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "cutType"

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 9
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->v:I

    .line 10
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 11
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "SW_cutNumber"

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 12
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->y:Z

    .line 13
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const/16 v1, 0x64

    .line 14
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "N_standard"

    invoke-virtual {v0, v4, v1}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 15
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->z:I

    .line 16
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 17
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "IS_material"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 18
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->k:Z

    .line 19
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 20
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "IS_Mirroring"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 21
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->l:Z

    .line 22
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 23
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "IS_angle"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 24
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->p:Z

    .line 25
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 26
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "START_ET_LOCK"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 27
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->s:Z

    .line 28
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 29
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "IS_UVFlim"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 30
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->o:Z

    .line 31
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 32
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "MaxWidth"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    int-to-float v0, v0

    .line 33
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->t:F

    .line 34
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 35
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "HVER"

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 36
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->u:Ljava/lang/String;

    .line 37
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 38
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "cutCountShow"

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "0"

    .line 39
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 40
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 41
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->b(Ljava/lang/Boolean;)V

    goto :goto_0

    .line 42
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 43
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->b(Ljava/lang/Boolean;)V

    .line 44
    :goto_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "cutDataFilePath"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->T:Ljava/lang/String;

    .line 45
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "fileName"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->U:Ljava/lang/String;

    .line 46
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 47
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->d:Landroid/widget/ImageButton;

    new-instance v1, Lc/b/a/a/l/b/u2;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/u2;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 48
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 49
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/w6;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/w6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 50
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 51
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/x6;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/x6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 52
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 53
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/y6;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/y6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 54
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 55
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->e:Landroid/widget/CheckBox;

    new-instance v1, Lc/b/a/a/l/b/z6;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/z6;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 56
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 57
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->f:Landroid/widget/CheckBox;

    new-instance v1, Lc/b/a/a/l/b/a7;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/a7;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 58
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 59
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    new-instance v1, Lc/b/a/a/l/b/b7;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/b7;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 60
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 61
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->a:Landroid/widget/Button;

    new-instance v1, Lc/b/a/a/l/b/c7;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/c7;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 62
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 63
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->h:Landroid/widget/ImageButton;

    new-instance v1, Lc/b/a/a/l/b/d7;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/d7;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 64
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 65
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->U:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->setTitle(Ljava/lang/String;)V

    .line 66
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->k:Z

    const/4 v1, 0x2

    if-eqz v0, :cond_5

    .line 67
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_4

    const/4 v0, 0x0

    .line 68
    :goto_1
    sget-object v2, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-ge v0, v2, :cond_4

    .line 69
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {v2, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 70
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 71
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 72
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, -0x1

    const/4 v6, -0x2

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 73
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v5

    if-nez v5, :cond_1

    .line 74
    invoke-virtual {v4, v3, v3, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_2

    :cond_1
    const/16 v5, 0xc

    .line 75
    invoke-virtual {v4, v3, v5, v3, v3}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 76
    :goto_2
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 77
    sget-object v4, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v4, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 78
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 79
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->C(Ljava/lang/String;)Landroid/widget/CheckBox;

    move-result-object v4

    .line 80
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 81
    new-instance v5, Lc/b/a/a/l/b/v2;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/v2;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v4, v5}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 82
    iget-object v5, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v0, 0x1

    .line 83
    sget-object v5, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_2

    .line 84
    sget-object v5, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 85
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->D(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 86
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->C(Ljava/lang/String;)Landroid/widget/CheckBox;

    move-result-object v4

    .line 87
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 88
    iget-object v5, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P:Ljava/util/ArrayList;

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 89
    new-instance v5, Lc/b/a/a/l/b/q2;

    invoke-direct {v5, p0}, Lc/b/a/a/l/b/q2;-><init>(Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;)V

    invoke-virtual {v4, v5}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    goto :goto_4

    .line 90
    :cond_2
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 91
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v5

    const/4 v6, 0x5

    if-nez v5, :cond_3

    .line 92
    invoke-virtual {v4, v6, v1, v6, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_3

    .line 93
    :cond_3
    invoke-virtual {v4, v6, v6, v6, v6}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    :goto_3
    const/high16 v5, 0x3f800000    # 1.0f

    .line 94
    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 95
    new-instance v5, Landroid/widget/Space;

    invoke-direct {v5, p0}, Landroid/widget/Space;-><init>(Landroid/content/Context;)V

    .line 96
    invoke-virtual {v5, v4}, Landroid/widget/Space;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 97
    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 98
    :goto_4
    iget-object v4, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 99
    check-cast v4, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v4, v4, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x2

    goto/16 :goto_1

    .line 100
    :cond_4
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->G()V

    .line 101
    :cond_5
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->l:Z

    if-eqz v0, :cond_6

    .line 102
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 103
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->e:Landroid/widget/CheckBox;

    invoke-virtual {v0, v3}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 104
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 105
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->f:Landroid/widget/CheckBox;

    invoke-virtual {v0, v3}, Landroid/widget/CheckBox;->setVisibility(I)V

    .line 106
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 107
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->e:Landroid/widget/CheckBox;

    invoke-static {v0}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 108
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 109
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->f:Landroid/widget/CheckBox;

    invoke-static {v0}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 110
    :cond_6
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->p:Z

    if-eqz v0, :cond_7

    .line 111
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 112
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->a:Landroid/widget/Button;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 113
    :cond_7
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->s:Z

    const/16 v2, 0x8

    if-eqz v0, :cond_8

    .line 114
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 115
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v0, v3}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 116
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 117
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_5

    .line 118
    :cond_8
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 119
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 120
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 121
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 122
    :goto_5
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->v:I

    if-ne v0, v1, :cond_9

    .line 123
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 124
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 125
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 126
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 127
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 128
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->d:Landroid/widget/ImageButton;

    invoke-virtual {v0, v2}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 129
    :cond_9
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M()V

    .line 130
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->W()V

    .line 131
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F()V

    return-void
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 3
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/FragmentActivity;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p3, :cond_1

    const-string v2, "savePath"

    .line 2
    invoke-virtual {p3, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    if-ne p2, v1, :cond_1

    .line 3
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    if-nez p3, :cond_1

    .line 4
    iget-object p3, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast p3, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object p3, p3, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {p3}, Landroid/widget/CheckBox;->isChecked()Z

    move-result p3

    if-eqz p3, :cond_0

    .line 6
    iget-object p3, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast p3, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object p3, p3, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->g:Landroid/widget/CheckBox;

    invoke-virtual {p3, v0}, Landroid/widget/CheckBox;->setChecked(Z)V

    const/4 p3, 0x0

    .line 8
    iput-object p3, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->I:Landroid/graphics/Bitmap;

    const-string p3, ""

    .line 9
    iput-object p3, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->E:Ljava/lang/String;

    .line 10
    :cond_0
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->W()V

    .line 11
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M()V

    .line 12
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F()V

    :cond_1
    const/4 p3, 0x2

    if-ne p1, p3, :cond_2

    if-ne p2, v1, :cond_2

    new-array p1, v1, [Ljava/lang/Object;

    const-string p2, "---------- \u5207\u819c\u5df2\u7ecf\u53d6\u6d88\uff01----------"

    aput-object p2, p1, v0

    .line 13
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto :goto_0

    :cond_2
    if-ne p1, p3, :cond_3

    if-ne p2, p3, :cond_3

    .line 14
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->S()V

    :cond_3
    :goto_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    const-string v0, "page_onCreate"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onCreate"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    .line 3
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 5
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->S:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->S:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CutMoveDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    :cond_2
    const/4 v0, 0x0

    .line 7
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->Q(I)V

    .line 8
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onDestroy()V

    return-void
.end method

.method public onEvent(Lcn/upus/app/upprinting/data/bean/event/MessageEvent;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onEvent(Lcn/upus/app/upprinting/data/bean/event/MessageEvent;)V

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object v0

    const-string v1, "cut_finish"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    const v1, 0x7f1101d8

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 5
    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 6
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 7
    :cond_0
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object p1

    const-string v0, "recharge_finish"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 8
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getBalaqty()J

    move-result-wide v0

    iput-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    .line 9
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getUseqty()J

    move-result-wide v0

    iput-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->x:J

    :cond_1
    return-void
.end method

.method public onPause()V
    .locals 2

    const-string v0, "onPause"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onPause()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onRestart()V
    .locals 2

    const-string v0, "page_onReStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onRestart()V

    return-void
.end method

.method public onResume()V
    .locals 4

    const-string v0, "onResume"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 1
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onResume()V

    .line 2
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getBalaqty()J

    move-result-wide v2

    iput-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->w:J

    .line 3
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getUseqty()J

    move-result-wide v2

    iput-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->x:J

    const-string v2, "page_onResume"

    const/4 v3, 0x0

    .line 4
    invoke-static {p0, v2, v3}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onSerialPortEvent(Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;)V
    .locals 14
    .annotation runtime Li/b/a/k;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;->getData()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "\u63a5\u6536\u5230\u7684\u4ea7\u54c1\u5207\u5272\u4e32\u53e3\u6570\u636e\uff1a"

    .line 2
    invoke-static {v2, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v1, "FSIZE="

    .line 3
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    const-string v4, ","

    const-string v5, ";"

    const/4 v6, 0x2

    if-eqz v2, :cond_b

    .line 4
    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->F:Ljava/lang/String;

    .line 5
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const-string v7, ""

    if-eqz v2, :cond_8

    .line 6
    invoke-virtual {p1, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 7
    array-length v8, v2

    if-ge v8, v6, :cond_0

    return-void

    .line 8
    :cond_0
    aget-object v2, v2, v3

    .line 9
    invoke-virtual {v2, v1, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 10
    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    .line 11
    array-length v2, v1

    const-string v4, " mm"

    const-string v8, " L:"

    const-string v9, "W:"

    const/high16 v10, 0x42200000    # 40.0f

    if-ne v2, v6, :cond_3

    .line 12
    aget-object v2, v1, v3

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v10

    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    .line 13
    aget-object v1, v1, v0

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v1, v10

    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    .line 14
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    float-to-int v6, v2

    float-to-int v1, v1

    int-to-float v10, v6

    cmpg-float v2, v10, v2

    if-gez v2, :cond_1

    add-int/lit8 v6, v6, 0x1

    :cond_1
    int-to-float v2, v1

    .line 15
    iget v10, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    cmpg-float v2, v2, v10

    if-gez v2, :cond_2

    add-int/lit8 v1, v1, 0x1

    .line 16
    :cond_2
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->n:Landroid/widget/TextView;

    invoke-static {v9, v6, v8, v1, v4}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 18
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R()V

    goto/16 :goto_0

    .line 19
    :cond_3
    array-length v2, v1

    const/4 v11, 0x4

    if-ne v2, v11, :cond_8

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->C:Ljava/lang/String;

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_8

    const/4 v2, 0x3

    .line 20
    aget-object v2, v1, v2

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->q:I

    .line 21
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->m:Z

    if-nez v2, :cond_4

    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->n:Z

    if-eqz v2, :cond_5

    .line 22
    :cond_4
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->q:I

    mul-int/lit8 v2, v2, -0x1

    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->q:I

    .line 23
    :cond_5
    aget-object v2, v1, v6

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    rem-int/lit8 v2, v2, 0xb

    .line 24
    iget-object v6, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->C:Ljava/lang/String;

    add-int/lit8 v12, v2, 0x2

    invoke-virtual {v6, v2, v12}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v6

    .line 25
    iget-object v13, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->C:Ljava/lang/String;

    add-int/2addr v2, v11

    invoke-virtual {v13, v12, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const/16 v11, 0x10

    .line 26
    invoke-static {v6, v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v6

    .line 27
    invoke-static {v2, v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v2

    .line 28
    aget-object v11, v1, v3

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    add-int/2addr v11, v6

    int-to-float v6, v11

    div-float/2addr v6, v10

    iput v6, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    .line 29
    aget-object v1, v1, v0

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    add-int/2addr v1, v2

    int-to-float v1, v1

    div-float/2addr v1, v10

    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    .line 30
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->L:F

    float-to-int v6, v2

    float-to-int v1, v1

    int-to-float v10, v6

    cmpg-float v2, v10, v2

    if-gez v2, :cond_6

    add-int/lit8 v6, v6, 0x1

    :cond_6
    int-to-float v2, v1

    .line 31
    iget v10, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->M:F

    cmpg-float v2, v2, v10

    if-gez v2, :cond_7

    add-int/lit8 v1, v1, 0x1

    .line 32
    :cond_7
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 33
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->n:Landroid/widget/TextView;

    invoke-static {v9, v6, v8, v1, v4}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 34
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->R()V

    .line 35
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->P()V

    :cond_8
    :goto_0
    const-string v1, "PAGE="

    .line 36
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_11

    .line 37
    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 38
    array-length v1, p1

    const/4 v2, 0x2

    if-ge v1, v2, :cond_9

    return-void

    .line 39
    :cond_9
    aget-object p1, p1, v0

    .line 40
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_a

    .line 41
    invoke-virtual {p1, v5, v7}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 42
    :cond_a
    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->K:Ljava/lang/String;

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u9ed8\u8ba4\u5207\u5272\u5c3a\u5bf8\uff1a"

    .line 43
    invoke-static {v0}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->K:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    aput-object v0, p1, v3

    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 44
    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->k:Z

    if-eqz p1, :cond_11

    .line 45
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->G()V

    goto/16 :goto_2

    :cond_b
    const-string v1, "RCMD=10,"

    .line 46
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_10

    const-string v1, "RCMD=10,1;"

    .line 47
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_c

    .line 48
    sput-boolean v0, Lc/b/a/a/k/d;->j:Z

    .line 49
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 50
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    const v1, 0x7f1100da

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u5f53\u524d\u8bbe\u5907\u5de5\u4f5c\u72b6\u6001\uff1a\u8bbe\u5907\u5de5\u4f5c/\u91cd\u7f6e"

    aput-object v0, p1, v3

    .line 51
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto/16 :goto_2

    :cond_c
    const-string v1, "RCMD=10,0;"

    .line 52
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 53
    invoke-virtual {p1, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 54
    array-length v1, p1

    const-string v2, "\u83b7\u53d6\u673a\u5668\u72b6\u6001\uff1a\u6570\u636e\u9519\u8bef"

    const v5, 0x7f1100d4

    const-string v6, " "

    const v7, 0x7f1100d9

    const/4 v8, 0x2

    if-eq v1, v8, :cond_d

    .line 55
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 56
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v7}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    aput-object v2, p1, v3

    .line 57
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    return-void

    .line 58
    :cond_d
    aget-object p1, p1, v0

    invoke-virtual {p1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 59
    array-length v1, p1

    const/4 v4, 0x2

    if-lt v1, v4, :cond_f

    aget-object v1, p1, v0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_e

    goto :goto_1

    .line 60
    :cond_e
    aget-object p1, p1, v0

    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/cut/cutjni/JniUtils;->getHandshake(J)[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u4e00\u6b21\u53d1\u5b8c\u63e1\u624b\u6570\u636e"

    aput-object v0, p1, v3

    .line 61
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto :goto_2

    .line 62
    :cond_f
    :goto_1
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 63
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityPltFileCutBinding;->m:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v7}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    aput-object v2, p1, v3

    .line 64
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    return-void

    :cond_10
    const-string v1, "RCMD=12,"

    .line 65
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_11

    const-string v1, "RCMD=12,0;"

    .line 66
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_11

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u63e1\u624b\u6210\u529f\uff0c\u5f00\u59cb\u5207\u5272"

    aput-object v0, p1, v3

    .line 67
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 68
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/PltFileCutActivity;->S()V

    :cond_11
    :goto_2
    return-void
.end method

.method public onStart()V
    .locals 2

    const-string v0, "page_onStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onStart"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStart()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onStop()V
    .locals 2

    const-string v0, "page_onStop"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStop()V

    return-void
.end method
