.class public Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;
.super Lcn/upus/app/upprinting/base/BaseDataBindingActivity;
.source "CustomCutActivity.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcn/upus/app/upprinting/base/BaseDataBindingActivity<",
        "Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;",
        ">;"
    }
.end annotation


# instance fields
.field public A:I

.field public B:Z

.field public C:Z

.field public D:Ljava/lang/String;

.field public E:Ljava/lang/String;

.field public F:Ljava/lang/String;

.field public G:Lc/b/a/a/l/d/g1;

.field public H:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/InputDialog;",
            ">;"
        }
    .end annotation
.end field

.field public I:Landroid/widget/ArrayAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/widget/ArrayAdapter<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public J:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/widget/CheckBox;",
            ">;"
        }
    .end annotation
.end field

.field public K:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public L:Lcn/upus/app/upprinting/data/bean/CutSettings;

.field public M:Ljava/lang/String;

.field public N:Ljava/lang/String;

.field public O:Landroid/graphics/Bitmap;

.field public P:Landroid/graphics/Canvas;

.field public k:Z

.field public l:F

.field public m:I

.field public n:J

.field public o:J

.field public p:Z

.field public q:I

.field public r:I

.field public s:I

.field public t:F

.field public u:F

.field public v:F

.field public w:Z

.field public x:F

.field public y:F

.field public z:F


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;-><init>()V

    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->k:Z

    const/4 v1, 0x0

    .line 3
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->l:F

    const/4 v2, -0x1

    .line 4
    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->s:I

    .line 5
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->v:F

    .line 6
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->w:Z

    .line 7
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    .line 8
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    .line 9
    iput v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    .line 10
    iput v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    .line 11
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->B:Z

    const-string v0, ""

    .line 12
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D:Ljava/lang/String;

    .line 13
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->E:Ljava/lang/String;

    .line 14
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->F:Ljava/lang/String;

    .line 15
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    .line 16
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    return-void
.end method

.method public static K(Landroid/content/Context;)V
    .locals 1

    .line 1
    const-class v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;

    invoke-static {p0, v0}, Ld/a/a/a/a;->H(Landroid/content/Context;Ljava/lang/Class;)V

    return-void
.end method

.method public static L(Landroid/content/Context;Lcn/upus/app/upprinting/data/bean/CutSettings;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 1
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string v1, "cutSettings"

    .line 2
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    const-string p1, "cameraCutout"

    .line 3
    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string p1, "bladePosition"

    .line 4
    invoke-virtual {v0, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 5
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public static p(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static q(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V
    .locals 1

    const/4 v0, 0x0

    .line 1
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    .line 2
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    .line 3
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    const/4 v0, -0x1

    .line 4
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    return-void
.end method

.method public static r(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static synthetic s(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;Z)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->e0(Z)V

    return-void
.end method

.method public static synthetic t(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->Y()V

    return-void
.end method

.method public static synthetic u(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->f0()V

    return-void
.end method

.method public static v(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;Ljava/lang/String;Z)V
    .locals 2

    if-eqz p0, :cond_0

    .line 1
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    new-instance v1, Lc/b/a/a/l/b/p;

    invoke-direct {v1, p0, p2, p1}, Lc/b/a/a/l/b/p;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;ZLjava/lang/String;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 3
    invoke-static {p1, v0}, Lc/b/a/a/h/c/e;->m(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void

    :cond_0
    const/4 p0, 0x0

    .line 4
    throw p0
.end method

.method public static synthetic w(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)Ljava/lang/ref/WeakReference;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    return-object p0
.end method

.method public static x(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static y(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method

.method public static z(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)Landroidx/databinding/ViewDataBinding;
    .locals 0

    .line 1
    iget-object p0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    return-object p0
.end method


# virtual methods
.method public final A(F)Ljava/util/List;
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(F)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move-object/from16 v6, p0

    .line 1
    new-instance v7, Ljava/util/ArrayList;

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 2
    iget-object v0, v6, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->g:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v0}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v0

    .line 4
    iget-object v1, v6, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->f:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v1}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v1

    .line 6
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v8

    .line 7
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v9

    const/high16 v0, 0x3fc00000    # 1.5f

    mul-float v10, p1, v0

    .line 8
    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    mul-float v11, v1, p1

    .line 9
    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    if-ltz v1, :cond_3

    const/4 v2, 0x4

    if-ge v1, v2, :cond_3

    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/4 v3, 0x0

    cmpl-float v4, v2, v3

    if-lez v4, :cond_3

    iget v4, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v3, v4, v3

    if-lez v3, :cond_3

    const/4 v3, 0x0

    const/high16 v12, 0x40000000    # 2.0f

    const-string v13, ","

    if-nez v1, :cond_0

    sub-float v1, v9, v2

    div-float/2addr v1, v12

    sub-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v0, v1

    sub-float v1, v9, v2

    div-float/2addr v1, v12

    mul-float v1, v1, p1

    float-to-int v8, v1

    float-to-int v14, v10

    .line 10
    invoke-static {v3, v13, v0, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v15, v14

    int-to-float v3, v0

    const/4 v4, 0x4

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move v2, v15

    .line 11
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v14, v13, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 12
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v0, v9, v0

    div-float/2addr v0, v12

    mul-float v0, v0, p1

    float-to-int v0, v0

    .line 13
    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v2, v1, v2

    mul-float v2, v2, p1

    float-to-int v2, v2

    int-to-float v3, v0

    add-float/2addr v3, v11

    float-to-int v8, v3

    mul-float v1, v1, p1

    float-to-int v5, v1

    .line 14
    invoke-static {v2, v13, v0, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v2

    int-to-float v3, v8

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move v1, v11

    move v12, v5

    move/from16 v5, v16

    .line 15
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v12, v13, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 16
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/high16 v1, 0x40000000    # 2.0f

    invoke-static {v9, v0, v1, v0}, Ld/a/a/a/a;->b(FFFF)F

    move-result v2

    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float/2addr v2, v3

    mul-float v2, v2, p1

    float-to-int v2, v2

    .line 17
    iget v4, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    mul-float v5, v4, p1

    float-to-int v5, v5

    sub-float v8, v9, v0

    div-float/2addr v8, v1

    add-float/2addr v8, v0

    mul-float v8, v8, p1

    float-to-int v8, v8

    sub-float/2addr v4, v3

    mul-float v4, v4, p1

    float-to-int v12, v4

    .line 18
    invoke-static {v5, v13, v2, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v12

    int-to-float v4, v2

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move v1, v11

    move v2, v3

    move v3, v4

    move v4, v5

    move/from16 v5, v16

    .line 19
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v12, v13, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 20
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v9, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    add-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    sub-float/2addr v9, v0

    div-float/2addr v9, v2

    add-float/2addr v9, v0

    const/high16 v0, 0x3fc00000    # 1.5f

    add-float/2addr v9, v0

    mul-float v9, v9, p1

    float-to-int v8, v9

    .line 21
    invoke-static {v14, v13, v1, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v8

    const/4 v4, 0x3

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move v2, v15

    .line 22
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v7, v0, v1, v13, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    goto/16 :goto_0

    :cond_0
    const/4 v0, 0x1

    if-ne v0, v1, :cond_1

    sub-float v0, v9, v2

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    add-float/2addr v0, v2

    const/high16 v3, 0x3fc00000    # 1.5f

    add-float/2addr v0, v3

    mul-float v0, v0, p1

    float-to-int v0, v0

    mul-float v4, v8, p1

    float-to-int v12, v4

    sub-float v4, v9, v2

    div-float/2addr v4, v1

    add-float/2addr v4, v2

    mul-float v4, v4, p1

    float-to-int v14, v4

    sub-float v1, v8, v3

    mul-float v1, v1, p1

    float-to-int v15, v1

    .line 23
    invoke-static {v12, v13, v0, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v5, v15

    int-to-float v3, v0

    const/4 v4, 0x2

    const/16 v16, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move v2, v5

    move/from16 v17, v5

    move/from16 v5, v16

    .line 24
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v15, v13, v14}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 25
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v9, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    add-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    .line 26
    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v4, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v5, v3, v4

    sub-float v5, v8, v5

    mul-float v5, v5, p1

    float-to-int v5, v5

    sub-float v14, v9, v0

    div-float/2addr v14, v2

    add-float/2addr v14, v0

    sub-float/2addr v14, v4

    mul-float v14, v14, p1

    float-to-int v14, v14

    sub-float v0, v8, v3

    mul-float v0, v0, p1

    float-to-int v4, v0

    .line 27
    invoke-static {v5, v13, v1, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v5

    int-to-float v3, v14

    const/4 v5, 0x2

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move v1, v11

    move/from16 v18, v12

    move v12, v4

    move v4, v5

    move/from16 v5, v16

    .line 28
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v12, v13, v14}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 29
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v9, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    add-float/2addr v1, v3

    mul-float v1, v1, p1

    float-to-int v1, v1

    .line 30
    iget v4, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    sub-float v5, v8, v4

    mul-float v5, v5, p1

    float-to-int v5, v5

    sub-float v0, v9, v0

    div-float/2addr v0, v2

    mul-float v0, v0, p1

    float-to-int v12, v0

    sub-float/2addr v4, v3

    sub-float/2addr v8, v4

    mul-float v8, v8, p1

    float-to-int v8, v8

    .line 31
    invoke-static {v5, v13, v1, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v8

    int-to-float v3, v1

    const/4 v4, 0x3

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move v1, v11

    .line 32
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v8, v13, v12}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 33
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v9, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    mul-float v1, v1, p1

    float-to-int v1, v1

    sub-float/2addr v9, v0

    div-float/2addr v9, v2

    const/high16 v0, 0x3fc00000    # 1.5f

    sub-float/2addr v9, v0

    mul-float v9, v9, p1

    float-to-int v8, v9

    .line 34
    invoke-static {v15, v13, v1, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v8

    const/4 v4, 0x1

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move/from16 v2, v17

    .line 35
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    move/from16 v1, v18

    invoke-static {v7, v0, v1, v13, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    goto/16 :goto_0

    :cond_1
    const/4 v0, 0x2

    if-ne v0, v1, :cond_2

    sub-float v0, v8, v2

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    add-float/2addr v0, v2

    const/high16 v3, 0x3fc00000    # 1.5f

    add-float/2addr v0, v3

    mul-float v0, v0, p1

    float-to-int v0, v0

    float-to-int v9, v10

    sub-float v3, v8, v2

    div-float/2addr v3, v1

    add-float/2addr v3, v2

    mul-float v3, v3, p1

    float-to-int v12, v3

    const/4 v1, 0x0

    .line 36
    invoke-static {v0, v13, v1, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v0

    int-to-float v14, v9

    const/4 v4, 0x3

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move v3, v14

    .line 37
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v12, v13, v9}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 38
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v2, v0, v1

    mul-float v2, v2, p1

    float-to-int v2, v2

    .line 39
    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v4, v8, v3

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    add-float/2addr v4, v3

    mul-float v4, v4, p1

    float-to-int v4, v4

    mul-float v0, v0, p1

    float-to-int v12, v0

    sub-float v0, v8, v3

    div-float/2addr v0, v5

    add-float/2addr v0, v3

    sub-float/2addr v0, v1

    mul-float v0, v0, p1

    float-to-int v15, v0

    .line 40
    invoke-static {v4, v13, v2, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v15

    int-to-float v4, v2

    const/4 v5, 0x1

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move v1, v11

    move v2, v3

    move v3, v4

    move v4, v5

    move/from16 v5, v16

    .line 41
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v15, v13, v12}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 42
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    mul-float v1, v0, p1

    float-to-int v1, v1

    .line 43
    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v3, v8, v2

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v3, v4

    iget v5, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    add-float/2addr v3, v5

    mul-float v3, v3, p1

    float-to-int v3, v3

    sub-float/2addr v0, v5

    mul-float v0, v0, p1

    float-to-int v12, v0

    sub-float v0, v8, v2

    div-float/2addr v0, v4

    mul-float v0, v0, p1

    float-to-int v15, v0

    .line 44
    invoke-static {v3, v13, v1, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v3

    int-to-float v3, v12

    const/16 v16, 0x2

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move v1, v11

    move/from16 v4, v16

    .line 45
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v15, v13, v12}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 46
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v8, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    mul-float v1, v1, p1

    float-to-int v1, v1

    sub-float/2addr v8, v0

    div-float/2addr v8, v2

    const/high16 v0, 0x3fc00000    # 1.5f

    sub-float/2addr v8, v0

    mul-float v8, v8, p1

    float-to-int v8, v8

    .line 47
    invoke-static {v1, v13, v9, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v8

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move v3, v14

    .line 48
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v7, v0, v8, v13, v1}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    goto/16 :goto_0

    :cond_2
    const/4 v0, 0x3

    if-ne v0, v1, :cond_3

    mul-float v0, v9, p1

    float-to-int v12, v0

    sub-float v0, v8, v2

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    const/high16 v3, 0x3fc00000    # 1.5f

    sub-float/2addr v0, v3

    mul-float v0, v0, p1

    float-to-int v0, v0

    sub-float v3, v9, v3

    mul-float v3, v3, p1

    float-to-int v14, v3

    sub-float v2, v8, v2

    div-float/2addr v2, v1

    mul-float v2, v2, p1

    float-to-int v15, v2

    .line 49
    invoke-static {v0, v13, v12, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v0

    int-to-float v5, v14

    const/4 v4, 0x1

    const/16 v16, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move v3, v5

    move/from16 v17, v5

    move/from16 v5, v16

    .line 50
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v15, v13, v14}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 51
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v2, v0, v1

    sub-float v2, v9, v2

    mul-float v2, v2, p1

    float-to-int v2, v2

    .line 52
    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v4, v8, v3

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    mul-float v4, v4, p1

    float-to-int v4, v4

    sub-float v0, v9, v0

    mul-float v0, v0, p1

    float-to-int v15, v0

    sub-float v0, v8, v3

    div-float/2addr v0, v5

    add-float/2addr v0, v1

    mul-float v0, v0, p1

    float-to-int v5, v0

    .line 53
    invoke-static {v4, v13, v2, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v5

    int-to-float v4, v2

    const/16 v16, 0x3

    const/16 v18, 0x0

    move-object/from16 v0, p0

    move v1, v11

    move v2, v3

    move v3, v4

    move/from16 v4, v16

    move/from16 v16, v12

    move v12, v5

    move/from16 v5, v18

    .line 54
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v12, v13, v15}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 55
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    sub-float v1, v9, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    .line 56
    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/high16 v3, 0x40000000    # 2.0f

    invoke-static {v8, v2, v3, v2}, Ld/a/a/a/a;->b(FFFF)F

    move-result v4

    iget v5, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float/2addr v4, v5

    mul-float v4, v4, p1

    float-to-int v4, v4

    sub-float/2addr v0, v5

    sub-float/2addr v9, v0

    mul-float v9, v9, p1

    float-to-int v9, v9

    sub-float v0, v8, v2

    div-float/2addr v0, v3

    add-float/2addr v0, v2

    mul-float v0, v0, p1

    float-to-int v12, v0

    .line 57
    invoke-static {v4, v13, v1, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v4

    int-to-float v3, v9

    const/4 v15, 0x4

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move v1, v11

    move v4, v15

    .line 58
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v7, v0, v12, v13, v9}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 59
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v8, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    add-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    sub-float/2addr v8, v0

    div-float/2addr v8, v2

    add-float/2addr v8, v0

    const/high16 v0, 0x3fc00000    # 1.5f

    add-float/2addr v8, v0

    mul-float v8, v8, p1

    float-to-int v8, v8

    .line 60
    invoke-static {v1, v13, v14, v7}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v8

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move v1, v10

    move/from16 v3, v17

    .line 61
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    move/from16 v1, v16

    invoke-static {v7, v0, v8, v13, v1}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    :cond_3
    :goto_0
    return-object v7
.end method

.method public final B(FII)Ljava/util/List;
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FII)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move-object/from16 v6, p0

    move/from16 v7, p2

    move/from16 v8, p3

    .line 1
    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 2
    iget-object v0, v6, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->g:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v0}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v0

    .line 4
    iget-object v1, v6, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->f:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v1}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v1

    .line 6
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0

    int-to-float v2, v7

    div-float v2, v2, p1

    add-float v10, v2, v0

    .line 7
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0

    int-to-float v1, v8

    div-float v1, v1, p1

    add-float v11, v1, v0

    const/high16 v0, 0x3fc00000    # 1.5f

    mul-float v12, p1, v0

    .line 8
    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    mul-float v13, v1, p1

    .line 9
    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    if-ltz v1, :cond_3

    const/4 v2, 0x4

    if-ge v1, v2, :cond_3

    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/4 v3, 0x0

    cmpl-float v4, v2, v3

    if-lez v4, :cond_3

    iget v4, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v3, v4, v3

    if-lez v3, :cond_3

    const/4 v3, 0x1

    const/high16 v14, 0x40000000    # 2.0f

    const-string v15, ","

    if-ne v3, v1, :cond_0

    sub-float v1, v11, v2

    div-float/2addr v1, v14

    sub-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v0, v1

    add-int/2addr v0, v8

    add-int/lit8 v10, v7, 0x0

    sub-float v1, v11, v2

    div-float/2addr v1, v14

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int v5, v1, v8

    float-to-int v1, v12

    add-int v4, v1, v7

    .line 10
    invoke-static {v10, v15, v0, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v4

    int-to-float v2, v0

    const/16 v16, 0x4

    const/16 v17, 0x1

    move-object/from16 v0, p0

    move v1, v12

    move/from16 v18, v2

    move v2, v3

    move/from16 v19, v3

    move/from16 v3, v18

    move v14, v4

    move/from16 v4, v16

    move/from16 v16, v10

    move v10, v5

    move/from16 v5, v17

    .line 11
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v14, v15, v10}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 12
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v0, v11, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int/2addr v0, v8

    .line 13
    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v2, v1, v2

    mul-float v2, v2, p1

    float-to-int v2, v2

    add-int/2addr v2, v7

    int-to-float v3, v0

    add-float/2addr v3, v13

    float-to-int v4, v3

    add-int v10, v4, v8

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int v5, v1, v7

    .line 14
    invoke-static {v2, v15, v0, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    .line 15
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    aput-object v0, v1, v4

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    .line 16
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v4

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    .line 17
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v4, ""

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    aput-object v1, v0, v4

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    int-to-float v2, v2

    const/4 v4, 0x4

    const/16 v17, 0x0

    move-object/from16 v0, p0

    move v1, v13

    move/from16 v20, v12

    move v12, v5

    move/from16 v5, v17

    .line 18
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v12, v15, v10}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 19
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/high16 v1, 0x40000000    # 2.0f

    invoke-static {v11, v0, v1, v0}, Ld/a/a/a/a;->b(FFFF)F

    move-result v2

    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float/2addr v2, v3

    mul-float v2, v2, p1

    float-to-int v2, v2

    add-int/2addr v2, v8

    .line 20
    iget v4, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    mul-float v5, v4, p1

    float-to-int v5, v5

    add-int/2addr v5, v7

    sub-float v10, v11, v0

    div-float/2addr v10, v1

    add-float/2addr v10, v0

    mul-float v10, v10, p1

    float-to-int v0, v10

    add-int v10, v0, v8

    sub-float/2addr v4, v3

    mul-float v4, v4, p1

    float-to-int v0, v4

    add-int/2addr v7, v0

    .line 21
    invoke-static {v5, v15, v2, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v7

    int-to-float v4, v2

    const/4 v5, 0x1

    const/4 v12, 0x0

    move-object/from16 v0, p0

    move v1, v13

    move v2, v3

    move v3, v4

    move v4, v5

    move v5, v12

    .line 22
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v7, v15, v10}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 23
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v11, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    add-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int/2addr v1, v8

    sub-float/2addr v11, v0

    div-float/2addr v11, v2

    add-float/2addr v11, v0

    const/high16 v0, 0x3fc00000    # 1.5f

    add-float/2addr v11, v0

    mul-float v11, v11, p1

    float-to-int v0, v11

    add-int v7, v0, v8

    .line 24
    invoke-static {v14, v15, v1, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v7

    const/4 v4, 0x3

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move/from16 v1, v20

    move/from16 v2, v19

    .line 25
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    move/from16 v1, v16

    invoke-static {v9, v0, v1, v15, v7}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    goto/16 :goto_0

    :cond_0
    move/from16 v20, v12

    if-nez v1, :cond_1

    sub-float v0, v11, v2

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    add-float/2addr v0, v2

    const/high16 v3, 0x3fc00000    # 1.5f

    add-float/2addr v0, v3

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int/2addr v0, v8

    mul-float v3, v10, p1

    float-to-int v7, v3

    sub-float v3, v11, v2

    div-float/2addr v3, v1

    add-float/2addr v3, v2

    mul-float v3, v3, p1

    float-to-int v1, v3

    add-int v12, v1, v8

    const/high16 v1, 0x3fc00000    # 1.5f

    sub-float v1, v10, v1

    mul-float v1, v1, p1

    float-to-int v14, v1

    .line 26
    invoke-static {v7, v15, v0, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v5, v14

    int-to-float v3, v0

    const/4 v4, 0x2

    const/16 v16, 0x1

    move-object/from16 v0, p0

    move/from16 v1, v20

    move v2, v5

    move/from16 v17, v5

    move/from16 v5, v16

    .line 27
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v14, v15, v12}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 28
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v11, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    add-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int/2addr v1, v8

    .line 29
    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v4, v2, v3

    sub-float v4, v10, v4

    mul-float v4, v4, p1

    float-to-int v4, v4

    sub-float v5, v11, v0

    const/high16 v12, 0x40000000    # 2.0f

    div-float/2addr v5, v12

    add-float/2addr v5, v0

    sub-float/2addr v5, v3

    mul-float v5, v5, p1

    float-to-int v0, v5

    add-int v12, v0, v8

    sub-float v0, v10, v2

    mul-float v0, v0, p1

    float-to-int v5, v0

    .line 30
    invoke-static {v4, v15, v1, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v4

    int-to-float v3, v12

    const/4 v4, 0x2

    const/16 v16, 0x0

    move-object/from16 v0, p0

    move v1, v13

    move/from16 v19, v7

    move v7, v5

    move/from16 v5, v16

    .line 31
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v7, v15, v12}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 32
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v11, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    add-float/2addr v1, v3

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int/2addr v1, v8

    .line 33
    iget v4, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    sub-float v5, v10, v4

    mul-float v5, v5, p1

    float-to-int v5, v5

    sub-float v0, v11, v0

    div-float/2addr v0, v2

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int v7, v0, v8

    sub-float/2addr v4, v3

    sub-float/2addr v10, v4

    mul-float v10, v10, p1

    float-to-int v10, v10

    .line 34
    invoke-static {v5, v15, v1, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v10

    int-to-float v3, v1

    const/4 v4, 0x3

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move v1, v13

    .line 35
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v10, v15, v7}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 36
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v11, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int/2addr v1, v8

    sub-float/2addr v11, v0

    div-float/2addr v11, v2

    const/high16 v0, 0x3fc00000    # 1.5f

    sub-float/2addr v11, v0

    mul-float v11, v11, p1

    float-to-int v0, v11

    add-int v7, v0, v8

    .line 37
    invoke-static {v14, v15, v1, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v7

    const/4 v4, 0x1

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move/from16 v1, v20

    move/from16 v2, v17

    .line 38
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    move/from16 v1, v19

    invoke-static {v9, v0, v1, v15, v7}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    goto/16 :goto_0

    :cond_1
    const/4 v0, 0x3

    if-ne v0, v1, :cond_2

    add-int/lit8 v11, v8, 0x0

    sub-float v0, v10, v2

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    add-float/2addr v0, v2

    const/high16 v3, 0x3fc00000    # 1.5f

    add-float/2addr v0, v3

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int/2addr v0, v7

    move/from16 v12, v20

    float-to-int v3, v12

    add-int v14, v3, v8

    sub-float v3, v10, v2

    div-float/2addr v3, v1

    add-float/2addr v3, v2

    mul-float v3, v3, p1

    float-to-int v1, v3

    add-int v5, v1, v7

    .line 39
    invoke-static {v0, v15, v11, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v0

    int-to-float v4, v14

    const/16 v16, 0x3

    const/16 v17, 0x1

    move-object/from16 v0, p0

    move v1, v12

    move v3, v4

    move/from16 v19, v4

    move/from16 v4, v16

    move/from16 v16, v11

    move v11, v5

    move/from16 v5, v17

    .line 40
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v11, v15, v14}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 41
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v2, v0, v1

    mul-float v2, v2, p1

    float-to-int v2, v2

    add-int/2addr v2, v8

    .line 42
    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v4, v10, v3

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    add-float/2addr v4, v3

    mul-float v4, v4, p1

    float-to-int v4, v4

    add-int/2addr v4, v7

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int v11, v0, v8

    sub-float v0, v10, v3

    div-float/2addr v0, v5

    add-float/2addr v0, v3

    sub-float/2addr v0, v1

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int v5, v0, v7

    .line 43
    invoke-static {v4, v15, v2, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v5

    int-to-float v4, v2

    const/16 v20, 0x0

    move-object/from16 v0, p0

    move v1, v13

    move v2, v3

    move v3, v4

    move/from16 v4, v17

    move/from16 v17, v12

    move v12, v5

    move/from16 v5, v20

    .line 44
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v12, v15, v11}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 45
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    mul-float v1, v0, p1

    float-to-int v1, v1

    add-int/2addr v1, v8

    .line 46
    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v3, v10, v2

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v3, v4

    iget v5, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    add-float/2addr v3, v5

    mul-float v3, v3, p1

    float-to-int v3, v3

    add-int/2addr v3, v7

    sub-float/2addr v0, v5

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int/2addr v8, v0

    sub-float v0, v10, v2

    div-float/2addr v0, v4

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int v11, v0, v7

    .line 47
    invoke-static {v3, v15, v1, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v3

    int-to-float v3, v8

    const/4 v12, 0x2

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move v1, v13

    move v4, v12

    .line 48
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v11, v15, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 49
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v10, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int/2addr v1, v7

    sub-float/2addr v10, v0

    div-float/2addr v10, v2

    const/high16 v0, 0x3fc00000    # 1.5f

    sub-float/2addr v10, v0

    mul-float v10, v10, p1

    float-to-int v0, v10

    add-int/2addr v7, v0

    .line 50
    invoke-static {v1, v15, v14, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v7

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move/from16 v1, v17

    move/from16 v3, v19

    .line 51
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    move/from16 v1, v16

    invoke-static {v9, v0, v7, v15, v1}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    goto/16 :goto_0

    :cond_2
    move/from16 v17, v20

    const/4 v0, 0x2

    if-ne v0, v1, :cond_3

    mul-float v0, v11, p1

    float-to-int v0, v0

    add-int v12, v0, v8

    sub-float v0, v10, v2

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    const/high16 v3, 0x3fc00000    # 1.5f

    sub-float/2addr v0, v3

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int/2addr v0, v7

    sub-float v3, v11, v3

    mul-float v3, v3, p1

    float-to-int v3, v3

    add-int v14, v3, v8

    sub-float v2, v10, v2

    div-float/2addr v2, v1

    mul-float v2, v2, p1

    float-to-int v1, v2

    add-int v5, v1, v7

    .line 52
    invoke-static {v0, v15, v12, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v0

    int-to-float v4, v14

    const/16 v16, 0x1

    const/16 v19, 0x1

    move-object/from16 v0, p0

    move/from16 v1, v17

    move v3, v4

    move/from16 v20, v4

    move/from16 v4, v16

    move/from16 v16, v12

    move v12, v5

    move/from16 v5, v19

    .line 53
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v12, v15, v14}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 54
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    iget v1, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float v2, v0, v1

    sub-float v2, v11, v2

    mul-float v2, v2, p1

    float-to-int v2, v2

    add-int/2addr v2, v8

    .line 55
    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v4, v10, v3

    const/high16 v5, 0x40000000    # 2.0f

    div-float/2addr v4, v5

    mul-float v4, v4, p1

    float-to-int v4, v4

    add-int/2addr v4, v7

    sub-float v0, v11, v0

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int v12, v0, v8

    sub-float v0, v10, v3

    div-float/2addr v0, v5

    add-float/2addr v0, v1

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int v5, v0, v7

    .line 56
    invoke-static {v4, v15, v2, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v3, v5

    int-to-float v4, v2

    const/16 v19, 0x3

    const/16 v21, 0x0

    move-object/from16 v0, p0

    move v1, v13

    move v2, v3

    move v3, v4

    move/from16 v4, v19

    move/from16 v19, v14

    move v14, v5

    move/from16 v5, v21

    .line 57
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v14, v15, v12}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 58
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    sub-float v1, v11, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int/2addr v1, v8

    .line 59
    iget v2, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/high16 v3, 0x40000000    # 2.0f

    invoke-static {v10, v2, v3, v2}, Ld/a/a/a/a;->b(FFFF)F

    move-result v4

    iget v3, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    sub-float/2addr v4, v3

    mul-float v4, v4, p1

    float-to-int v4, v4

    add-int/2addr v4, v7

    sub-float/2addr v0, v3

    sub-float/2addr v11, v0

    mul-float v11, v11, p1

    float-to-int v0, v11

    add-int/2addr v8, v0

    sub-float v0, v10, v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v0, v3

    add-float/2addr v0, v2

    mul-float v0, v0, p1

    float-to-int v0, v0

    add-int v11, v0, v7

    .line 60
    invoke-static {v4, v15, v1, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v4

    int-to-float v3, v8

    const/4 v12, 0x4

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move v1, v13

    move v4, v12

    .line 61
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    invoke-static {v9, v0, v11, v15, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 62
    iget v0, v6, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    sub-float v1, v10, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    add-float/2addr v1, v0

    mul-float v1, v1, p1

    float-to-int v1, v1

    add-int/2addr v1, v7

    sub-float/2addr v10, v0

    div-float/2addr v10, v2

    add-float/2addr v10, v0

    const/high16 v0, 0x3fc00000    # 1.5f

    add-float/2addr v10, v0

    mul-float v10, v10, p1

    float-to-int v0, v10

    add-int/2addr v7, v0

    move/from16 v3, v19

    .line 63
    invoke-static {v1, v15, v3, v9}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    int-to-float v2, v7

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move/from16 v1, v17

    move/from16 v3, v20

    .line 64
    invoke-virtual/range {v0 .. v5}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C(FFFII)Ljava/util/List;

    move-result-object v0

    move/from16 v1, v16

    invoke-static {v9, v0, v7, v15, v1}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    :cond_3
    :goto_0
    return-object v9
.end method

.method public final C(FFFII)Ljava/util/List;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FFFII)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    const/4 v2, 0x1

    :goto_0
    const/16 v3, 0xb4

    if-ge v2, v3, :cond_8

    float-to-double v3, p1

    int-to-double v5, v2

    const-wide/high16 v7, 0x3fe0000000000000L    # 0.5

    mul-double v5, v5, v7

    const-wide v7, 0x400921fb54442d18L    # Math.PI

    mul-double v5, v5, v7

    const-wide v7, 0x4066800000000000L    # 180.0

    div-double/2addr v5, v7

    .line 2
    invoke-static {v5, v6}, Ljava/lang/Math;->cos(D)D

    move-result-wide v7

    mul-double v7, v7, v3

    double-to-int v7, v7

    .line 3
    invoke-static {v5, v6}, Ljava/lang/Math;->sin(D)D

    move-result-wide v5

    mul-double v5, v5, v3

    double-to-int v3, v5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v8, ","

    const-string v9, ""

    if-ne v1, p5, :cond_3

    if-ne v1, p4, :cond_0

    int-to-float v3, v3

    add-float/2addr v3, p2

    float-to-int v3, v3

    int-to-float v4, v7

    add-float/2addr v4, p3

    float-to-int v4, v4

    .line 4
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1

    :cond_0
    if-ne v5, p4, :cond_1

    int-to-float v4, v7

    add-float/2addr v4, p2

    float-to-int v4, v4

    int-to-float v3, v3

    sub-float v3, p3, v3

    float-to-int v3, v3

    .line 5
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1

    :cond_1
    if-ne v4, p4, :cond_2

    int-to-float v3, v3

    sub-float v3, p2, v3

    float-to-int v3, v3

    int-to-float v4, v7

    sub-float v4, p3, v4

    float-to-int v4, v4

    .line 6
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1

    :cond_2
    if-ne v6, p4, :cond_7

    int-to-float v4, v7

    sub-float v4, p2, v4

    float-to-int v4, v4

    int-to-float v3, v3

    add-float/2addr v3, p3

    float-to-int v3, v3

    .line 7
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_1

    :cond_3
    if-ne v1, p4, :cond_4

    int-to-float v4, v7

    add-float/2addr v4, p2

    float-to-int v4, v4

    int-to-float v3, v3

    add-float/2addr v3, p3

    float-to-int v3, v3

    .line 8
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_4
    if-ne v5, p4, :cond_5

    int-to-float v3, v3

    sub-float v3, p2, v3

    float-to-int v3, v3

    int-to-float v4, v7

    add-float/2addr v4, p3

    float-to-int v4, v4

    .line 9
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_5
    if-ne v4, p4, :cond_6

    int-to-float v4, v7

    sub-float v4, p2, v4

    float-to-int v4, v4

    int-to-float v3, v3

    sub-float v3, p3, v3

    float-to-int v3, v3

    .line 10
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_6
    if-ne v6, p4, :cond_7

    int-to-float v3, v3

    add-float/2addr v3, p2

    float-to-int v3, v3

    int-to-float v4, v7

    sub-float v4, p3, v4

    float-to-int v4, v4

    .line 11
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_7
    :goto_1
    add-int/lit8 v2, v2, 0x4

    goto/16 :goto_0

    :cond_8
    return-object v0
.end method

.method public final D(Ljava/lang/String;)Landroid/widget/CheckBox;
    .locals 3

    .line 1
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, 0x0

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v1

    const/4 v2, 0x5

    if-nez v1, :cond_0

    .line 3
    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_0

    .line 4
    :cond_0
    invoke-virtual {v0, v2, v2, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    :goto_0
    const/high16 v1, 0x3f800000    # 1.0f

    .line 5
    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 6
    new-instance v1, Landroid/widget/CheckBox;

    invoke-direct {v1, p0}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 7
    invoke-virtual {v1, v0}, Landroid/widget/CheckBox;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 8
    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setTextAlignment(I)V

    .line 9
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v2, 0x7f06007b

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/CheckBox;->setTextColor(I)V

    const v0, 0x7f08007b

    .line 10
    invoke-virtual {v1, v0}, Landroid/widget/CheckBox;->setButtonDrawable(I)V

    .line 11
    invoke-static {v1}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 12
    invoke-virtual {v1, p1}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    const/high16 p1, 0x41400000    # 12.0f

    .line 13
    invoke-virtual {v1, p1}, Landroid/widget/CheckBox;->setTextSize(F)V

    return-object v1
.end method

.method public final E()V
    .locals 18

    move-object/from16 v0, p0

    .line 1
    iget-object v1, v0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->g:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v1}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v1

    .line 3
    iget-object v2, v0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->f:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v2}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v2

    .line 5
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_19

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_0

    goto/16 :goto_6

    .line 6
    :cond_0
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    .line 7
    invoke-static {v2}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    .line 8
    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/high16 v4, 0x40000000    # 2.0f

    div-float/2addr v3, v4

    .line 9
    iget-object v4, v0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast v4, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v4, v4, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->k:Landroidx/appcompat/widget/AppCompatSpinner;

    invoke-virtual {v4}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v4

    .line 11
    iget-object v5, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->I:Landroid/widget/ArrayAdapter;

    invoke-virtual {v5, v4}, Landroid/widget/ArrayAdapter;->getItem(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 12
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v6, 0x0

    if-nez v5, :cond_1

    .line 13
    invoke-static {v4}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v4

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    :goto_0
    cmpg-float v3, v3, v4

    if-gez v3, :cond_2

    const v1, 0x7f1100ca

    .line 14
    invoke-virtual {v0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    return-void

    :cond_2
    const/high16 v3, 0x40800000    # 4.0f

    cmpg-float v5, v1, v3

    if-ltz v5, :cond_18

    cmpg-float v5, v2, v3

    if-gez v5, :cond_3

    goto/16 :goto_5

    .line 15
    :cond_3
    iget v5, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->l:F

    sub-float/2addr v5, v3

    cmpl-float v5, v1, v5

    if-lez v5, :cond_4

    const v1, 0x7f1100e7

    .line 16
    invoke-virtual {v0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    return-void

    :cond_4
    cmpl-float v5, v1, v3

    if-ltz v5, :cond_17

    cmpl-float v3, v2, v3

    if-ltz v3, :cond_17

    const/4 v3, 0x4

    const/high16 v5, 0x43c80000    # 400.0f

    cmpl-float v7, v1, v5

    if-gtz v7, :cond_5

    cmpl-float v5, v2, v5

    if-lez v5, :cond_6

    :cond_5
    const/4 v3, 0x1

    :cond_6
    int-to-float v3, v3

    mul-float v1, v1, v3

    mul-float v2, v2, v3

    mul-float v4, v4, v3

    .line 17
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const-string v7, "0,"

    .line 18
    invoke-static {v7}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    float-to-int v9, v4

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 19
    iget v8, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    if-nez v8, :cond_7

    iget v8, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    cmpl-float v8, v8, v6

    if-lez v8, :cond_7

    iget v8, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v8, v8, v6

    if-lez v8, :cond_7

    .line 20
    invoke-virtual {v0, v3}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A(F)Ljava/util/List;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 21
    :cond_7
    invoke-static {v7}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    sub-float v10, v2, v4

    float-to-int v11, v10

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    cmpl-float v8, v4, v6

    if-lez v8, :cond_8

    const/16 v12, 0x10e

    .line 22
    invoke-virtual {v0, v4, v4, v10, v12}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 23
    :cond_8
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v13, ","

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    float-to-int v14, v2

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v5, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v12, 0x3

    .line 24
    iget v15, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    if-ne v12, v15, :cond_9

    iget v12, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    cmpl-float v12, v12, v6

    if-lez v12, :cond_9

    iget v12, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v6, v12, v6

    if-lez v6, :cond_9

    .line 25
    invoke-virtual {v0, v3}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A(F)Ljava/util/List;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 26
    :cond_9
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    sub-float v12, v1, v4

    float-to-int v15, v12

    invoke-virtual {v6, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-lez v8, :cond_a

    const/16 v6, 0x168

    .line 27
    invoke-virtual {v0, v4, v12, v10, v6}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 28
    :cond_a
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    float-to-int v10, v1

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 29
    iget v6, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    const/4 v11, 0x1

    if-ne v11, v6, :cond_b

    iget v6, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/4 v11, 0x0

    cmpl-float v6, v6, v11

    if-lez v6, :cond_b

    iget v6, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v6, v6, v11

    if-lez v6, :cond_b

    .line 30
    invoke-virtual {v0, v3}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A(F)Ljava/util/List;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 31
    :cond_b
    invoke-static {v10, v13, v9, v5}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    if-lez v8, :cond_c

    const/16 v6, 0x5a

    .line 32
    invoke-virtual {v0, v4, v12, v4, v6}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_c
    const/4 v6, 0x0

    .line 33
    invoke-static {v15, v13, v6, v5}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    .line 34
    iget v10, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    const/4 v11, 0x2

    if-ne v11, v10, :cond_d

    iget v10, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    const/4 v12, 0x0

    cmpl-float v10, v10, v12

    if-lez v10, :cond_d

    iget v10, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v10, v10, v12

    if-lez v10, :cond_d

    .line 35
    invoke-virtual {v0, v3}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A(F)Ljava/util/List;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 36
    :cond_d
    invoke-static {v9, v13, v6, v5}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    if-lez v8, :cond_e

    const/16 v3, 0xb4

    .line 37
    invoke-virtual {v0, v4, v4, v4, v3}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 38
    :cond_e
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/high16 v3, 0x41a00000    # 20.0f

    add-float/2addr v1, v3

    float-to-int v1, v1

    add-float/2addr v2, v3

    float-to-int v2, v2

    .line 39
    iget-object v3, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->O:Landroid/graphics/Bitmap;

    const/4 v4, 0x0

    if-eqz v3, :cond_f

    .line 40
    invoke-virtual {v3}, Landroid/graphics/Bitmap;->recycle()V

    .line 41
    iput-object v4, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->O:Landroid/graphics/Bitmap;

    .line 42
    :cond_f
    iget-object v3, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    if-eqz v3, :cond_10

    .line 43
    iput-object v4, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    .line 44
    :cond_10
    sget-object v3, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v2, v3}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    iput-object v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->O:Landroid/graphics/Bitmap;

    .line 45
    new-instance v1, Landroid/graphics/Canvas;

    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->O:Landroid/graphics/Bitmap;

    invoke-direct {v1, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    iput-object v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    .line 46
    new-instance v1, Landroid/graphics/Paint;

    invoke-direct {v1}, Landroid/graphics/Paint;-><init>()V

    const/4 v2, 0x1

    .line 47
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    .line 48
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setDither(Z)V

    const/high16 v2, -0x1000000

    .line 49
    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 50
    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 51
    sget-object v2, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 52
    sget-object v2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 53
    new-instance v2, Landroid/graphics/CornerPathEffect;

    const/high16 v3, 0x40400000    # 3.0f

    invoke-direct {v2, v3}, Landroid/graphics/CornerPathEffect;-><init>(F)V

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setPathEffect(Landroid/graphics/PathEffect;)Landroid/graphics/PathEffect;

    .line 54
    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 55
    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 56
    new-instance v2, Landroid/graphics/Path;

    invoke-direct {v2}, Landroid/graphics/Path;-><init>()V

    const/4 v3, 0x0

    .line 57
    :goto_1
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-ge v3, v4, :cond_16

    .line 58
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const-string v7, "U"

    const-string v8, ""

    .line 59
    invoke-virtual {v4, v7, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v7, "D"

    .line 60
    invoke-virtual {v4, v7, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 61
    invoke-virtual {v4, v13}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 62
    array-length v7, v4

    if-ne v11, v7, :cond_15

    .line 63
    aget-object v7, v4, v6

    const/4 v9, 0x1

    .line 64
    aget-object v4, v4, v9

    .line 65
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_15

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_11

    goto :goto_4

    :cond_11
    const-string v9, "-"

    .line 66
    invoke-virtual {v7, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    const-wide/high16 v14, -0x4010000000000000L    # -1.0

    if-eqz v10, :cond_12

    .line 67
    invoke-virtual {v7, v9, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 68
    invoke-static {v7}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v16

    mul-double v16, v16, v14

    goto :goto_2

    .line 69
    :cond_12
    invoke-static {v7}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v16

    :goto_2
    move-wide/from16 v6, v16

    double-to-int v6, v6

    int-to-double v6, v6

    .line 70
    invoke-virtual {v4, v9}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_13

    .line 71
    invoke-virtual {v4, v9, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 72
    invoke-static {v4}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v8

    mul-double v8, v8, v14

    goto :goto_3

    .line 73
    :cond_13
    invoke-static {v4}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v8

    :goto_3
    double-to-int v4, v8

    int-to-double v8, v4

    const-wide/high16 v14, 0x4024000000000000L    # 10.0

    if-nez v3, :cond_14

    add-double/2addr v6, v14

    double-to-float v4, v6

    add-double/2addr v8, v14

    double-to-float v6, v8

    .line 74
    invoke-virtual {v2, v4, v6}, Landroid/graphics/Path;->moveTo(FF)V

    goto :goto_4

    :cond_14
    add-double/2addr v6, v14

    double-to-float v4, v6

    add-double/2addr v8, v14

    double-to-float v6, v8

    .line 75
    invoke-virtual {v2, v4, v6}, Landroid/graphics/Path;->lineTo(FF)V

    :cond_15
    :goto_4
    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    goto :goto_1

    .line 76
    :cond_16
    iget-object v3, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    invoke-virtual {v3, v2, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 77
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    invoke-virtual {v1}, Landroid/graphics/Canvas;->save()I

    .line 78
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    invoke-virtual {v1}, Landroid/graphics/Canvas;->restore()V

    .line 79
    iget-object v1, v0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 80
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->h:Landroid/widget/ImageView;

    iget-object v2, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->O:Landroid/graphics/Bitmap;

    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_17
    return-void

    :cond_18
    :goto_5
    const v1, 0x7f1100cb

    .line 81
    invoke-virtual {v0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    :cond_19
    :goto_6
    return-void
.end method

.method public final F(FFF)Ljava/lang/String;
    .locals 17

    move-object/from16 v0, p0

    const/high16 v1, 0x42200000    # 40.0f

    mul-float v2, p1, v1

    float-to-int v2, v2

    mul-float v3, p2, v1

    float-to-int v3, v3

    mul-float v4, p3, v1

    float-to-int v4, v4

    .line 1
    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 2
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    sub-int v7, v2, v4

    const/4 v8, 0x0

    add-int/2addr v7, v8

    add-int/lit8 v9, v7, -0x28

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, ","

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v10, v3, 0x0

    add-int/lit8 v11, v10, 0x28

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 3
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    int-to-float v6, v4

    int-to-float v11, v7

    sub-int v12, v3, v4

    add-int/2addr v12, v8

    int-to-float v13, v12

    const/16 v14, 0x168

    .line 4
    invoke-virtual {v0, v6, v11, v13, v14}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v14

    invoke-virtual {v5, v14}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 5
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v15, v2, 0x0

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v5, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 6
    iget v14, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    const/16 v16, 0x0

    if-nez v14, :cond_0

    iget v14, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    cmpl-float v14, v14, v16

    if-lez v14, :cond_0

    iget v14, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v14, v14, v16

    if-lez v14, :cond_0

    .line 7
    invoke-virtual {v0, v1, v8, v8}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->B(FII)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 8
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/2addr v4, v8

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    int-to-float v1, v4

    const/16 v14, 0x5a

    .line 9
    invoke-virtual {v0, v6, v11, v1, v14}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v11

    invoke-static {v5, v11, v7, v9, v8}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    const/4 v11, 0x3

    .line 10
    iget v14, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    if-ne v11, v14, :cond_1

    iget v11, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    cmpl-float v11, v11, v16

    if-lez v11, :cond_1

    iget v11, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v11, v11, v16

    if-lez v11, :cond_1

    const/high16 v11, 0x42200000    # 40.0f

    .line 11
    invoke-virtual {v0, v11, v8, v8}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->B(FII)Ljava/util/List;

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 12
    :cond_1
    invoke-static {v4, v9, v8, v5}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    const/16 v11, 0xb4

    .line 13
    invoke-virtual {v0, v6, v1, v1, v11}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v11

    invoke-static {v5, v11, v8, v9, v4}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 14
    iget v11, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    const/4 v14, 0x1

    if-ne v14, v11, :cond_2

    iget v11, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    cmpl-float v11, v11, v16

    if-lez v11, :cond_2

    iget v11, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v11, v11, v16

    if-lez v11, :cond_2

    const/high16 v11, 0x42200000    # 40.0f

    .line 15
    invoke-virtual {v0, v11, v8, v8}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->B(FII)Ljava/util/List;

    move-result-object v11

    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 16
    :cond_2
    invoke-static {v8, v9, v12, v5}, Ld/a/a/a/a;->G(ILjava/lang/String;ILjava/util/ArrayList;)V

    const/16 v11, 0x10e

    .line 17
    invoke-virtual {v0, v6, v1, v13, v11}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G(FFFI)Ljava/util/List;

    move-result-object v1

    invoke-static {v5, v1, v4, v9, v10}, Ld/a/a/a/a;->N(Ljava/util/ArrayList;Ljava/util/List;ILjava/lang/String;I)V

    .line 18
    iget v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    const/4 v4, 0x2

    if-ne v4, v1, :cond_3

    iget v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    cmpl-float v1, v1, v16

    if-lez v1, :cond_3

    iget v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    cmpl-float v1, v1, v16

    if-lez v1, :cond_3

    const/high16 v1, 0x42200000    # 40.0f

    .line 19
    invoke-virtual {v0, v1, v8, v8}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->B(FII)Ljava/util/List;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 20
    :cond_3
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 21
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 22
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    add-int/lit8 v15, v15, 0x50

    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 23
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ""

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 24
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 25
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 26
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 27
    invoke-virtual {v1}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    const/4 v10, 0x0

    .line 28
    :goto_0
    array-length v11, v1

    if-ge v10, v11, :cond_4

    .line 29
    aget-char v11, v1, v10

    .line 30
    iget-object v12, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v12, v11}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    .line 31
    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v10, v10, 0x1

    goto :goto_0

    .line 32
    :cond_4
    invoke-virtual {v3}, Ljava/lang/String;->toCharArray()[C

    move-result-object v1

    const/4 v3, 0x0

    .line 33
    :goto_1
    array-length v10, v1

    if-ge v3, v10, :cond_5

    .line 34
    aget-char v10, v1, v3

    .line 35
    iget-object v11, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v11, v10}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    .line 36
    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    .line 37
    :cond_5
    iget-object v1, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v3, "0"

    invoke-virtual {v1, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 38
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 39
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    .line 40
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "IN SJM=515167676782828 FSIZE"

    const-string v11, ";"

    .line 41
    invoke-static {v10, v6, v9, v3, v11}, Ld/a/a/a/a;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "U"

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, " "

    .line 43
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "D"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    .line 46
    :goto_2
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v12

    if-ge v10, v12, :cond_b

    .line 47
    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    .line 48
    invoke-virtual {v12, v6, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 49
    invoke-virtual {v12, v11, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    .line 50
    invoke-virtual {v12, v9}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    .line 51
    array-length v13, v12

    if-ne v4, v13, :cond_a

    .line 52
    aget-object v4, v12, v8

    const/4 v8, 0x1

    .line 53
    aget-object v8, v12, v8

    .line 54
    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_a

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_6

    goto/16 :goto_5

    .line 55
    :cond_6
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    .line 56
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    .line 57
    invoke-virtual {v4}, Ljava/lang/String;->toCharArray()[C

    move-result-object v4

    const/4 v14, 0x0

    .line 58
    :goto_3
    array-length v15, v4

    if-ge v14, v15, :cond_7

    .line 59
    aget-char v15, v4, v14

    move-object/from16 p1, v4

    .line 60
    iget-object v4, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    move-object/from16 p2, v5

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 61
    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v14, v14, 0x1

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    goto :goto_3

    :cond_7
    move-object/from16 p2, v5

    .line 62
    invoke-virtual {v8}, Ljava/lang/String;->toCharArray()[C

    move-result-object v4

    const/4 v5, 0x0

    .line 63
    :goto_4
    array-length v8, v4

    if-ge v5, v8, :cond_8

    .line 64
    aget-char v8, v4, v5

    .line 65
    iget-object v14, v0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v14, v8}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .line 66
    invoke-virtual {v13, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v5, v5, 0x1

    goto :goto_4

    :cond_8
    if-nez v10, :cond_9

    .line 67
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 69
    :cond_9
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_6

    :cond_a
    :goto_5
    move-object/from16 p2, v5

    :goto_6
    add-int/lit8 v10, v10, 0x1

    const/4 v4, 0x2

    const/4 v8, 0x0

    move-object/from16 v5, p2

    goto/16 :goto_2

    .line 71
    :cond_b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " @ "

    .line 72
    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const-string v2, "********:"

    .line 73
    invoke-static {v2}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 74
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    return-object v1
.end method

.method public final G(FFFI)Ljava/util/List;
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(FFFI)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    move/from16 v0, p1

    move/from16 v1, p2

    move/from16 v2, p3

    move/from16 v3, p4

    const/4 v4, 0x1

    new-array v5, v4, [Ljava/lang/Object;

    const-string v6, "----radius type:"

    .line 1
    invoke-static {v6, v3}, Ld/a/a/a/a;->e(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    aput-object v6, v5, v7

    invoke-static {v5}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    new-array v5, v4, [Ljava/lang/Object;

    .line 2
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "----radius:"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v7

    invoke-static {v5}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    new-array v5, v4, [Ljava/lang/Object;

    .line 3
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "----cx:"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v7

    invoke-static {v5}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    new-array v4, v4, [Ljava/lang/Object;

    .line 4
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "----cy:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v7

    invoke-static {v4}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 5
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x4

    move v6, v3

    :goto_0
    const/16 v7, 0xb4

    if-ge v5, v7, :cond_4

    float-to-double v7, v0

    int-to-double v9, v5

    const-wide/high16 v11, 0x3fe0000000000000L    # 0.5

    mul-double v9, v9, v11

    const-wide v11, 0x400921fb54442d18L    # Math.PI

    mul-double v9, v9, v11

    const-wide v11, 0x4066800000000000L    # 180.0

    div-double/2addr v9, v11

    .line 6
    invoke-static {v9, v10}, Ljava/lang/Math;->cos(D)D

    move-result-wide v11

    mul-double v11, v11, v7

    .line 7
    invoke-static {v9, v10}, Ljava/lang/Math;->sin(D)D

    move-result-wide v9

    mul-double v9, v9, v7

    const/16 v7, 0x5a

    const-string v8, "-----y:"

    const-string v13, "-----dy:"

    const-string v14, "-----cy:"

    const-string v15, ","

    const-string v0, ""

    if-ne v7, v6, :cond_0

    move v7, v5

    move/from16 v16, v6

    float-to-double v5, v1

    add-double/2addr v5, v11

    double-to-int v5, v5

    move/from16 v17, v7

    float-to-double v6, v2

    sub-double/2addr v6, v9

    double-to-int v6, v6

    .line 8
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v0, 0x1

    new-array v7, v0, [Ljava/lang/Object;

    .line 9
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "90----cx:"

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v14, 0x0

    aput-object v0, v7, v14

    invoke-static {v7}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    .line 10
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "90----dx:"

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v11, v12}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v9, v10}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v14

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v7, "90----x:"

    .line 11
    invoke-static {v7, v5, v8, v6}, Ld/a/a/a/a;->g(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;

    move-result-object v5

    aput-object v5, v0, v14

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    move v5, v3

    move-object v3, v4

    goto/16 :goto_1

    :cond_0
    move/from16 v17, v5

    move/from16 v16, v6

    const/16 v5, 0xb4

    if-ne v5, v6, :cond_1

    move/from16 v16, v6

    float-to-double v5, v1

    sub-double/2addr v5, v9

    double-to-int v5, v5

    float-to-double v6, v2

    sub-double/2addr v6, v11

    double-to-int v6, v6

    const/4 v7, 0x1

    new-array v7, v7, [Ljava/lang/Object;

    .line 12
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v18, v4

    const-string v4, "180----cx:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v7, v4

    invoke-static {v7}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    .line 13
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "180----dx:"

    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v11, v12}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v9, v10}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v3, v4

    invoke-static {v3}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const-string v7, "180----x:"

    .line 14
    invoke-static {v7, v5, v8, v6}, Ld/a/a/a/a;->g(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;

    move-result-object v7

    aput-object v7, v3, v4

    invoke-static {v3}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 15
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v3, v18

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v5, p4

    :goto_1
    move/from16 v6, v16

    goto/16 :goto_3

    :cond_1
    move-object v3, v4

    move/from16 v16, v6

    const/16 v4, 0x10e

    move/from16 v5, v16

    if-ne v4, v5, :cond_2

    float-to-double v4, v1

    sub-double/2addr v4, v11

    double-to-int v4, v4

    float-to-double v5, v2

    add-double/2addr v5, v9

    double-to-int v5, v5

    const/4 v6, 0x1

    new-array v6, v6, [Ljava/lang/Object;

    .line 16
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v18, v3

    const-string v3, "270----cx:"

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    aput-object v3, v6, v7

    invoke-static {v6}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    .line 17
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "270----dx:"

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v11, v12}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v9, v10}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v3, v7

    invoke-static {v3}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v3, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const-string v6, "270----x:"

    .line 18
    invoke-static {v6, v4, v8, v5}, Ld/a/a/a/a;->g(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v3, v7

    invoke-static {v3}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 19
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v3, v18

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move/from16 v5, p4

    goto :goto_2

    :cond_2
    const/16 v4, 0x168

    move/from16 v5, p4

    if-ne v4, v5, :cond_3

    float-to-double v6, v1

    add-double/2addr v6, v9

    double-to-int v4, v6

    float-to-double v6, v2

    add-double/2addr v6, v11

    double-to-int v6, v6

    .line 20
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    .line 21
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "360----cx:"

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x0

    aput-object v7, v0, v14

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    .line 22
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "360----dx:"

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v11, v12}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v9, v10}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    aput-object v7, v0, v14

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v7, "360----x:"

    .line 23
    invoke-static {v7, v4, v8, v6}, Ld/a/a/a/a;->g(Ljava/lang/String;ILjava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v14

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    :cond_3
    :goto_2
    move v6, v5

    :goto_3
    add-int/lit8 v0, v17, 0x4

    move-object v4, v3

    move v3, v5

    move v5, v0

    move/from16 v0, p1

    goto/16 :goto_0

    :cond_4
    move-object v3, v4

    return-object v3
.end method

.method public final H(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v0, "\\*"

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 2
    array-length v0, p1

    const/4 v1, 0x2

    if-ne v1, v0, :cond_0

    const/4 v0, 0x0

    .line 3
    aget-object v0, p1, v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x1

    .line 4
    aget-object p1, p1, v1

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    const-string v1, " W:"

    const-string v2, " L:"

    const-string v3, " mm"

    .line 5
    invoke-static {v1, p1, v2, v0, v3}, Ld/a/a/a/a;->h(Ljava/lang/String;ILjava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    const-string p1, ""

    :goto_0
    return-object p1
.end method

.method public final I(Ljava/lang/String;)Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;
    .locals 5

    const-string v0, ""

    .line 1
    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->m:I

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    .line 2
    new-instance v2, Lorg/json/JSONObject;

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const-string v3, "productId"

    const-string v4, "-10"

    .line 3
    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "remark"

    .line 4
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->E:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "uuid"

    .line 5
    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->F:Ljava/lang/String;

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v3, "packageType"

    .line 6
    invoke-virtual {v2, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v1, "feedBack"

    .line 7
    invoke-virtual {v2, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "1"

    const-string v1, "material"

    .line 8
    invoke-static {v1}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 9
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {p1}, Lc/b/a/a/m/d;->c0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string v1, "pressure"

    .line 10
    invoke-virtual {v2, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 11
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {p1}, Lc/b/a/a/m/d;->d0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const-string v1, "speed"

    .line 12
    invoke-virtual {v2, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "pltCode"

    .line 13
    invoke-virtual {v2, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p1, "pltVersion"

    .line 14
    invoke-virtual {v2, p1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 15
    invoke-virtual {p1}, Lorg/json/JSONException;->printStackTrace()V

    .line 16
    :cond_0
    :goto_0
    new-instance p1, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    invoke-direct {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;-><init>()V

    const/4 v0, 0x0

    .line 17
    invoke-virtual {p1, v0}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;->setIsUpdate(Z)V

    .line 18
    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;->setJson(Ljava/lang/String;)V

    return-object p1
.end method

.method public final J()V
    .locals 15

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->g:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v0}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v0

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->f:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v1}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v1

    .line 5
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const-string v3, ""

    const/high16 v4, 0x40800000    # 4.0f

    const/4 v5, 0x2

    const-string v6, "\\*"

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-nez v2, :cond_2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    sget-object v2, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    if-eqz v2, :cond_2

    .line 6
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_2

    .line 7
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    .line 8
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v9

    const/4 v10, 0x0

    .line 9
    :goto_0
    sget-object v11, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    if-ge v10, v11, :cond_2

    .line 10
    sget-object v11, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v11, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    .line 11
    invoke-virtual {v11, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    .line 12
    array-length v13, v12

    if-eq v5, v13, :cond_0

    goto :goto_1

    .line 13
    :cond_0
    aget-object v13, v12, v8

    invoke-static {v13}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v13

    .line 14
    aget-object v12, v12, v7

    invoke-static {v12}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v12

    const/high16 v14, 0x41a80000    # 21.0f

    sub-float/2addr v13, v14

    cmpg-float v13, v2, v13

    if-gtz v13, :cond_1

    sub-float/2addr v12, v4

    cmpg-float v12, v9, v12

    if-gtz v12, :cond_1

    goto :goto_2

    :cond_1
    :goto_1
    add-int/lit8 v10, v10, 0x1

    goto :goto_0

    :cond_2
    move-object v11, v3

    .line 15
    :goto_2
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v9, 0x0

    if-eqz v2, :cond_3

    const/4 v1, 0x0

    goto :goto_3

    :cond_3
    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    .line 16
    :goto_3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_4

    const/4 v0, 0x0

    goto :goto_4

    :cond_4
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0

    .line 17
    :goto_4
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const v10, 0x7f060077

    if-nez v2, :cond_f

    sget-object v2, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    if-eqz v2, :cond_f

    .line 18
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_f

    .line 19
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 20
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v2, v7}, Landroid/widget/Button;->setEnabled(Z)V

    .line 21
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 22
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->c:Landroid/widget/ImageButton;

    invoke-virtual {v2, v7}, Landroid/widget/ImageButton;->setEnabled(Z)V

    .line 23
    invoke-virtual {v11, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v2

    .line 24
    array-length v12, v2

    if-eq v5, v12, :cond_5

    return-void

    .line 25
    :cond_5
    aget-object v12, v2, v7

    invoke-static {v12}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v12

    .line 26
    aget-object v2, v2, v8

    invoke-static {v2}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    cmpl-float v12, v9, v12

    if-nez v12, :cond_7

    cmpl-float v2, v9, v2

    if-nez v2, :cond_7

    const/4 v0, 0x0

    .line 27
    :goto_5
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_11

    .line 28
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_6

    .line 29
    instance-of v2, v1, Landroid/widget/CheckBox;

    if-eqz v2, :cond_6

    .line 30
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v10}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 31
    invoke-virtual {v1, v8}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 32
    invoke-virtual {v1, v8}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_6
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 33
    :cond_7
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    const/16 v9, 0x320

    .line 34
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v10, "BackEdgeSize"

    invoke-virtual {v2, v10, v9}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v2

    int-to-float v2, v2

    const/high16 v9, 0x42200000    # 40.0f

    div-float/2addr v2, v9

    add-float/2addr v2, v1

    const/high16 v1, 0x3f800000    # 1.0f

    add-float/2addr v2, v1

    const/4 v1, 0x0

    .line 35
    :goto_6
    sget-object v9, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    const v10, 0x7f06007b

    if-ge v1, v9, :cond_c

    .line 36
    sget-object v9, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v9, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    .line 37
    iget-object v12, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v12, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/widget/CheckBox;

    .line 38
    invoke-virtual {v9, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v13

    .line 39
    array-length v14, v13

    if-eq v5, v14, :cond_8

    goto :goto_8

    .line 40
    :cond_8
    aget-object v5, v13, v8

    invoke-static {v5}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v5

    .line 41
    aget-object v13, v13, v7

    invoke-static {v13}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v13

    if-eqz v12, :cond_b

    .line 42
    instance-of v14, v12, Landroid/widget/CheckBox;

    if-eqz v14, :cond_b

    .line 43
    iget v14, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->l:F

    cmpg-float v14, v13, v14

    if-gtz v14, :cond_a

    add-float v14, v0, v4

    cmpl-float v13, v13, v14

    if-ltz v13, :cond_a

    cmpl-float v5, v5, v2

    if-ltz v5, :cond_a

    .line 44
    invoke-virtual {v12, v7}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 45
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5, v10}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {v12, v5}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 46
    invoke-static {v12}, Lc/b/a/a/m/d;->z(Landroid/widget/CheckBox;)V

    .line 47
    invoke-virtual {v9, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_9

    const/4 v5, 0x1

    goto :goto_7

    :cond_9
    const/4 v5, 0x0

    :goto_7
    invoke-virtual {v12, v5}, Landroid/widget/CheckBox;->setChecked(Z)V

    goto :goto_8

    .line 48
    :cond_a
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v9, 0x7f060077

    invoke-virtual {v5, v9}, Landroid/content/res/Resources;->getColor(I)I

    move-result v5

    invoke-virtual {v12, v5}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 49
    invoke-virtual {v12, v8}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 50
    invoke-virtual {v12, v8}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_b
    :goto_8
    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    goto :goto_6

    .line 51
    :cond_c
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 52
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "IS_re_material"

    invoke-virtual {v1, v5, v8}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v1

    .line 53
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v5

    .line 54
    iget-object v5, v5, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v9, "lastMaterialSize"

    invoke-virtual {v5, v9, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v1, :cond_11

    .line 55
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_11

    const/4 v1, 0x0

    .line 56
    :goto_9
    sget-object v5, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v1, v5, :cond_11

    .line 57
    sget-object v5, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 58
    iget-object v9, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v9, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/widget/CheckBox;

    .line 59
    invoke-virtual {v5, v6}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v11

    .line 60
    array-length v12, v11

    const/4 v13, 0x2

    if-eq v13, v12, :cond_d

    goto :goto_a

    .line 61
    :cond_d
    aget-object v12, v11, v8

    invoke-static {v12}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v12

    .line 62
    aget-object v11, v11, v7

    invoke-static {v11}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v11

    if-eqz v9, :cond_e

    .line 63
    instance-of v13, v9, Landroid/widget/CheckBox;

    if-eqz v13, :cond_e

    .line 64
    iget v13, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->l:F

    cmpg-float v13, v11, v13

    if-gtz v13, :cond_e

    add-float v13, v0, v4

    cmpl-float v11, v11, v13

    if-ltz v11, :cond_e

    cmpl-float v11, v12, v2

    if-ltz v11, :cond_e

    .line 65
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    invoke-virtual {v11, v10}, Landroid/content/res/Resources;->getColor(I)I

    move-result v11

    invoke-virtual {v9, v11}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 66
    invoke-virtual {v9, v7}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 67
    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_e

    .line 68
    invoke-virtual {v9, v7}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_e
    :goto_a
    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_f
    const/4 v0, 0x0

    .line 69
    :goto_b
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_11

    .line 70
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_10

    .line 71
    instance-of v2, v1, Landroid/widget/CheckBox;

    if-eqz v2, :cond_10

    .line 72
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f060077

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getColor(I)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 73
    invoke-virtual {v1, v8}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 74
    invoke-virtual {v1, v8}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_10
    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    :cond_11
    return-void
.end method

.method public synthetic M(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 1
    check-cast p1, Landroid/widget/CheckBox;

    invoke-virtual {p0, p1, p2}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->a0(Landroid/widget/CheckBox;Z)V

    return-void
.end method

.method public synthetic N(Landroid/widget/CompoundButton;Z)V
    .locals 0

    .line 1
    check-cast p1, Landroid/widget/CheckBox;

    invoke-virtual {p0, p1, p2}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->a0(Landroid/widget/CheckBox;Z)V

    return-void
.end method

.method public O(ZLjava/lang/String;Ljava/lang/Integer;)V
    .locals 1

    .line 1
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    const/4 v0, 0x1

    if-ne p3, v0, :cond_1

    if-eqz p1, :cond_0

    .line 2
    invoke-virtual {p0, p2}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->h0(Ljava/lang/String;)V

    goto :goto_0

    .line 3
    :cond_0
    invoke-virtual {p0, p2}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->Z(Ljava/lang/String;)V

    .line 4
    :goto_0
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    const p2, 0x7f1100d2

    invoke-virtual {p0, p2}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_1

    :cond_1
    const-string p1, "IN U0,0 @ "

    .line 6
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    :goto_1
    return-void
.end method

.method public synthetic P(Landroid/view/View;)Z
    .locals 0

    const/4 p1, 0x0

    .line 1
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->e0(Z)V

    const/4 p1, 0x1

    return p1
.end method

.method public Q(Landroid/view/View;)V
    .locals 0

    .line 1
    sget-object p1, Lcn/upus/app/upprinting/MApp;->x:Lcn/upus/app/upprinting/MApp;

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/MApp;->d()V

    const/4 p1, 0x1

    .line 3
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->e0(Z)V

    return-void
.end method

.method public synthetic R(Landroid/view/View;)Z
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->X()V

    const/4 p1, 0x0

    return p1
.end method

.method public S(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 2
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 3
    new-instance v1, Lc/b/a/a/l/b/p;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2, p1}, Lc/b/a/a/l/b/p;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;ZLjava/lang/String;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 4
    invoke-static {p1, v0}, Lc/b/a/a/h/c/e;->m(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void
.end method

.method public synthetic T(Ljava/lang/Boolean;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x0

    .line 2
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->g0(Z)V

    :cond_0
    return-void
.end method

.method public synthetic U(FFFI)V
    .locals 0

    .line 1
    iput p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->x:F

    .line 2
    iput p2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->y:F

    .line 3
    iput p3, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->z:F

    .line 4
    iput p4, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->A:I

    .line 5
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->E()V

    return-void
.end method

.method public synthetic V(Ljava/lang/String;)V
    .locals 1

    const-string v0, ";BD:100,0;"

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 2
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->Z(Ljava/lang/String;)V

    return-void
.end method

.method public final W(Ljava/lang/String;)V
    .locals 14

    .line 1
    new-instance v12, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v12}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->m:I

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    .line 3
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->I(Ljava/lang/String;)Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    move-result-object v13

    const-string v0, "material"

    .line 4
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "custom:"

    if-eqz v0, :cond_0

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/CutSettings;->getId()Ljava/lang/String;

    move-result-object v7

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {v0}, Lc/b/a/a/m/d;->c0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {v0}, Lc/b/a/a/m/d;->d0(Lcn/upus/app/upprinting/data/bean/CutSettings;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v9

    .line 8
    invoke-static {v1}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->E:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->F:Ljava/lang/String;

    const-string v0, "on"

    const-string v1, "-10"

    const-string v2, ""

    const-string v10, "0"

    const-string v11, "0"

    move-object v6, p1

    invoke-static/range {v0 .. v13}, Lc/b/a/a/h/c/e;->h(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)V

    goto :goto_0

    .line 9
    :cond_0
    invoke-static {v1}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->E:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->F:Ljava/lang/String;

    const-string v0, "on"

    const-string v1, "-10"

    const-string v2, ""

    const-string v7, "0"

    move-object v6, p1

    move-object v8, v12

    move-object v9, v13

    invoke-static/range {v0 .. v9}, Lc/b/a/a/h/c/e;->g(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)V

    :goto_0
    return-void
.end method

.method public final X()V
    .locals 3

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    const v0, 0x7f1100da

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 5
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 6
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v1, 0x0

    const-string v2, "ID_abnormal"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    const v0, 0x7f1100cf

    .line 7
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 10
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 11
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    goto :goto_1

    .line 12
    :cond_3
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    .line 13
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    new-instance v1, Lc/b/a/a/l/b/w;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/w;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    .line 14
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->b:Lcn/upus/app/upprinting/ui/dialog/InputDialog$a;

    .line 15
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f110266

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 16
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->c:Ljava/lang/String;

    .line 17
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x1

    .line 18
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->d:Ljava/lang/String;

    .line 19
    iput v2, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->e:I

    .line 20
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "input"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public final Y()V
    .locals 4

    .line 1
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_0

    const v0, 0x7f1100da

    .line 2
    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 5
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 6
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v1, 0x0

    const-string v2, "ID_abnormal"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_1

    const v0, 0x7f1100cf

    .line 7
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 8
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 9
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_1
    const-string v0, ";BD:100,10,5;BD:100,3;"

    .line 10
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    invoke-virtual {v0}, Landroidx/databinding/ViewDataBinding;->getRoot()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/j4;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/j4;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    const-wide/16 v2, 0x32

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public final Z(Ljava/lang/String;)V
    .locals 10

    .line 1
    new-instance v9, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v9}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    .line 2
    new-instance v0, Lc/b/a/a/l/b/v;

    invoke-direct {v0, p0}, Lc/b/a/a/l/b/v;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v9, p0, v0}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 3
    iget-object v3, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->E:Ljava/lang/String;

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->F:Ljava/lang/String;

    iget v6, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->m:I

    const-string v0, "on"

    const-string v1, "-10"

    const-string v2, ""

    const-string v7, "Y"

    const-string v8, "0"

    move-object v5, p1

    invoke-static/range {v0 .. v9}, Lc/b/a/a/h/c/e;->L(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void
.end method

.method public final a0(Landroid/widget/CheckBox;Z)V
    .locals 3

    if-eqz p1, :cond_1

    .line 1
    instance-of v0, p1, Landroid/widget/CheckBox;

    if-eqz v0, :cond_1

    if-eqz p2, :cond_1

    const/4 p2, 0x0

    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge v0, v1, :cond_1

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_0

    .line 4
    instance-of v2, v1, Landroid/widget/CheckBox;

    if-eqz v2, :cond_0

    if-eq v1, p1, :cond_0

    .line 5
    invoke-virtual {v1, p2}, Landroid/widget/CheckBox;->setChecked(Z)V

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method public final b0()V
    .locals 7

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 2
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    .line 3
    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->q:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    .line 4
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/lifecycle/LiveData;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    .line 5
    iget-wide v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    const-wide/16 v3, 0x1

    sub-long/2addr v1, v3

    iput-wide v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    .line 6
    iget-wide v5, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->o:J

    add-long/2addr v5, v3

    iput-wide v5, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->o:J

    .line 7
    const-wide v1, 0x1869f
    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setBalaqty(J)V

    .line 8
    iget-wide v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->o:J

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setUseqty(J)V

    .line 9
    iget-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    .line 10
    iget-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->o:J

    .line 11
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 12
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v5

    if-lez v5, :cond_0

    .line 13
    iget-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v2

    int-to-long v2, v2

    add-long/2addr v0, v2

    .line 14
    iget-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->o:J

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    int-to-long v4, v4

    sub-long/2addr v2, v4

    .line 15
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    .line 16
    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 17
    iget-object v3, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "USEQTY"

    invoke-virtual {v3, v4, v2}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 18
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 19
    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 20
    iget-object v1, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "BALAQTY"

    invoke-virtual {v1, v2, v0}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    return-void
.end method

.method public final c0()V
    .locals 7

    .line 1
    :try_start_0
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->t:F

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->u:F

    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->v:F

    invoke-virtual {p0, v0, v1, v2}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->F(FFF)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    .line 2
    iget-boolean v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->k:Z

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->s:I

    const/4 v5, -0x1

    if-le v2, v5, :cond_1

    .line 3
    sget-object v1, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->s:I

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    const-string v5, "lastMaterialSize"

    .line 5
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2, v5, v1}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    const-string v2, "\\*"

    .line 6
    invoke-virtual {v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    .line 7
    array-length v5, v1

    if-eq v2, v5, :cond_0

    return-void

    .line 8
    :cond_0
    aget-object v2, v1, v4

    invoke-static {v2}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    float-to-int v2, v2

    .line 9
    aget-object v1, v1, v3

    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v1

    float-to-int v1, v1

    .line 10
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "BD:33,"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ","

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ";"

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 11
    :cond_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    new-array v1, v4, [Ljava/lang/Object;

    .line 12
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5207\u5272\uff1a"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->v([Ljava/lang/Object;)V

    .line 13
    sput-boolean v4, Lcn/upus/app/upprinting/MApp;->D:Z

    const-string v1, "0"

    .line 14
    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2

    .line 15
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 16
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    const v2, 0x7f1101ae

    invoke-virtual {p0, v2}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 17
    sput-boolean v4, Lc/b/a/a/k/d;->j:Z

    .line 18
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-static {v1, v0}, Lc/b/a/a/m/d;->K(Lcn/upus/app/upprinting/data/bean/CutSettings;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-array v1, v4, [Ljava/lang/Object;

    .line 19
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5f53\u524d\u7684\u5207\u5272\u6307\u4ee4\uff1a"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 20
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    .line 21
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d([B)V

    .line 22
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C:Z

    if-eqz v0, :cond_3

    .line 23
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->b0()V

    .line 24
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->r:I

    add-int/2addr v0, v4

    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->r:I

    .line 25
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->r:I

    .line 26
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "N_cutNumber2"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    const-string v0, "Y"

    .line 27
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->W(Ljava/lang/String;)V

    goto :goto_0

    :cond_2
    const-string v1, "1"

    .line 28
    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3

    .line 29
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->d0(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 30
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_3
    :goto_0
    return-void
.end method

.method public final d0(Ljava/lang/String;)V
    .locals 3

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 3
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 4
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/fragment/app/DialogFragment;->setCancelable(Z)V

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v2, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity$c;

    invoke-direct {v2, p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity$c;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;Ljava/lang/String;)V

    .line 6
    iput-object v2, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 7
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    .line 8
    iput v1, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->g:I

    .line 9
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f11009d

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 10
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->f:Ljava/lang/String;

    .line 11
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f110065

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 12
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 13
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "customdialog"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public final e0(Z)V
    .locals 3

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "N_cutNumber2"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 3
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->r:I

    .line 4
    iget-boolean v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->p:Z

    if-eqz v1, :cond_2

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->q:I

    if-lt v0, v1, :cond_2

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 6
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 7
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 8
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity$b;

    invoke-direct {v1, p0, p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity$b;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;Z)V

    .line 9
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 10
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    const v0, 0x7f110054

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 11
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->e:Ljava/lang/String;

    .line 12
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->r:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v1, 0x7f11007c

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 13
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 14
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "customdialog"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    goto :goto_2

    :cond_2
    if-eqz p1, :cond_3

    .line 15
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->Y()V

    goto :goto_2

    .line 16
    :cond_3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->f0()V

    :goto_2
    return-void
.end method

.method public final f0()V
    .locals 12

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "cutNet"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    .line 3
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v0

    if-nez v0, :cond_0

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    const v1, 0x7f1100ab

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 6
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 7
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "offCutMax"

    invoke-virtual {v0, v3, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    const v3, 0x7f1100ce

    if-lez v0, :cond_1

    .line 8
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_1

    .line 9
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    if-lt v4, v0, :cond_1

    .line 10
    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 13
    :cond_1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 14
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "ID_abnormal"

    invoke-virtual {v0, v4, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_2

    const v0, 0x7f1100cf

    .line 15
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 16
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 17
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 18
    :cond_2
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->m:I

    if-ne v0, v1, :cond_3

    .line 19
    iget-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    const-wide/16 v4, 0x1

    cmp-long v0, v2, v4

    if-gez v0, :cond_5

    const v0, 0x7f1100cd

    .line 20
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 21
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 22
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 23
    :cond_3
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-wide/16 v4, 0x0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 24
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    const-string v2, "netCurrentTime"

    invoke-virtual {v0, v2, v6, v7}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v6

    .line 25
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 26
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    const-string v2, "cutCurrentTime"

    invoke-virtual {v0, v2, v8, v9}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v8

    .line 27
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    .line 28
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const-string v2, "cutEndTime"

    invoke-virtual {v0, v2, v4, v5}, Lcom/tencent/mmkv/MMKV;->c(Ljava/lang/String;J)J

    move-result-wide v4

    sub-long v6, v8, v6

    const-wide/32 v10, 0x5265c00

    cmp-long v0, v6, v10

    if-lez v0, :cond_4

    .line 29
    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 30
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 31
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v3}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_4
    cmp-long v0, v4, v8

    if-gez v0, :cond_5

    const v0, 0x7f1100d0

    .line 32
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 33
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 34
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    .line 35
    :cond_5
    invoke-virtual {p0, v1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->g0(Z)V

    return-void
.end method

.method public g()I
    .locals 1

    const v0, 0x7f0c0079

    return v0
.end method

.method public final g0(Z)V
    .locals 5

    .line 1
    iput-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->C:Z

    .line 2
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->g:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {p1}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object p1

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->f:Lcn/upus/app/upprinting/view/TextChangedEditText;

    invoke-static {v0}, Ld/a/a/a/a;->S(Lcn/upus/app/upprinting/view/TextChangedEditText;)Ljava/lang/String;

    move-result-object v0

    .line 6
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const v2, 0x7f1100cc

    if-nez v1, :cond_c

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    goto/16 :goto_5

    .line 7
    :cond_0
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    .line 8
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    invoke-virtual {v0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "."

    .line 9
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_b

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    goto/16 :goto_4

    .line 10
    :cond_1
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1

    iput p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->t:F

    .line 11
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1

    iput p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->u:F

    .line 12
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->t:F

    invoke-static {v0, p1}, Ljava/lang/Math;->min(FF)F

    move-result p1

    const/high16 v0, 0x40000000    # 2.0f

    div-float/2addr p1, v0

    .line 13
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 14
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->k:Landroidx/appcompat/widget/AppCompatSpinner;

    invoke-virtual {v0}, Landroid/widget/Spinner;->getSelectedItemPosition()I

    move-result v0

    .line 15
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->I:Landroid/widget/ArrayAdapter;

    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->getItem(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 16
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_2

    .line 17
    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0

    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->v:F

    .line 18
    :cond_2
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->v:F

    cmpg-float p1, p1, v0

    if-gez p1, :cond_3

    const p1, 0x7f1100ca

    .line 19
    invoke-virtual {p0, p1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    return-void

    .line 20
    :cond_3
    iget p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->t:F

    const/high16 v0, 0x40800000    # 4.0f

    cmpg-float v1, p1, v0

    if-ltz v1, :cond_a

    iget v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->u:F

    cmpg-float v2, v1, v0

    if-gez v2, :cond_4

    goto :goto_3

    .line 21
    :cond_4
    iget v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->l:F

    sub-float/2addr v2, v0

    cmpl-float p1, p1, v2

    if-gtz p1, :cond_9

    const/high16 p1, 0x447a0000    # 1000.0f

    cmpl-float p1, v1, p1

    if-lez p1, :cond_5

    goto :goto_2

    .line 22
    :cond_5
    iget-boolean p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->k:Z

    const/4 v0, 0x0

    if-eqz p1, :cond_8

    const/4 p1, 0x0

    .line 23
    :goto_0
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    if-ge p1, v1, :cond_7

    .line 24
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/widget/CheckBox;

    if-eqz v1, :cond_6

    .line 25
    invoke-virtual {v1}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v1

    if-eqz v1, :cond_6

    goto :goto_1

    :cond_6
    add-int/lit8 p1, p1, 0x1

    goto :goto_0

    :cond_7
    const/4 p1, -0x1

    .line 26
    :goto_1
    iput p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->s:I

    if-gez p1, :cond_8

    const p1, 0x7f1100d1

    .line 27
    invoke-virtual {p0, p1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 28
    :cond_8
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 29
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    const v1, 0x7f1100d9

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 30
    sput-boolean v0, Lc/b/a/a/k/d;->j:Z

    .line 31
    invoke-static {}, Lc/b/a/a/k/a;->t()[B

    move-result-object p1

    .line 32
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    return-void

    :cond_9
    :goto_2
    const p1, 0x7f1100e7

    .line 33
    invoke-virtual {p0, p1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    return-void

    :cond_a
    :goto_3
    const p1, 0x7f1100cb

    .line 34
    invoke-virtual {p0, p1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    return-void

    .line 35
    :cond_b
    :goto_4
    invoke-virtual {p0, v2}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    return-void

    .line 36
    :cond_c
    :goto_5
    invoke-virtual {p0, v2}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final h0(Ljava/lang/String;)V
    .locals 4

    const-string v0, ";BD:100,10,5;BD:100,4;"

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 3
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    invoke-virtual {v0}, Landroidx/databinding/ViewDataBinding;->getRoot()Landroid/view/View;

    move-result-object v0

    new-instance v1, Lc/b/a/a/l/b/u;

    invoke-direct {v1, p0, p1}, Lc/b/a/a/l/b/u;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;Ljava/lang/String;)V

    const-wide/16 v2, 0x32

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public l()V
    .locals 9

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "cutSettings"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/data/bean/CutSettings;

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    .line 2
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "cameraCutout"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->M:Ljava/lang/String;

    .line 3
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "bladePosition"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->N:Ljava/lang/String;

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v1, "0"

    const-string v2, "1"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v2, "2"

    const-string v3, "7"

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v4, "3"

    invoke-virtual {v0, v4, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v4, "4"

    const-string v5, "5"

    invoke-virtual {v0, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 9
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v6, "6"

    invoke-virtual {v0, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 10
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    invoke-virtual {v0, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v4, "8"

    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    invoke-virtual {v0, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K:Ljava/util/HashMap;

    const-string v2, "9"

    invoke-virtual {v0, v2, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "custom:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v2, Lcn/upus/app/upprinting/MApp;->F:Ljava/text/SimpleDateFormat;

    invoke-static {v2}, Lcom/blankj/utilcode/util/TimeUtils;->getNowString(Ljava/text/DateFormat;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "AppVersion:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 15
    invoke-static {}, Lcom/blankj/utilcode/util/AppUtils;->getAppVersionName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "BinVersion:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 17
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "SVER"

    const-string v4, ""

    invoke-virtual {v2, v3, v4}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 18
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->E:Ljava/lang/String;

    .line 19
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "-"

    invoke-virtual {v0, v2, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->F:Ljava/lang/String;

    .line 20
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 21
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "cutType"

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 22
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->m:I

    const-string v0, "cutBeforeCheck"

    .line 23
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D:Ljava/lang/String;

    .line 24
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 25
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "SW_cutNumber"

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 26
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->p:Z

    .line 27
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const/16 v2, 0x64

    .line 28
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "N_standard"

    invoke-virtual {v0, v6, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 29
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->q:I

    .line 30
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 31
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "IS_material"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 32
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->k:Z

    .line 33
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 34
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "MaxWidth"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    int-to-float v0, v0

    .line 35
    iput v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->l:F

    .line 36
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 37
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "START_ET_LOCK"

    invoke-virtual {v0, v2, v5}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    .line 38
    iput-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->B:Z

    .line 39
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 40
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "cutCountShow"

    invoke-virtual {v0, v2, v4}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 41
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 42
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 43
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->b(Ljava/lang/Boolean;)V

    goto :goto_0

    .line 44
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 45
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->b(Ljava/lang/Boolean;)V

    .line 46
    :goto_0
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_1

    const v0, 0x7f1100da

    .line 47
    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    .line 48
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 49
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 50
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 51
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->g:Lcn/upus/app/upprinting/view/TextChangedEditText;

    new-instance v1, Lc/b/a/a/l/b/e4;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/e4;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 52
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 53
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->f:Lcn/upus/app/upprinting/view/TextChangedEditText;

    new-instance v1, Lc/b/a/a/l/b/f4;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/f4;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 54
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 55
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->k:Landroidx/appcompat/widget/AppCompatSpinner;

    new-instance v1, Lc/b/a/a/l/b/g4;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/g4;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    .line 56
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 57
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->c:Landroid/widget/ImageButton;

    new-instance v1, Lc/b/a/a/l/b/q;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/q;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 58
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 59
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/h4;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/h4;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 60
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 61
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->a:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/n;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/n;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 62
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 63
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->a:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/r;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 64
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 65
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->d:Landroid/widget/Button;

    new-instance v1, Lc/b/a/a/l/b/i4;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/i4;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 66
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->k:Z

    const/16 v1, 0x8

    if-eqz v0, :cond_2

    .line 67
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 68
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_1

    .line 69
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 70
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 71
    :goto_1
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->B:Z

    if-eqz v0, :cond_3

    .line 72
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 73
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->c:Landroid/widget/ImageButton;

    invoke-virtual {v0, v5}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 74
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 75
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_2

    .line 76
    :cond_3
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 77
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->c:Landroid/widget/ImageButton;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 78
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 79
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 80
    :goto_2
    iget v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->m:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_4

    .line 81
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 82
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setVisibility(I)V

    .line 83
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 84
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->c:Landroid/widget/ImageButton;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    .line 85
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 86
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->a:Landroidx/appcompat/widget/AppCompatButton;

    invoke-virtual {v0, v5}, Landroid/widget/Button;->setVisibility(I)V

    .line 87
    :cond_4
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x0

    :goto_3
    const/high16 v6, 0x42340000    # 45.0f

    const/high16 v7, 0x3f800000    # 1.0f

    cmpg-float v6, v1, v6

    if-gtz v6, :cond_5

    .line 88
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-float/2addr v1, v7

    goto :goto_3

    .line 89
    :cond_5
    new-instance v1, Landroid/widget/ArrayAdapter;

    const v4, 0x1090008

    invoke-direct {v1, p0, v4, v0}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->I:Landroid/widget/ArrayAdapter;

    const v0, 0x1090009

    .line 90
    invoke-virtual {v1, v0}, Landroid/widget/ArrayAdapter;->setDropDownViewResource(I)V

    .line 91
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 92
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->k:Landroidx/appcompat/widget/AppCompatSpinner;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->I:Landroid/widget/ArrayAdapter;

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/AppCompatSpinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    .line 93
    iget-boolean v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->k:Z

    if-eqz v0, :cond_a

    .line 94
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-nez v0, :cond_9

    const/4 v0, 0x0

    .line 95
    :goto_4
    sget-object v1, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_9

    .line 96
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 97
    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 98
    invoke-virtual {v1, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 99
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v8, -0x2

    invoke-direct {v4, v6, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 100
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v6

    if-nez v6, :cond_6

    .line 101
    invoke-virtual {v4, v5, v5, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_5

    :cond_6
    const/16 v6, 0xc

    .line 102
    invoke-virtual {v4, v5, v6, v5, v5}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 103
    :goto_5
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 104
    sget-object v4, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v4, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 105
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 106
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D(Ljava/lang/String;)Landroid/widget/CheckBox;

    move-result-object v4

    .line 107
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 108
    new-instance v6, Lc/b/a/a/l/b/t;

    invoke-direct {v6, p0}, Lc/b/a/a/l/b/t;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v4, v6}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 109
    iget-object v6, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v0, 0x1

    .line 110
    sget-object v6, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v4, v6, :cond_7

    .line 111
    sget-object v6, Lcn/upus/app/upprinting/MApp;->y:Ljava/util/List;

    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .line 112
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 113
    invoke-virtual {p0, v4}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D(Ljava/lang/String;)Landroid/widget/CheckBox;

    move-result-object v4

    .line 114
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 115
    iget-object v6, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J:Ljava/util/ArrayList;

    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 116
    new-instance v6, Lc/b/a/a/l/b/s;

    invoke-direct {v6, p0}, Lc/b/a/a/l/b/s;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    invoke-virtual {v4, v6}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    goto :goto_7

    .line 117
    :cond_7
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v5, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 118
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v6

    const/4 v8, 0x5

    if-nez v6, :cond_8

    .line 119
    invoke-virtual {v4, v8, v2, v8, v2}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    goto :goto_6

    .line 120
    :cond_8
    invoke-virtual {v4, v8, v8, v8, v8}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 121
    :goto_6
    iput v7, v4, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    .line 122
    new-instance v6, Landroid/widget/Space;

    invoke-direct {v6, p0}, Landroid/widget/Space;-><init>(Landroid/content/Context;)V

    .line 123
    invoke-virtual {v6, v4}, Landroid/widget/Space;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 124
    invoke-virtual {v1, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 125
    :goto_7
    iget-object v4, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 126
    check-cast v4, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v4, v4, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    add-int/lit8 v0, v0, 0x2

    goto/16 :goto_4

    .line 127
    :cond_9
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->J()V

    .line 128
    :cond_a
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 129
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->g:Lcn/upus/app/upprinting/view/TextChangedEditText;

    new-array v1, v3, [Landroid/text/InputFilter;

    new-instance v2, Lc/b/a/a/m/c;

    invoke-direct {v2}, Lc/b/a/a/m/c;-><init>()V

    aput-object v2, v1, v5

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    .line 130
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 131
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->f:Lcn/upus/app/upprinting/view/TextChangedEditText;

    new-array v1, v3, [Landroid/text/InputFilter;

    new-instance v2, Lc/b/a/a/m/c;

    invoke-direct {v2}, Lc/b/a/a/m/c;-><init>()V

    aput-object v2, v1, v5

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setFilters([Landroid/text/InputFilter;)V

    return-void
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .locals 1
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .line 1
    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/FragmentActivity;->onActivityResult(IILandroid/content/Intent;)V

    const/4 p3, 0x2

    if-ne p1, p3, :cond_0

    const/4 v0, 0x1

    if-ne p2, v0, :cond_0

    new-array p1, v0, [Ljava/lang/Object;

    const/4 p2, 0x0

    const-string p3, "---------- \u5207\u819c\u5df2\u7ecf\u53d6\u6d88\uff01----------"

    aput-object p3, p1, p2

    .line 2
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    if-ne p1, p3, :cond_1

    if-ne p2, p3, :cond_1

    .line 3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->c0()V

    :cond_1
    :goto_0
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    const-string v0, "page_onCreate"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onCreate"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onDestroy()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->O:Landroid/graphics/Bitmap;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    .line 2
    invoke-virtual {v0}, Landroid/graphics/Bitmap;->recycle()V

    .line 3
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->O:Landroid/graphics/Bitmap;

    .line 4
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    if-eqz v0, :cond_1

    .line 5
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->P:Landroid/graphics/Canvas;

    .line 6
    :cond_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    .line 8
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->G:Lc/b/a/a/l/d/g1;

    if-eqz v0, :cond_3

    .line 9
    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 10
    :cond_3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_4

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_4

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->H:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 12
    :cond_4
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onDestroy()V

    return-void
.end method

.method public onEvent(Lcn/upus/app/upprinting/data/bean/event/MessageEvent;)V
    .locals 9

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object v0

    const-string v1, "home"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, ""

    const-string v2, "1"

    const/4 v3, 0x0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object v0

    const-string v4, "back"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 2
    :cond_0
    sget-boolean v0, Lc/b/a/a/k/d;->j:Z

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    new-array v4, v0, [Ljava/lang/Object;

    const-string v5, "\u5f53\u524d\u9700\u8981\u786e\u8ba4\u653e\u819c\u624d\u80fd\u5207\u5272\uff0c\u5728\u5207\u5272\u8fc7\u7a0b\u4e2d\u56e0\u4e3a\u5f02\u5e38\u63a8\u51fa\u4e86\u5207\u5272\u9875\u9762\uff0c\u56e0\u6b64\u751f\u6210\u79bb\u7ebf\u5207\u5272\u6570\u636e\u5e76\u4fdd\u5b58"

    aput-object v5, v4, v3

    .line 3
    invoke-static {v4}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    .line 5
    iget-object v4, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "BALAQTY"

    invoke-virtual {v4, v5, v1}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 6
    invoke-static {v4}, Lc/b/a/a/k/a;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    new-array v0, v0, [Ljava/lang/Object;

    const-string v6, "\u5f53\u524d\u7684\u5269\u4f59\u5207\u5272\u6570\uff1a"

    .line 7
    invoke-static {v6}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-wide v7, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v7, "\u3001\u5b58\u50a8\u7684\u5269\u4f59\u5207\u5272\u6570\uff1a"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v0, v3

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v0, "Y/N"

    .line 8
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->I(Ljava/lang/String;)Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;

    move-result-object v0

    .line 9
    invoke-static {v0}, Lc/a/a/j/a;->o(Lcn/upus/app/upprinting/data/bean/dbBean/AppendBean;)Z

    .line 10
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    .line 11
    invoke-static {}, Lc/b/a/a/k/a;->x()V

    .line 12
    :cond_1
    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onEvent(Lcn/upus/app/upprinting/data/bean/event/MessageEvent;)V

    .line 13
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object v0

    const-string v4, "cut_finish"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    .line 14
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 15
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    const v4, 0x7f1101d8

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 16
    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 17
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->D:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 18
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "part_no"

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 19
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 20
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_2

    goto :goto_0

    .line 21
    :cond_2
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->dismiss()V

    goto :goto_1

    .line 22
    :cond_3
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    .line 23
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {v0, v3}, Landroidx/fragment/app/DialogFragment;->setCancelable(Z)V

    .line 24
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    new-instance v1, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity$a;

    invoke-direct {v1, p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity$a;-><init>(Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;)V

    .line 25
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->b:Lcn/upus/app/upprinting/ui/dialog/CustomDialog$a;

    .line 26
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    .line 27
    iput v3, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->g:I

    .line 28
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f11007d

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 29
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->d:Ljava/lang/String;

    .line 30
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f11008d

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 31
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->f:Ljava/lang/String;

    .line 32
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f110073

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 33
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;->e:Ljava/lang/String;

    .line 34
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->f:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/CustomDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "customdialog"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    .line 35
    :cond_4
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/MessageEvent;->getEvent()Ljava/lang/String;

    move-result-object p1

    const-string v0, "recharge_finish"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    .line 36
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getBalaqty()J

    move-result-wide v0

    iput-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    .line 37
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getUseqty()J

    move-result-wide v0

    iput-wide v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->o:J

    :cond_5
    return-void
.end method

.method public onPause()V
    .locals 2

    const-string v0, "onPause"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onPause()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onRestart()V
    .locals 2

    const-string v0, "page_onReStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onRestart()V

    return-void
.end method

.method public onResume()V
    .locals 6

    const-string v0, "onResume"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 1
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onResume()V

    .line 2
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getBalaqty()J

    move-result-wide v2

    iput-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    .line 3
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->getUseqty()J

    move-result-wide v2

    iput-wide v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->o:J

    new-array v2, v1, [Ljava/lang/Object;

    const-string v3, "\u5145\u503c\u5207\u5272\u6570\u5df2\u6210\u529f\uff0c\u5f53\u524d\u7684\u5207\u5272\u6570\uff1a"

    .line 4
    invoke-static {v3}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-wide v4, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->n:J

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    aput-object v3, v2, v4

    invoke-static {v2}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v2, "page_onResume"

    .line 5
    invoke-static {p0, v2, v4}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onSerialPortEvent(Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;)V
    .locals 7
    .annotation runtime Li/b/a/k;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;->getData()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "\u63a5\u6536\u5230\u7684\u81ea\u5b9a\u4e49\u5207\u5272\u4e32\u53e3\u6570\u636e\uff1a"

    .line 2
    invoke-static {v2, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v1, "RCMD=10,"

    .line 3
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_4

    const-string v1, "RCMD=10,1;"

    .line 4
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 5
    sput-boolean v0, Lc/b/a/a/k/d;->j:Z

    .line 6
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    const v1, 0x7f1100da

    invoke-virtual {p0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u5f53\u524d\u8bbe\u5907\u5de5\u4f5c\u72b6\u6001\uff1a\u8bbe\u5907\u5de5\u4f5c/\u91cd\u7f6e"

    aput-object v0, p1, v3

    .line 8
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto/16 :goto_1

    :cond_0
    const-string v1, "RCMD=10,0;"

    .line 9
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_6

    const-string v1, ";"

    .line 10
    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 11
    array-length v1, p1

    const-string v2, "\u83b7\u53d6\u673a\u5668\u72b6\u6001\uff1a\u6570\u636e\u9519\u8bef"

    const v4, 0x7f1100d4

    const v5, 0x7f1100d9

    const/4 v6, 0x2

    if-eq v1, v6, :cond_1

    .line 12
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 13
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    aput-object v2, p1, v3

    .line 14
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    return-void

    .line 15
    :cond_1
    aget-object p1, p1, v0

    const-string v1, ","

    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    .line 16
    array-length v1, p1

    if-lt v1, v6, :cond_3

    aget-object v1, p1, v0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_2

    goto :goto_0

    .line 17
    :cond_2
    aget-object p1, p1, v0

    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/cut/cutjni/JniUtils;->getHandshake(J)[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    new-array p1, v0, [Ljava/lang/Object;

    const-string v0, "\u4e00\u6b21\u53d1\u5b8c\u5207\u5272\u6570\u636e"

    aput-object v0, p1, v3

    .line 18
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    goto :goto_1

    .line 19
    :cond_3
    :goto_0
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 20
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivityCustomCutBinding;->m:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array p1, v0, [Ljava/lang/Object;

    aput-object v2, p1, v3

    .line 21
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    return-void

    :cond_4
    const-string v1, "RCMD=12,"

    .line 22
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    const-string v1, "RCMD=12,0;"

    .line 23
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_6

    new-array p1, v0, [Ljava/lang/Object;

    const-string v1, "\u63e1\u624b\u6210\u529f\uff0c\u5f00\u59cb\u5207\u5272"

    aput-object v1, p1, v3

    .line 24
    invoke-static {p1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string p1, "material"

    .line 25
    invoke-static {p1}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "1"

    .line 26
    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5

    .line 27
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/CutSettings;->getFilmSize()Ljava/lang/String;

    move-result-object p1

    new-array v0, v0, [Ljava/lang/Object;

    const-string v1, "\u83b7\u53d6\u5207\u5272\u5c3a\u5bf8\uff1a"

    .line 28
    invoke-static {v1, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    aput-object v1, v0, v3

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 29
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->L:Lcn/upus/app/upprinting/data/bean/CutSettings;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->M:Ljava/lang/String;

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->N:Ljava/lang/String;

    invoke-static {p0, v0, p1, v1, v2}, Lcn/upus/app/upprinting/ui/activity/setting/SettingSureActivity;->p(Landroid/app/Activity;Lcn/upus/app/upprinting/data/bean/CutSettings;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    .line 30
    :cond_5
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->c0()V

    :cond_6
    :goto_1
    return-void
.end method

.method public onStart()V
    .locals 2

    const-string v0, "page_onStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onStart"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStart()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onStop()V
    .locals 2

    const-string v0, "page_onStop"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStop()V

    return-void
.end method
