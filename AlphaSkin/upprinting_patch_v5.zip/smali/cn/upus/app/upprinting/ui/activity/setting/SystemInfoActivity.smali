.class public Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;
.super Lcn/upus/app/upprinting/base/BaseDataBindingActivity;
.source "SystemInfoActivity.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcn/upus/app/upprinting/base/BaseDataBindingActivity<",
        "Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;",
        ">;"
    }
.end annotation


# instance fields
.field public k:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/InputDialog;",
            ">;"
        }
    .end annotation
.end field

.field public l:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;",
            ">;"
        }
    .end annotation
.end field

.field public m:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/AppUpdateBean;",
            ">;"
        }
    .end annotation
.end field

.field public n:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field public o:Lcn/upus/app/upprinting/data/bean/AppUpdateBean;

.field public p:Ljava/lang/String;

.field public q:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;-><init>()V

    return-void
.end method

.method public static r(Landroid/content/Context;)V
    .locals 1

    .line 1
    const-class v0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;

    invoke-static {p0, v0}, Ld/a/a/a/a;->H(Landroid/content/Context;Ljava/lang/Class;)V

    return-void
.end method


# virtual methods
.method public g()I
    .locals 1

    const v0, 0x7f0c009d

    return v0
.end method

.method public l()V
    .locals 8

    const-string v0, "BD:10,2;"

    .line 1
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    move-result-object v0

    .line 2
    invoke-virtual {p0, v0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    .line 3
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->m:Landroidx/lifecycle/MutableLiveData;

    .line 4
    new-instance v1, Lc/b/a/a/l/b/r7/n1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/n1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 5
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->n:Landroidx/lifecycle/MutableLiveData;

    .line 6
    new-instance v1, Lc/b/a/a/l/b/r7/o1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/o1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->b:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/r7/m1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/m1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 9
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->a:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/r7/k1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/k1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->c:Landroidx/appcompat/widget/AppCompatButton;

    new-instance v1, Lc/b/a/a/l/b/r7/l1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/l1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 13
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 14
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 15
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->q:Landroid/widget/TextView;

    .line 16
    iget-object v2, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, ""

    const-string v4, "PGHEAD"

    invoke-virtual {v2, v4, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 17
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 18
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "DEVNO"

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 19
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 20
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->d:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 21
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "MODE"

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 22
    iget-object v2, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "ID_AGENT"

    invoke-virtual {v2, v4, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v4, "1537"

    .line 23
    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    const-string v2, "CUTSF_A"

    const-string v4, "HMA18SF-A"

    .line 24
    invoke-virtual {v1, v2, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "CUT_A"

    const-string v4, "HMA18-A"

    invoke-virtual {v1, v2, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    .line 25
    :cond_0
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 26
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->e:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 27
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 28
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->f:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/blankj/utilcode/util/AppUtils;->getAppVersionName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "("

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f11004a

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, ")"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 30
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 31
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "SVER"

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 32
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 33
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->g:Landroid/widget/TextView;

    invoke-static {v1, v4}, Ld/a/a/a/a;->C(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-object v6, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 34
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->z()V

    .line 35
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "HVER"

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 36
    iput-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->q:Ljava/lang/String;

    .line 37
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 38
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->h:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 39
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->y()V

    .line 40
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "PID"

    invoke-virtual {v1, v2, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 41
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 42
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->i:Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 43
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v2, 0x0

    const-string v6, "NET_IS_OK"

    invoke-virtual {v1, v6, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_1

    .line 44
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v1

    if-eqz v1, :cond_1

    .line 45
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 46
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    const v6, 0x7f1102b4

    invoke-virtual {p0, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 47
    :cond_1
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 48
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    const v6, 0x7f1102b5

    invoke-virtual {p0, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 49
    :goto_0
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v1

    if-eqz v1, :cond_2

    .line 50
    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v6

    if-lez v6, :cond_2

    .line 51
    iget-object v6, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 52
    check-cast v6, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v6, v6, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    invoke-static {v4}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    goto :goto_1

    .line 53
    :cond_2
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 54
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    const-string v4, "(0)"

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    .line 55
    :goto_1
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const/4 v4, 0x1

    const-string v5, "ID_abnormal"

    invoke-virtual {v1, v5, v4}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_3

    .line 56
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 57
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->l:Landroid/widget/TextView;

    const v5, 0x7f1102b7

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    .line 58
    :cond_3
    iget-object v1, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "ID_REGISTERED"

    invoke-virtual {v1, v5, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 59
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 60
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->l:Landroid/widget/TextView;

    const v5, 0x7f1102b8

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_2

    .line 61
    :cond_4
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 62
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->l:Landroid/widget/TextView;

    const v5, 0x7f1102b9

    invoke-virtual {p0, v5}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_2
    new-array v1, v4, [Ljava/lang/Object;

    const-string v5, "\u6570\u636e\u7248\u672c\uff1a"

    .line 63
    invoke-static {v5}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 64
    iget-object v6, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v7, "data_version"

    invoke-virtual {v6, v7, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 65
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v1, v2

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 66
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 67
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->m:Landroid/widget/TextView;

    .line 68
    iget-object v5, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v5, v7, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 69
    invoke-virtual {v1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    new-array v1, v4, [Ljava/lang/Object;

    const-string v4, "\u6570\u636e\u65f6\u95f4\uff1a"

    .line 70
    invoke-static {v4}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 71
    iget-object v5, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "data_time"

    invoke-virtual {v5, v6, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 72
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v2

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 73
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 74
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v1, v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->n:Landroid/widget/TextView;

    .line 75
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0, v6, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 76
    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 2

    const-string v0, "page_onCreate"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onCreate"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onCreate(Landroid/os/Bundle;)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onDestroy()V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->l:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;->dismiss()V

    :cond_0
    return-void
.end method

.method public onPause()V
    .locals 2

    const-string v0, "onPause"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onPause()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onRestart()V
    .locals 2

    const-string v0, "page_onReStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onRestart()V

    return-void
.end method

.method public onResume()V
    .locals 2

    const-string v0, "onResume"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onResume()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "page_onResume"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onSerialPortEvent(Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;)V
    .locals 7
    .annotation runtime Li/b/a/k;
        threadMode = .enum Lorg/greenrobot/eventbus/ThreadMode;->MAIN:Lorg/greenrobot/eventbus/ThreadMode;
    .end annotation

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/event/SerialPortDataEvent;->getData()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "serialData:"

    .line 2
    invoke-static {v2, p1}, Ld/a/a/a/a;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v1, "ERR="

    .line 3
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    const-string v3, ";"

    const-string v4, ""

    if-eqz v2, :cond_0

    .line 4
    invoke-virtual {p1, v3, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v1, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->j:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, "BD:101,112;"

    .line 7
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    goto/16 :goto_3

    :cond_0
    const-string v1, "PGHEAD="

    .line 8
    invoke-virtual {p1, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_6

    const-string v1, "RBSVER="

    .line 9
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const-string v5, "BSVER="

    if-nez v2, :cond_1

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_8

    .line 10
    :cond_1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_5

    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_5

    .line 11
    :cond_2
    invoke-virtual {p1, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    .line 12
    :goto_0
    array-length v6, p1

    if-ge v2, v6, :cond_5

    .line 13
    aget-object v6, p1, v2

    invoke-virtual {v6, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_4

    aget-object v6, p1, v2

    invoke-virtual {v6, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_3

    goto :goto_1

    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 14
    :cond_4
    :goto_1
    aget-object p1, p1, v2

    invoke-virtual {p1, v1, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 15
    invoke-virtual {p1, v5, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 16
    invoke-virtual {p1, v3, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "V"

    .line 17
    invoke-virtual {p1, v1, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 18
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 19
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v2, "RBVER"

    invoke-virtual {v1, v2, p1}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    goto :goto_2

    :cond_5
    const/4 v0, 0x0

    :goto_2
    if-eqz v0, :cond_8

    .line 20
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->z()V

    goto :goto_3

    :cond_6
    const-string v0, "BLU="

    .line 21
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_7

    .line 22
    invoke-virtual {p1, v3, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1, v0, v4}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    .line 23
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 24
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->o:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const-string p1, ";RINFO;"

    .line 25
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    .line 26
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    goto :goto_3

    :cond_7
    const-string v0, "RCMD=100,20"

    .line 27
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_8

    .line 28
    invoke-static {p1}, Lc/b/a/a/k/a;->j(Ljava/lang/String;)Z

    .line 29
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->y()V

    :cond_8
    :goto_3
    return-void
.end method

.method public onStart()V
    .locals 2

    const-string v0, "page_onStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onStart"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStart()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onStop()V
    .locals 2

    const-string v0, "page_onStop"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStop()V

    return-void
.end method

.method public final p()V
    .locals 3

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->l:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;->dismiss()V

    goto :goto_1

    .line 3
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->l:Ljava/lang/ref/WeakReference;

    .line 4
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->p:Ljava/lang/String;

    iget-object v2, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->o:Lcn/upus/app/upprinting/data/bean/AppUpdateBean;

    .line 5
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;->c:Ljava/lang/String;

    .line 6
    iput-object v2, v0, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;->b:Lcn/upus/app/upprinting/data/bean/AppUpdateBean;

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->l:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/UpdateDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "update"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public final q()V
    .locals 2

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->a:Ljava/lang/String;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->m:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0, v1}, Lc/b/a/a/h/c/e;->b(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    return-void
.end method

.method public synthetic s(Lcn/upus/app/upprinting/data/bean/AppUpdateBean;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->o:Lcn/upus/app/upprinting/data/bean/AppUpdateBean;

    if-eqz p1, :cond_0

    .line 2
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->p()V

    :cond_0
    return-void
.end method

.method public t(Ljava/lang/Boolean;)V
    .locals 2

    .line 1
    invoke-static {}, Lc/b/a/a/m/j;->a()Lc/b/a/a/m/j;

    move-result-object v0

    invoke-virtual {v0}, Lc/b/a/a/m/j;->b()V

    .line 2
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 3
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 4
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    const v0, 0x7f1102b4

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 5
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f060078

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_0

    .line 7
    :cond_0
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    const v0, 0x7f1102b5

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 9
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f0600e4

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    .line 11
    :goto_0
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 12
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_1

    .line 13
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 14
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    const-string v1, "("

    invoke-static {v1}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ")"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    goto :goto_1

    .line 15
    :cond_1
    iget-object p1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 16
    check-cast p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object p1, p1, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->k:Landroid/widget/TextView;

    const-string v0, "(0)"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->append(Ljava/lang/CharSequence;)V

    :goto_1
    return-void
.end method

.method public u(Landroid/view/View;)V
    .locals 2

    .line 1
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->k:Ljava/lang/ref/WeakReference;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    if-nez p1, :cond_0

    goto :goto_0

    .line 2
    :cond_0
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->k:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    goto :goto_1

    .line 3
    :cond_1
    :goto_0
    new-instance p1, Ljava/lang/ref/WeakReference;

    new-instance v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-direct {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;-><init>()V

    invoke-direct {p1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->k:Ljava/lang/ref/WeakReference;

    .line 4
    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    new-instance v0, Lc/b/a/a/l/b/r7/j1;

    invoke-direct {v0, p0}, Lc/b/a/a/l/b/r7/j1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;)V

    .line 5
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->b:Lcn/upus/app/upprinting/ui/dialog/InputDialog$a;

    .line 6
    :goto_1
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->k:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "input"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    return-void
.end method

.method public v(Landroid/view/View;)V
    .locals 2

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    .line 2
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v0, "sessionId"

    const-string v1, ""

    invoke-virtual {p1, v0, v1}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 3
    sput-object v1, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    .line 4
    invoke-static {}, Lc/b/a/a/m/j;->a()Lc/b/a/a/m/j;

    move-result-object p1

    const/4 v0, 0x1

    invoke-virtual {p1, p0, v0}, Lc/b/a/a/m/j;->e(Landroid/content/Context;Z)V

    .line 5
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->n:Landroidx/lifecycle/MutableLiveData;

    invoke-static {p1}, Lc/b/a/a/h/c/e;->A(Landroidx/lifecycle/MutableLiveData;)V

    return-void
.end method

.method public w(Landroid/view/View;)V
    .locals 0

    const-string p1, ";BD:100,20,0;"

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    .line 2
    invoke-virtual {p0, p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b([B)V

    return-void
.end method

.method public synthetic x(Ljava/lang/String;)V
    .locals 1

    const-string v0, "2525"

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "2626"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    const-string v0, "1414"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const p1, 0x7f110131

    .line 2
    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    goto :goto_1

    .line 3
    :cond_1
    :goto_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->k:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 4
    iput-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->p:Ljava/lang/String;

    .line 5
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->o:Lcn/upus/app/upprinting/data/bean/AppUpdateBean;

    if-nez p1, :cond_2

    .line 6
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->q()V

    goto :goto_1

    .line 7
    :cond_2
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->p()V

    :goto_1
    return-void
.end method

.method public final y()V
    .locals 4

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "MaxWidth"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->q:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_0

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SystemInfoActivity;->q:Ljava/lang/String;

    const-string v3, "VF"

    invoke-virtual {v1, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    add-int/lit8 v0, v0, -0x4

    goto :goto_0

    :cond_0
    add-int/lit8 v0, v0, -0x2

    :goto_0
    if-gez v0, :cond_1

    goto :goto_1

    :cond_1
    move v2, v0

    .line 4
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->p:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " mm"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public final z()V
    .locals 3

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "RBVER"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 4
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 5
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->g:Landroid/widget/TextView;

    const/high16 v1, -0x1000000

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_0

    .line 6
    :cond_0
    :try_start_0
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const v1, 0x13465b6

    if-le v0, v1, :cond_1

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->h:Landroid/widget/TextView;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f0600f7

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 9
    sget-object v0, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    if-eqz v0, :cond_1

    sget-object v0, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getThemeColor()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 10
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 11
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySystemInfoBinding;->h:Landroid/widget/TextView;

    sget-object v1, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getThemeColor()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 12
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :cond_1
    :goto_0
    return-void
.end method
