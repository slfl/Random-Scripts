.class public Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;
.super Lcn/upus/app/upprinting/base/BaseDataBindingActivity;
.source "SettingActivity.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcn/upus/app/upprinting/base/BaseDataBindingActivity<",
        "Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;",
        ">;"
    }
.end annotation


# instance fields
.field public final k:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcn/upus/app/upprinting/data/bean/SetBean;",
            ">;"
        }
    .end annotation
.end field

.field public l:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;>;"
        }
    .end annotation
.end field

.field public m:Landroidx/lifecycle/MutableLiveData;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/lifecycle/MutableLiveData<",
            "Lcn/upus/app/upprinting/data/bean/AppUpdateBean;",
            ">;"
        }
    .end annotation
.end field

.field public n:[J

.field public o:Lcn/upus/app/upprinting/ui/adapter/SetItemAdapter;

.field public p:Lcn/upus/app/upprinting/data/bean/SetBean;

.field public q:Lc/b/a/a/l/d/p1;

.field public r:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcn/upus/app/upprinting/ui/dialog/InputDialog;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;-><init>()V

    .line 2
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    const/4 v0, 0x4

    new-array v0, v0, [J

    .line 3
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    .line 4
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 5
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-void
.end method

.method public static q(Landroid/content/Context;)V
    .locals 1

    .line 1
    const-class v0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;

    invoke-static {p0, v0}, Ld/a/a/a/a;->H(Landroid/content/Context;Ljava/lang/Class;)V

    return-void
.end method


# virtual methods
.method public g()I
    .locals 1

    const v0, 0x7f0c0099

    return v0
.end method

.method public l()V
    .locals 11

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "cutType"

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->b(Ljava/lang/String;I)I

    move-result v0

    .line 3
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;->a()Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    move-result-object v1

    iput-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    if-nez v1, :cond_0

    .line 4
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;->a()Lcn/upus/app/upprinting/data/viewmodel/SharedDataLiveData;

    move-result-object v1

    new-instance v10, Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    const-wide/16 v5, 0x0

    const-wide/16 v7, 0x0

    const-string v4, ""

    move-object v3, v10

    move v9, v0

    invoke-direct/range {v3 .. v9}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;-><init>(Ljava/lang/String;JJI)V

    iput-object v10, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    .line 5
    invoke-virtual {v1, v10}, Landroidx/lifecycle/LiveData;->setValue(Ljava/lang/Object;)V

    .line 6
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast v1, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v3, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->d:Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;

    invoke-virtual {v1, v3}, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->c(Lcn/upus/app/upprinting/data/viewmodel/SharedDataViewModel;)V

    .line 8
    :cond_0
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    invoke-virtual {v1, v0}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setCutType(I)V

    .line 9
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 10
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "DEVNO"

    const-string v3, ""

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 11
    iget-object v1, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    invoke-virtual {v1, v0}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setDevNo(Ljava/lang/String;)V

    .line 12
    :try_start_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    const-string v1, "USEQTY"

    .line 13
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 14
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    const-string v4, "BALAQTY"

    .line 15
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 16
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    if-nez v4, :cond_2

    .line 17
    :try_start_1
    invoke-static {v0}, Lc/b/a/a/k/a;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 18
    invoke-static {v1}, Lc/b/a/a/k/a;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_0

    :catch_0
    move-exception v4

    .line 19
    :try_start_2
    invoke-virtual {v4}, Ljava/lang/Exception;->printStackTrace()V

    .line 20
    :goto_0
    invoke-static {v0}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    .line 21
    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    .line 22
    invoke-static {}, Lc/a/a/j/a;->D()Ljava/util/List;

    move-result-object v6

    if-eqz v6, :cond_1

    .line 23
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v7

    if-lez v7, :cond_1

    .line 24
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v7

    int-to-long v7, v7

    add-long/2addr v4, v7

    .line 25
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    int-to-long v6, v6

    sub-long/2addr v0, v6

    .line 26
    :cond_1
    iget-object v6, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    invoke-virtual {v6, v4, v5}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setUseqty(J)V

    .line 27
    iget-object v4, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->e:Lcn/upus/app/upprinting/data/bean/SharedDataBean;

    const-wide v0, 0x1869f
    invoke-virtual {v4, v0, v1}, Lcn/upus/app/upprinting/data/bean/SharedDataBean;->setBalaqty(J)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    goto :goto_1

    :catch_1
    move-exception v0

    .line 28
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 29
    :cond_2
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 30
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->c:Landroid/widget/TextView;

    new-instance v1, Lc/b/a/a/l/b/r7/f1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/f1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 31
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 32
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->d:Landroid/widget/TextView;

    new-instance v1, Lc/b/a/a/l/b/r7/i1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/i1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 33
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 34
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->b:Landroid/widget/TextView;

    new-instance v1, Lc/b/a/a/l/b/r7/h1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/h1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 35
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->m:Landroidx/lifecycle/MutableLiveData;

    .line 36
    new-instance v1, Lc/b/a/a/l/b/r7/g3;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/g3;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 37
    invoke-static {}, Lcom/blankj/utilcode/util/NetworkUtils;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 38
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->a:Ljava/lang/String;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->m:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v0, v1}, Lc/b/a/a/h/c/e;->b(Ljava/lang/String;Landroidx/lifecycle/MutableLiveData;)V

    .line 39
    :cond_3
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->w()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 40
    new-instance v0, Landroidx/lifecycle/MutableLiveData;

    invoke-direct {v0}, Landroidx/lifecycle/MutableLiveData;-><init>()V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->l:Landroidx/lifecycle/MutableLiveData;

    .line 41
    new-instance v1, Lc/b/a/a/l/b/r7/h3;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/h3;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;)V

    invoke-virtual {v0, p0, v1}, Landroidx/lifecycle/LiveData;->observe(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Observer;)V

    .line 42
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 43
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "USER_INFO"

    invoke-virtual {v0, v1, v3}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x0

    const-string v4, "mt:"

    aput-object v4, v1, v3

    aput-object v0, v1, v2

    .line 44
    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 45
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_6

    .line 46
    const-class v1, Ljava/util/HashMap;

    invoke-static {v0, v1}, Lcom/blankj/utilcode/util/GsonUtils;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    if-eqz v0, :cond_6

    const-string v1, "userEmail"

    .line 47
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    const-string v2, "userName"

    .line 48
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v3, "userMobile"

    .line 49
    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const-string v4, "isUp"

    .line 50
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 51
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_5

    .line 52
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->q:Lc/b/a/a/l/d/p1;

    if-nez v0, :cond_4

    .line 53
    new-instance v0, Lc/b/a/a/l/b/r7/i3;

    invoke-direct {v0, p0, p0}, Lc/b/a/a/l/b/r7/i3;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;Landroid/content/Context;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->q:Lc/b/a/a/l/d/p1;

    .line 54
    :cond_4
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->q:Lc/b/a/a/l/d/p1;

    invoke-virtual {v0}, Lc/b/a/a/l/d/p1;->show()V

    goto :goto_2

    :cond_5
    const-string v4, "0"

    .line 55
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_6

    .line 56
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iget-object v4, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->l:Landroidx/lifecycle/MutableLiveData;

    invoke-static {v2, v3, v1, v0, v4}, Lc/b/a/a/h/c/e;->K(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Landroidx/lifecycle/MutableLiveData;)V

    :cond_6
    :goto_2
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 17
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    move-object/from16 v1, p0

    const-string v0, "page_onCreate"

    const/4 v2, 0x1

    invoke-static {v1, v0, v2}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v3, "onCreate"

    invoke-static {v1, v3, v2}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 1
    invoke-super/range {p0 .. p1}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onCreate(Landroid/os/Bundle;)V

    .line 2
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 3
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v4, 0x7f080121

    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    .line 4
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v5, 0x7f08011b

    invoke-virtual {v0, v5}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    .line 5
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v6, 0x7f080126

    invoke-virtual {v0, v6}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    .line 6
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v7, 0x7f08011f

    invoke-virtual {v0, v7}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    .line 7
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v8, 0x7f080123

    invoke-virtual {v0, v8}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    .line 8
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v9, 0x7f08011e

    invoke-virtual {v0, v9}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    .line 9
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v10, 0x7f08011a

    invoke-virtual {v0, v10}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    .line 10
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v11, 0x7f08011c

    invoke-virtual {v0, v11}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    .line 11
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v12, 0x7f080122

    invoke-virtual {v0, v12}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    .line 12
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v13, 0x7f08011d

    invoke-virtual {v0, v13}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v13

    .line 13
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v14, 0x7f080125

    invoke-virtual {v0, v14}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    .line 14
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v15, 0x7f080120

    invoke-virtual {v0, v15}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 15
    :try_start_0
    sget-object v0, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    if-eqz v0, :cond_a

    .line 16
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v15, Lc/b/a/a/h/a;->c:Ljava/lang/String;

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v15, "img/"

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 17
    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettRechargeImg()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v15

    if-nez v15, :cond_0

    .line 18
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v15, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v16, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 19
    invoke-virtual/range {v16 .. v16}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettRechargeImg()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v15, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 20
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    .line 21
    :cond_0
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettConfigImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_1

    .line 22
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 23
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettConfigImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 24
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    .line 25
    :cond_1
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettWifiImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_2

    .line 26
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 27
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettWifiImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 28
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    .line 29
    :cond_2
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettMaterialImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3

    .line 30
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 31
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettMaterialImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 32
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    .line 33
    :cond_3
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettDeviceImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_4

    .line 34
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 35
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettDeviceImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 36
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    .line 37
    :cond_4
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettLangImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_5

    .line 38
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 39
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettLangImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 40
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    .line 41
    :cond_5
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettBootImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_6

    .line 42
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 43
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettBootImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 44
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    .line 45
    :cond_6
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettUpdateImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_7

    .line 46
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 47
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettUpdateImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 48
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    .line 49
    :cond_7
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettStatisticsImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_8

    .line 50
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 51
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettStatisticsImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 52
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    .line 53
    :cond_8
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettFeedbackImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_9

    .line 54
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 55
    invoke-virtual {v15}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettFeedbackImg()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v2, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 56
    invoke-static {v2}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v13

    .line 57
    :cond_9
    sget-object v2, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettUserImg()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_a

    .line 58
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v0, Lcn/upus/app/upprinting/MApp;->z:Lcn/upus/app/upprinting/data/bean/AppThemeBean;

    .line 59
    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/AppThemeBean;->getSettUserImg()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/blankj/utilcode/util/ImageUtils;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v0

    .line 60
    invoke-static {v0}, Lcom/blankj/utilcode/util/ImageUtils;->bitmap2Drawable(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Drawable;

    move-result-object v14
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 61
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    .line 62
    :cond_a
    :goto_0
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v2, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v15, 0x7f110298

    invoke-virtual {v1, v15}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v16, v3

    const/4 v3, 0x0

    invoke-direct {v2, v4, v15, v3}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 63
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v2, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v4, 0x7f11026c

    invoke-virtual {v1, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v15, 0x1

    invoke-direct {v2, v5, v4, v15}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 64
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v2, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v4, 0x7f1102c4

    invoke-virtual {v1, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x2

    invoke-direct {v2, v6, v4, v5}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v0, "material"

    .line 65
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "1"

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    .line 66
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v4, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v6, 0x7f11029a

    invoke-virtual {v1, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/16 v15, 0xb

    invoke-direct {v4, v7, v6, v15}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 67
    :cond_b
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v4, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v6, 0x7f1102be

    invoke-virtual {v1, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x3

    invoke-direct {v4, v8, v6, v7}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    iput-object v4, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->p:Lcn/upus/app/upprinting/data/bean/SetBean;

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 68
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v4, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v6, 0x7f110299

    invoke-virtual {v1, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x4

    invoke-direct {v4, v9, v6, v7}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 69
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v4, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v6, 0x7f11026b

    invoke-virtual {v1, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x5

    invoke-direct {v4, v10, v6, v7}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 70
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v4, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v6, 0x7f110289

    invoke-virtual {v1, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x6

    invoke-direct {v4, v11, v6, v7}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 71
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v4, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v6, 0x7f1102a8

    invoke-virtual {v1, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x7

    invoke-direct {v4, v12, v6, v7}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 72
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 73
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "feedbackShow"

    const-string v6, ""

    invoke-virtual {v0, v4, v6}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 74
    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 75
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v2, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v4, 0x7f110293

    invoke-virtual {v1, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0x8

    invoke-direct {v2, v13, v4, v6}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 76
    :cond_c
    invoke-virtual/range {p0 .. p0}, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->w()Z

    move-result v0

    if-eqz v0, :cond_d

    .line 77
    iget-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v2, Lcn/upus/app/upprinting/data/bean/SetBean;

    const v4, 0x7f1102c3

    invoke-virtual {v1, v4}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/16 v6, 0x9

    invoke-direct {v2, v14, v4, v6}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 78
    :cond_d
    iget-object v0, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 79
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->a:Landroidx/recyclerview/widget/RecyclerView;

    const/16 v2, 0x14

    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->setItemViewCacheSize(I)V

    .line 80
    iget-object v0, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 81
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->a:Landroidx/recyclerview/widget/RecyclerView;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->setDrawingCacheEnabled(Z)V

    .line 82
    iget-object v0, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 83
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->a:Landroidx/recyclerview/widget/RecyclerView;

    const/high16 v2, 0x100000

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->setDrawingCacheQuality(I)V

    .line 84
    invoke-static {}, Lcom/blankj/utilcode/util/ScreenUtils;->isPortrait()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 85
    iget-object v0, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 86
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->a:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v2, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v4, 0x1

    invoke-direct {v2, v1, v4, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;IZ)V

    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    goto :goto_1

    .line 87
    :cond_e
    new-instance v0, Landroidx/recyclerview/widget/GridLayoutManager;

    invoke-direct {v0, v1, v5}, Landroidx/recyclerview/widget/GridLayoutManager;-><init>(Landroid/content/Context;I)V

    .line 88
    iget-object v2, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 89
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->a:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v2, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 90
    :goto_1
    new-instance v0, Lcn/upus/app/upprinting/ui/adapter/SetItemAdapter;

    invoke-direct {v0}, Lcn/upus/app/upprinting/ui/adapter/SetItemAdapter;-><init>()V

    iput-object v0, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->o:Lcn/upus/app/upprinting/ui/adapter/SetItemAdapter;

    .line 91
    iget-object v2, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 92
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->a:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v2, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 93
    iget-object v0, v1, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 94
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v2, v1, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    invoke-virtual {v0, v2}, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->b(Ljava/util/List;)V

    move-object/from16 v2, v16

    const/4 v3, 0x1

    .line 95
    invoke-static {v1, v2, v3}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onDestroy()V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->q:Lc/b/a/a/l/d/p1;

    if-eqz v0, :cond_0

    .line 3
    invoke-virtual {v0}, Lc/b/a/a/l/d/p1;->dismiss()V

    const/4 v0, 0x0

    .line 4
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->q:Lc/b/a/a/l/d/p1;

    .line 5
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->r:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 6
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->r:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    :cond_1
    return-void
.end method

.method public onPause()V
    .locals 2

    const-string v0, "onPause"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onPause()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onRestart()V
    .locals 2

    const-string v0, "page_onReStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onRestart()V

    return-void
.end method

.method public onResume()V
    .locals 7

    const-string v0, "onResume"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    .line 1
    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onResume()V

    .line 2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 3
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v3, "data_time"

    const-string v4, ""

    invoke-virtual {v2, v3, v4}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 4
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_0

    .line 5
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 6
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->b:Landroid/widget/TextView;

    const/16 v3, 0x8

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setVisibility(I)V

    goto :goto_0

    :cond_0
    const-string v3, "yyyyMMddHHmm"

    .line 7
    invoke-static {v2, v3}, Lcom/blankj/utilcode/util/TimeUtils;->string2Date(Ljava/lang/String;Ljava/lang/String;)Ljava/util/Date;

    move-result-object v2

    const-string v3, "yyyy-MM-dd HH:mm"

    .line 8
    invoke-static {v2, v3}, Lcom/blankj/utilcode/util/TimeUtils;->date2String(Ljava/util/Date;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 9
    iget-object v3, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast v3, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v3, v3, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->b:Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const v6, 0x7f11028c

    invoke-virtual {p0, v6}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "   "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 11
    iget-object v2, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v2, v2, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->b:Landroid/widget/TextView;

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setVisibility(I)V

    :goto_0
    const-string v2, "page_onResume"

    .line 13
    invoke-static {p0, v2, v4}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onStart()V
    .locals 2

    const-string v0, "page_onStart"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    const-string v0, "onStart"

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageBegin(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStart()V

    invoke-static {p0, v0, v1}, Lcom/umeng/pagesdk/PageManger;->onTracePageEnd(Landroid/app/Activity;Ljava/lang/String;Z)V

    return-void
.end method

.method public onStop()V
    .locals 2

    const-string v0, "page_onStop"

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Lcom/efs/sdk/launch/LaunchManager;->onTracePage(Landroid/app/Activity;Ljava/lang/String;Z)V

    invoke-super {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->onStop()V

    return-void
.end method

.method public final p()V
    .locals 7
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UseCompatLoadingForDrawables"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    array-length v1, v0

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    const/4 v3, 0x0

    invoke-static {v0, v2, v0, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    array-length v1, v0

    sub-int/2addr v1, v2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    aput-wide v4, v0, v1

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    aget-wide v1, v0, v3

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v3

    const-wide/16 v5, 0x3e8

    sub-long/2addr v3, v5

    cmp-long v0, v1, v3

    if-ltz v0, :cond_2

    const/4 v0, 0x4

    new-array v0, v0, [J

    .line 4
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    .line 5
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->r:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_1

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    .line 6
    :cond_0
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->r:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    goto :goto_1

    .line 7
    :cond_1
    :goto_0
    new-instance v0, Ljava/lang/ref/WeakReference;

    new-instance v1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-direct {v1}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->r:Ljava/lang/ref/WeakReference;

    .line 8
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    new-instance v1, Lc/b/a/a/l/b/r7/g1;

    invoke-direct {v1, p0}, Lc/b/a/a/l/b/r7/g1;-><init>(Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;)V

    .line 9
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->b:Lcn/upus/app/upprinting/ui/dialog/InputDialog$a;

    .line 10
    :goto_1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->r:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v1

    const-string v2, "input"

    invoke-virtual {v0, v1, v2}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    :cond_2
    return-void
.end method

.method public synthetic r(Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->v()V

    return-void
.end method

.method public synthetic s(Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->v()V

    return-void
.end method

.method public synthetic t(Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->p()V

    return-void
.end method

.method public synthetic u(Ljava/lang/String;)V
    .locals 1

    const-string v0, "5656"

    .line 1
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 2
    iget-object p1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->r:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 3
    invoke-static {p0}, Lcn/upus/app/upprinting/ui/activity/setting/CustomUpgradeActivity;->p(Landroid/content/Context;)V

    goto :goto_0

    :cond_0
    const p1, 0x7f110131

    .line 4
    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    :goto_0
    return-void
.end method

.method public final v()V
    .locals 8
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UseCompatLoadingForDrawables"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    array-length v1, v0

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    const/4 v3, 0x0

    invoke-static {v0, v2, v0, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 2
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    array-length v1, v0

    sub-int/2addr v1, v2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    aput-wide v4, v0, v1

    .line 3
    iget-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    aget-wide v1, v0, v3

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v4

    const-wide/16 v6, 0x3e8

    sub-long/2addr v4, v6

    cmp-long v0, v1, v4

    if-ltz v0, :cond_0

    const/4 v0, 0x4

    new-array v0, v0, [J

    .line 4
    iput-object v0, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->n:[J

    const v0, 0x7f1102c0

    .line 5
    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    .line 6
    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    new-instance v2, Lcn/upus/app/upprinting/data/bean/SetBean;

    invoke-virtual {p0}, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const v5, 0x7f080124

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {p0, v0}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/16 v5, 0xa

    invoke-direct {v2, v4, v0, v5}, Lcn/upus/app/upprinting/data/bean/SetBean;-><init>(Landroid/graphics/drawable/Drawable;Ljava/lang/String;I)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 7
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 8
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v1, p0, Lcn/upus/app/upprinting/ui/activity/setting/SettingActivity;->k:Ljava/util/List;

    invoke-virtual {v0, v1}, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->b(Ljava/util/List;)V

    .line 9
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 10
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->c:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    .line 11
    iget-object v0, p0, Lcn/upus/app/upprinting/base/BaseDataBindingActivity;->b:Landroidx/databinding/ViewDataBinding;

    .line 12
    check-cast v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/LayoutActivitySettingBinding;->d:Landroid/widget/TextView;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setEnabled(Z)V

    :cond_0
    return-void
.end method

.method public w()Z
    .locals 3

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "userInfoShow"

    const-string v2, ""

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    .line 3
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method
