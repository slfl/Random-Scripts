.class public Lc/b/a/a/l/c/b0;
.super Lc/b/a/a/m/g;
.source "MainTypeAdapter.java"


# instance fields
.field public final synthetic b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

.field public final synthetic c:Lcn/upus/app/upprinting/base/BindingViewHolder;

.field public final synthetic d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;


# direct methods
.method public constructor <init>(Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;Lcn/upus/app/upprinting/base/BindingViewHolder;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    iput-object p2, p0, Lc/b/a/a/l/c/b0;->b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    iput-object p3, p0, Lc/b/a/a/l/c/b0;->c:Lcn/upus/app/upprinting/base/BindingViewHolder;

    invoke-direct {p0}, Lc/b/a/a/m/g;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)V
    .locals 4

    .line 1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 2
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v1, "ID_abnormal"

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/tencent/mmkv/MMKV;->a(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_0

    .line 3
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const v0, 0x7f110130

    invoke-virtual {p1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showLong(Ljava/lang/CharSequence;)V

    return-void

    .line 4
    :cond_0
    iget-object v0, p0, Lc/b/a/a/l/c/b0;->b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getCategoryOneId()Ljava/lang/String;

    move-result-object v0

    const-string v1, "-888"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 5
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcn/upus/app/upprinting/ui/activity/USBPltFileListActivity;->r(Landroid/content/Context;)V

    goto/16 :goto_2

    .line 6
    :cond_1
    iget-object v0, p0, Lc/b/a/a/l/c/b0;->b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getNameEn()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Custom"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    new-array v0, v2, [Ljava/lang/Object;

    const/4 v1, 0x0

    const-string v2, "\u5f53\u524d\u81ea\u5b9a\u4e49\u5207\u5272\u4ea7\u54c1id\uff1a"

    .line 7
    invoke-static {v2}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lc/b/a/a/l/c/b0;->b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    aput-object v2, v0, v1

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    const-string v0, "material"

    .line 8
    invoke-static {v0}, Lc/b/a/a/m/d;->j1(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "1"

    .line 9
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 10
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x7f1101d5

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 11
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1, v0}, Lcn/upus/app/upprinting/ui/activity/ClassifyMaterialActivity;->p(Landroid/content/Context;Ljava/lang/String;)V

    goto/16 :goto_2

    .line 12
    :cond_2
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcn/upus/app/upprinting/ui/activity/CustomCutActivity;->K(Landroid/content/Context;)V

    goto/16 :goto_2

    .line 13
    :cond_3
    iget-object v0, p0, Lc/b/a/a/l/c/b0;->b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getIsLock()I

    move-result v0

    if-ne v0, v2, :cond_6

    .line 14
    iget-object v0, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 15
    iget-object v0, v0, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->c:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_5

    .line 16
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_4

    goto :goto_0

    .line 17
    :cond_4
    iget-object v0, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 18
    iget-object v0, v0, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->c:Ljava/lang/ref/WeakReference;

    .line 19
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {v0}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    goto :goto_1

    .line 20
    :cond_5
    :goto_0
    iget-object v0, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    new-instance v1, Ljava/lang/ref/WeakReference;

    new-instance v2, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-direct {v2}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;-><init>()V

    invoke-direct {v1, v2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 21
    iput-object v1, v0, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->c:Ljava/lang/ref/WeakReference;

    .line 22
    :goto_1
    iget-object v0, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 23
    iget-object v0, v0, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->c:Ljava/lang/ref/WeakReference;

    .line 24
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    iget-object v1, p0, Lc/b/a/a/l/c/b0;->b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    iget-object v2, p0, Lc/b/a/a/l/c/b0;->c:Lcn/upus/app/upprinting/base/BindingViewHolder;

    new-instance v3, Lc/b/a/a/l/c/i;

    invoke-direct {v3, p0, v1, p1, v2}, Lc/b/a/a/l/c/i;-><init>(Lc/b/a/a/l/c/b0;Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;Landroid/view/View;Lcn/upus/app/upprinting/base/BindingViewHolder;)V

    .line 25
    iput-object v3, v0, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->b:Lcn/upus/app/upprinting/ui/dialog/InputDialog$a;

    .line 26
    iget-object p1, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 27
    iget-object p1, p1, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->c:Ljava/lang/ref/WeakReference;

    .line 28
    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    iget-object v0, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 29
    iget-object v0, v0, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->d:Landroidx/fragment/app/FragmentActivity;

    const v1, 0x7f110055

    .line 30
    invoke-virtual {v0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 31
    iput-object v0, p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->c:Ljava/lang/String;

    .line 32
    iget-object p1, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 33
    iget-object p1, p1, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->c:Ljava/lang/ref/WeakReference;

    .line 34
    invoke-virtual {p1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    iget-object v0, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 35
    iget-object v0, v0, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->d:Landroidx/fragment/app/FragmentActivity;

    .line 36
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "input"

    invoke-virtual {p1, v0, v1}, Lcn/upus/app/upprinting/base/BaseDataBindingDialogFragment;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    goto :goto_2

    .line 37
    :cond_6
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    iget-object v0, p0, Lc/b/a/a/l/c/b0;->c:Lcn/upus/app/upprinting/base/BindingViewHolder;

    .line 38
    iget-object v0, v0, Lcn/upus/app/upprinting/base/BindingViewHolder;->a:Landroidx/databinding/ViewDataBinding;

    .line 39
    check-cast v0, Lcn/upus/app/upprinting/databinding/ItemMainTypeBinding;

    iget-object v0, v0, Lcn/upus/app/upprinting/databinding/ItemMainTypeBinding;->b:Landroid/widget/TextView;

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p0, Lc/b/a/a/l/c/b0;->b:Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getId()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ""

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {p1, v0, v1}, Lcn/upus/app/upprinting/ui/activity/ClassifyBrandActivity;->t(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    return-void
.end method

.method public b(Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;Landroid/view/View;Lcn/upus/app/upprinting/base/BindingViewHolder;Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getPassword()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p4

    if-eqz p4, :cond_0

    .line 2
    iget-object p4, p0, Lc/b/a/a/l/c/b0;->d:Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;

    .line 3
    iget-object p4, p4, Lcn/upus/app/upprinting/ui/adapter/MainTypeAdapter;->c:Ljava/lang/ref/WeakReference;

    .line 4
    invoke-virtual {p4}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Lcn/upus/app/upprinting/ui/dialog/InputDialog;

    invoke-virtual {p4}, Lcn/upus/app/upprinting/ui/dialog/InputDialog;->dismiss()V

    .line 5
    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    .line 6
    iget-object p3, p3, Lcn/upus/app/upprinting/base/BindingViewHolder;->a:Landroidx/databinding/ViewDataBinding;

    .line 7
    check-cast p3, Lcn/upus/app/upprinting/databinding/ItemMainTypeBinding;

    iget-object p3, p3, Lcn/upus/app/upprinting/databinding/ItemMainTypeBinding;->b:Landroid/widget/TextView;

    invoke-virtual {p3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p3

    invoke-interface {p3}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p3

    new-instance p4, Ljava/lang/StringBuilder;

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/dbBean/TypeItemBean;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ""

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p3, p1}, Lcn/upus/app/upprinting/ui/activity/ClassifyBrandActivity;->t(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :cond_0
    const p1, 0x7f110131

    .line 8
    invoke-static {p1}, Lcom/blankj/utilcode/util/ToastUtils;->showShort(I)V

    :goto_0
    return-void
.end method
