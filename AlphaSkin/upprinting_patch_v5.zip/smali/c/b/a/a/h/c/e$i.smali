.class public final Lc/b/a/a/h/c/e$i;
.super Ljava/lang/Object;
.source "ApiRepository.java"

# interfaces
.implements Le/b/k;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lc/b/a/a/h/c/e;->A(Landroidx/lifecycle/MutableLiveData;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Le/b/k<",
        "Lcn/upus/app/upprinting/data/net/LoginDataResponse;",
        ">;"
    }
.end annotation


# instance fields
.field public final synthetic a:Landroidx/lifecycle/MutableLiveData;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/MutableLiveData;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lc/b/a/a/h/c/e$i;->a:Landroidx/lifecycle/MutableLiveData;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onComplete()V
    .locals 0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 2
    iget-object p1, p0, Lc/b/a/a/h/c/e$i;->a:Landroidx/lifecycle/MutableLiveData;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p1, v0}, Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V

    return-void
.end method

.method public onNext(Ljava/lang/Object;)V
    .locals 5

    .line 1
    check-cast p1, Lcn/upus/app/upprinting/data/net/LoginDataResponse;

    if-eqz p1, :cond_1

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getCode()I

    move-result v0

    const/16 v1, 0xc8

    if-ne v0, v1, :cond_1

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 4
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v0

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 5
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v0

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getResultCode()I

    move-result v0

    if-ne v0, v1, :cond_1

    .line 6
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    .line 7
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getEnable()Ljava/lang/String;

    move-result-object v0

    const-string v1, "0"

    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    const-string v2, "ID_abnormal"

    const/4 v3, 0x1

    goto :cond_0

    .line 9
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 10
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "ID_REGISTERED"

    invoke-virtual {v0, v4, v3}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    .line 11
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 12
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0, v2, v1}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    goto :goto_0

    .line 13
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    .line 14
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v0, v2, v3}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    .line 15
    :goto_0
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getSessionId()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    .line 16
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    sget-object v2, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    .line 17
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "sessionId"

    invoke-virtual {v0, v4, v2}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 18
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v0

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutType()I

    move-result v2

    .line 19
    iget-object v0, v0, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "cutType"

    invoke-virtual {v0, v4, v2}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    .line 20
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getAgentSerialConfigs()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc/b/a/a/m/d;->w1(Ljava/lang/String;)V

    new-array v0, v3, [Ljava/lang/Object;

    const-string v2, "agentSerialConfigs_login_async\uff1a"

    .line 21
    invoke-static {v2}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getAgentSerialConfigs()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    aput-object p1, v0, v1

    invoke-static {v0}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 22
    iget-object p1, p0, Lc/b/a/a/h/c/e$i;->a:Landroidx/lifecycle/MutableLiveData;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p1, v0}, Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V

    goto :goto_1

    .line 23
    :cond_1
    iget-object p1, p0, Lc/b/a/a/h/c/e$i;->a:Landroidx/lifecycle/MutableLiveData;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p1, v0}, Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V

    :goto_1
    return-void
.end method

.method public onSubscribe(Le/b/p/b;)V
    .locals 0

    return-void
.end method
