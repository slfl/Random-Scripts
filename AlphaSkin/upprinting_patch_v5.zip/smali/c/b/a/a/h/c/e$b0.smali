.class public final Lc/b/a/a/h/c/e$b0;
.super Ljava/lang/Object;
.source "ApiRepository.java"

# interfaces
.implements Le/b/k;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lc/b/a/a/h/c/e;->S(Landroidx/lifecycle/MutableLiveData;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Le/b/k<",
        "Lcn/upus/app/upprinting/data/net/DataResponse<",
        "Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;",
        ">;>;"
    }
.end annotation


# instance fields
.field public final synthetic a:Landroidx/lifecycle/MutableLiveData;


# direct methods
.method public constructor <init>(Landroidx/lifecycle/MutableLiveData;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lc/b/a/a/h/c/e$b0;->a:Landroidx/lifecycle/MutableLiveData;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onComplete()V
    .locals 0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 2
    iget-object p1, p0, Lc/b/a/a/h/c/e$b0;->a:Landroidx/lifecycle/MutableLiveData;

    if-eqz p1, :cond_0

    const/4 v0, 0x0

    .line 3
    invoke-virtual {p1, v0}, Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V

    :cond_0
    return-void
.end method

.method public onNext(Ljava/lang/Object;)V
    .locals 10

    .line 1
    check-cast p1, Lcn/upus/app/upprinting/data/net/DataResponse;

    .line 2
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getCode()I

    move-result v0

    const/16 v1, 0xc8

    if-ne v0, v1, :cond_6

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v0

    if-eqz v0, :cond_6

    .line 3
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v0

    invoke-virtual {v0}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getResultCode()I

    move-result v0

    if-ne v0, v1, :cond_6

    const/4 v0, 0x1

    new-array v1, v0, [Ljava/lang/Object;

    const-string v2, "userInfo\uff1a"

    .line 4
    invoke-static {v2}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    new-instance v3, Lcom/google/gson/Gson;

    invoke-direct {v3}, Lcom/google/gson/Gson;-><init>()V

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v4

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/google/gson/Gson;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    aput-object v2, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 5
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getForcedUpdate()Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lcn/upus/app/upprinting/MApp;->C:Ljava/lang/String;

    .line 6
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getAgentId()Ljava/lang/String;

    move-result-object v2

    .line 7
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "ID_AGENT"

    invoke-virtual {v1, v4, v2}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 8
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getEnable()Ljava/lang/String;

    move-result-object v1

    const-string v2, "0"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const-string v4, "ID_abnormal"

    goto :cond_0

    .line 9
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 10
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "ID_REGISTERED"

    invoke-virtual {v1, v5, v0}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    .line 11
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 12
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    goto :goto_0

    .line 13
    :cond_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 14
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v1, v4, v0}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    .line 15
    :goto_0
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 16
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v4

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getPrints()Ljava/lang/String;

    move-result-object v4

    .line 17
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "Print_Type"

    invoke-virtual {v1, v5, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 18
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 19
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v5

    invoke-virtual {v5}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v5}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v5

    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v5, ""

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 20
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "USEQTY"

    invoke-virtual {v1, v6, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 21
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutTotalCount()J

    move-result-wide v6

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutUseCount()J

    move-result-wide v8

    sub-long/2addr v6, v8

    .line 22
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 23
    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lc/b/a/a/k/a;->k(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 24
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "BALAQTY"

    invoke-virtual {v1, v6, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 25
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 26
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v4

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutStartTime()J

    move-result-wide v6

    .line 27
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "cutStartTime"

    invoke-virtual {v1, v4, v6, v7}, Lcom/tencent/mmkv/MMKV;->f(Ljava/lang/String;J)Z

    .line 28
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 29
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v4

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutEndTime()J

    move-result-wide v6

    .line 30
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "cutEndTime"

    invoke-virtual {v1, v4, v6, v7}, Lcom/tencent/mmkv/MMKV;->f(Ljava/lang/String;J)Z

    .line 31
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 32
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v4

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v4}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutType()I

    move-result v4

    .line 33
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "cutType"

    invoke-virtual {v1, v6, v4}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    new-array v1, v0, [Ljava/lang/Object;

    const-string v4, "AgentSerialConfigs_user_info\uff1a"

    .line 34
    invoke-static {v4}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v6

    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getAgentSerialConfigs()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 35
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getAgentSerialConfigs()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc/b/a/a/m/d;->w1(Ljava/lang/String;)V

    new-array v1, v0, [Ljava/lang/Object;

    const-string v4, "\u4f1a\u8bddId\uff1a"

    .line 36
    invoke-static {v4}, Ld/a/a/a/a;->z(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v6

    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getSessionId()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    invoke-static {v1}, Lcom/blankj/utilcode/util/LogUtils;->d([Ljava/lang/Object;)V

    .line 37
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 38
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getCutNet()I

    move-result v3

    .line 39
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "cutNet"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    .line 40
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 41
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getOffCutMax()I

    move-result v3

    .line 42
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "offCutMax"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->e(Ljava/lang/String;I)Z

    .line 43
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 44
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    iget-object v3, v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->feedback:Ljava/lang/String;

    .line 45
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "feedbackShow"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 46
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 47
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    iget-object v3, v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->categoryShow:Ljava/lang/String;

    .line 48
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "categoryShow"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 49
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 50
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    iget-object v3, v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->userInfoShow:Ljava/lang/String;

    .line 51
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "userInfoShow"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 52
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 53
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    iget-object v3, v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->monthlyShow:Ljava/lang/String;

    .line 54
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "monthlyShow"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 55
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 56
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    iget-object v3, v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->cutCountShow:Ljava/lang/String;

    .line 57
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "cutCountShow"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 58
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 59
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    iget-object v3, v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->appCategoryShow:Ljava/lang/String;

    .line 60
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "appPltShow"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 61
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 62
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getSecondAgentId()Ljava/lang/String;

    move-result-object v3

    .line 63
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v4, "second_agent_id"

    invoke-virtual {v1, v4, v3}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    .line 64
    iget-object v1, p0, Lc/b/a/a/h/c/e$b0;->a:Landroidx/lifecycle/MutableLiveData;

    if-eqz v1, :cond_1

    .line 65
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V

    .line 66
    :cond_1
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v1

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getUserName()Ljava/lang/String;

    move-result-object v1

    .line 67
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v3

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v3}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getUserMobile()Ljava/lang/String;

    move-result-object v3

    .line 68
    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object p1

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {p1}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getUserEmail()Ljava/lang/String;

    move-result-object p1

    .line 69
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    .line 70
    iget-object v4, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v6, "USER_INFO"

    invoke-virtual {v4, v6, v5}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 71
    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    const-string v8, "isUp"

    if-nez v7, :cond_2

    .line 72
    const-class v7, Ljava/util/HashMap;

    invoke-static {v4, v7}, Lcom/blankj/utilcode/util/GsonUtils;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map;

    if-eqz v4, :cond_2

    .line 73
    invoke-interface {v4, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/CharSequence;

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_2

    .line 74
    invoke-interface {v4, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    xor-int/2addr v0, v2

    :cond_2
    if-eqz v0, :cond_7

    .line 75
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 76
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_3

    move-object p1, v5

    :cond_3
    const-string v2, "userEmail"

    invoke-virtual {v0, v2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 77
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_4

    move-object v1, v5

    :cond_4
    const-string p1, "userName"

    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_5

    goto :goto_1

    :cond_5
    move-object v5, v3

    :goto_1
    const-string p1, "userMobile"

    invoke-virtual {v0, p1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p1, "1"

    .line 79
    invoke-virtual {v0, v8, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object p1

    invoke-static {v0}, Lcom/blankj/utilcode/util/GsonUtils;->toJson(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    .line 81
    iget-object p1, p1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {p1, v6, v0}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    goto :goto_2

    .line 82
    :cond_6
    iget-object p1, p0, Lc/b/a/a/h/c/e$b0;->a:Landroidx/lifecycle/MutableLiveData;

    if-eqz p1, :cond_7

    const/4 v0, 0x0

    .line 83
    invoke-virtual {p1, v0}, Landroidx/lifecycle/MutableLiveData;->postValue(Ljava/lang/Object;)V

    :cond_7
    :goto_2
    return-void
.end method

.method public onSubscribe(Le/b/p/b;)V
    .locals 0

    return-void
.end method
