.class public Lc/b/a/a/h/c/o;
.super Ljava/lang/Object;
.source "HeaderInterceptor.java"

# interfaces
.implements Lg/a0;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public intercept(Lg/a0$a;)Lg/j0;
    .locals 12

    .line 1
    check-cast p1, Lg/m0/h/f;

    .line 2
    iget-object v0, p1, Lg/m0/h/f;->e:Lg/f0;

    .line 3
    sget-object v1, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const-string v2, ""

    const-string v3, "sessionId"

    if-eqz v1, :cond_0

    .line 4
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v1

    .line 5
    iget-object v1, v1, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v1, v3, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 6
    sput-object v1, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    :cond_0
    if-eqz v0, :cond_5

    .line 7
    new-instance v1, Lg/f0$a;

    invoke-direct {v1, v0}, Lg/f0$a;-><init>(Lg/f0;)V

    .line 8
    sget-object v4, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    invoke-virtual {v1, v3, v4}, Lg/f0$a;->c(Ljava/lang/String;Ljava/lang/String;)Lg/f0$a;

    invoke-virtual {v1}, Lg/f0$a;->a()Lg/f0;

    move-result-object v1

    .line 9
    iget-object v4, p1, Lg/m0/h/f;->b:Lg/m0/g/j;

    iget-object v5, p1, Lg/m0/h/f;->c:Lg/m0/g/d;

    invoke-virtual {p1, v1, v4, v5}, Lg/m0/h/f;->b(Lg/f0;Lg/m0/g/j;Lg/m0/g/d;)Lg/j0;

    move-result-object v1

    .line 10
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v4

    .line 11
    iget-object v4, v4, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    const-string v5, "DEVNO"

    invoke-virtual {v4, v5, v2}, Lcom/tencent/mmkv/MMKV;->d(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 12
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1

    return-object v1

    .line 13
    :cond_1
    :try_start_0
    iget v2, v1, Lg/j0;->c:I

    const/16 v4, 0xc8

    if-ne v2, v4, :cond_4

    .line 14
    iget-object v2, v1, Lg/j0;->g:Lg/k0;

    .line 15
    invoke-virtual {v2}, Lg/k0;->contentType()Lg/b0;

    move-result-object v2

    .line 16
    iget-object v5, v1, Lg/j0;->g:Lg/k0;

    .line 17
    invoke-virtual {v5}, Lg/k0;->string()Ljava/lang/String;

    move-result-object v5

    .line 18
    new-instance v6, Lcom/google/gson/Gson;

    invoke-direct {v6}, Lcom/google/gson/Gson;-><init>()V

    .line 19
    const-class v7, Lcn/upus/app/upprinting/data/net/DataResponse;

    invoke-virtual {v6, v5, v7}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lcn/upus/app/upprinting/data/net/DataResponse;

    const/4 v8, 0x1

    new-array v9, v8, [Ljava/lang/Object;

    .line 20
    iget-object v10, v1, Lg/j0;->a:Lg/f0;

    .line 21
    iget-object v10, v10, Lg/f0;->a:Lg/z;

    const/4 v11, 0x0

    aput-object v10, v9, v11

    .line 22
    invoke-static {v9}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    new-array v9, v8, [Ljava/lang/Object;

    aput-object v5, v9, v11

    .line 23
    invoke-static {v9}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    .line 24
    invoke-virtual {v7}, Lcn/upus/app/upprinting/data/net/DataResponse;->getCode()I

    move-result v7

    const/16 v9, 0x191

    if-ne v7, v9, :cond_3

    .line 25
    invoke-static {}, Lc/b/a/a/h/c/e;->z()Lg/j0;

    move-result-object v7

    new-array v9, v8, [Ljava/lang/Object;

    .line 26
    iget v10, v7, Lg/j0;->c:I

    .line 27
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    aput-object v10, v9, v11

    invoke-static {v9}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    .line 28
    iget v9, v7, Lg/j0;->c:I

    if-ne v9, v4, :cond_3

    .line 29
    iget-object v7, v7, Lg/j0;->g:Lg/k0;

    .line 30
    invoke-virtual {v7}, Lg/k0;->string()Ljava/lang/String;

    move-result-object v7

    const-class v9, Lcn/upus/app/upprinting/data/net/LoginDataResponse;

    invoke-virtual {v6, v7, v9}, Lcom/google/gson/Gson;->fromJson(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcn/upus/app/upprinting/data/net/LoginDataResponse;

    if-eqz v6, :cond_3

    .line 31
    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getCode()I

    move-result v7

    if-ne v7, v4, :cond_3

    .line 32
    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v7

    if-eqz v7, :cond_3

    .line 33
    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v7

    invoke-virtual {v7}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_3

    .line 34
    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v7

    invoke-virtual {v7}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getResultCode()I

    move-result v7

    if-ne v7, v4, :cond_3

    .line 35
    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getEnable()Ljava/lang/String;

    move-result-object v2

    const-string v4, "0"

    .line 36
    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const-string v4, "ID_abnormal"

    goto :cond_2

    .line 37
    :try_start_1
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    const-string v5, "ID_REGISTERED"

    .line 38
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2, v5, v8}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    .line 39
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 40
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2, v4, v11}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    goto :goto_0

    .line 41
    :cond_2
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    .line 42
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2, v4, v8}, Lcom/tencent/mmkv/MMKV;->i(Ljava/lang/String;Z)Z

    .line 43
    :goto_0
    invoke-virtual {v6}, Lcn/upus/app/upprinting/data/net/LoginDataResponse;->getData()Lcn/upus/app/upprinting/data/net/DataResultResponse;

    move-result-object v2

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/net/DataResultResponse;->getBussData()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;

    invoke-virtual {v2}, Lcn/upus/app/upprinting/data/bean/DeviceInfoBean;->getSessionId()Ljava/lang/String;

    move-result-object v2

    sput-object v2, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    .line 44
    invoke-static {}, Lc/b/a/a/m/f;->c()Lc/b/a/a/m/f;

    move-result-object v2

    sget-object v4, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    .line 45
    iget-object v2, v2, Lc/b/a/a/m/f;->b:Lcom/tencent/mmkv/MMKV;

    invoke-virtual {v2, v3, v4}, Lcom/tencent/mmkv/MMKV;->g(Ljava/lang/String;Ljava/lang/String;)Z

    new-array v2, v8, [Ljava/lang/Object;

    .line 46
    sget-object v4, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    aput-object v4, v2, v11

    invoke-static {v2}, Lcom/blankj/utilcode/util/LogUtils;->e([Ljava/lang/Object;)V

    .line 47
    new-instance v2, Lg/f0$a;

    invoke-direct {v2, v0}, Lg/f0$a;-><init>(Lg/f0;)V

    .line 48
    sget-object v0, Lcn/upus/app/upprinting/MApp;->B:Ljava/lang/String;

    invoke-virtual {v2, v3, v0}, Lg/f0$a;->c(Ljava/lang/String;Ljava/lang/String;)Lg/f0$a;

    invoke-virtual {v2}, Lg/f0$a;->a()Lg/f0;

    move-result-object v0

    .line 49
    iget-object v2, p1, Lg/m0/h/f;->b:Lg/m0/g/j;

    iget-object v3, p1, Lg/m0/h/f;->c:Lg/m0/g/d;

    invoke-virtual {p1, v0, v2, v3}, Lg/m0/h/f;->b(Lg/f0;Lg/m0/g/j;Lg/m0/g/d;)Lg/j0;

    move-result-object v1

    .line 50
    iget-object p1, v1, Lg/j0;->g:Lg/k0;

    .line 51
    invoke-virtual {p1}, Lg/k0;->contentType()Lg/b0;

    move-result-object v2

    .line 52
    iget-object p1, v1, Lg/j0;->g:Lg/k0;

    .line 53
    invoke-virtual {p1}, Lg/k0;->string()Ljava/lang/String;

    move-result-object v5

    .line 54
    :cond_3
    invoke-static {v2, v5}, Lg/k0;->create(Lg/b0;Ljava/lang/String;)Lg/k0;

    move-result-object p1

    .line 55
    new-instance v0, Lg/j0$a;

    invoke-direct {v0, v1}, Lg/j0$a;-><init>(Lg/j0;)V

    .line 56
    iput-object p1, v0, Lg/j0$a;->g:Lg/k0;

    .line 57
    invoke-virtual {v0}, Lg/j0$a;->a()Lg/j0;

    move-result-object p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    .line 58
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    :cond_4
    return-object v1

    :cond_5
    const/4 p1, 0x0

    .line 59
    throw p1
.end method
